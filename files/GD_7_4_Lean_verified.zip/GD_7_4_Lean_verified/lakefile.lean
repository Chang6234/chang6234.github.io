import Lake
open Lake DSL

package «gdproof» where

require mathlib from git "https://github.com/leanprover-community/mathlib4.git" @ "v4.8.0"

@[default_target] lean_lib GDProof where
  roots := #[`GDProof]
