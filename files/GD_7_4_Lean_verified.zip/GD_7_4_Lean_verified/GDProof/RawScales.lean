import GDProof.RawInterval

namespace GDProof.RawScales

open GDProof.Schedule GDProof.Prefix GDProof.RawInterval

noncomputable section

/-- Second coordinates propagate the trailing binary scale of each raw coefficient. -/
def tagged : ℕ → ℝ → ℕ → List (ℝ × ℕ)
  | 0, a, q => [(a,q)]
  | k+1, a, q => tagged k (small a) 1 ++ tagged k (large a) (2*q)

def tagChildren : List (ℝ × ℕ) → List (ℝ × ℕ)
  | [] => []
  | (a,q) :: t => (small a,1) :: (large a,2*q) :: tagChildren t

def tagTail : ℕ → List (ℝ × ℕ)
  | 0 => []
  | k+1 => (2,2) :: tagChildren (tagTail k)

def taggedRaw (k : ℕ) := (1,1) :: tagTail k

def vals (x : List (ℝ × ℕ)) : List ℝ := x.map Prod.fst

@[simp] theorem vals_append (x y : List (ℝ × ℕ)) : vals (x ++ y) = vals x ++ vals y :=
  List.map_append ..

theorem tagged_vals (k : ℕ) (a : ℝ) (q : ℕ) : vals (tagged k a q) = descendants k a := by
  induction k generalizing a q with
  | zero => rfl
  | succ k ih => simp [tagged,descendants,ih]

private theorem tagChildren_append (x y : List (ℝ × ℕ)) :
    tagChildren (x ++ y) = tagChildren x ++ tagChildren y := by
  induction x with
  | nil => rfl
  | cons h xs ih =>
    rcases h with ⟨a,q⟩
    simp [tagChildren,ih]

private theorem tagChildren_tagged (k : ℕ) (a : ℝ) (q : ℕ) :
    tagChildren (tagged k a q) = tagged (k+1) a q := by
  induction k generalizing a q with
  | zero => rfl
  | succ k ih =>
    change tagChildren (tagged k (small a) 1 ++ tagged k (large a) (2*q)) = _
    rw [tagChildren_append, ih, ih]
    rfl

theorem tagTail_snoc (k : ℕ) : tagTail (k+1) = tagTail k ++ tagged k 2 2 := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change (2,2) :: tagChildren (tagTail (k+1)) = ((2,2) :: tagChildren (tagTail k)) ++ tagged (k+1) 2 2
    rw [ih,tagChildren_append,tagChildren_tagged]
    rfl

theorem taggedRaw_snoc (k : ℕ) : taggedRaw (k+1) = taggedRaw k ++ tagged k 2 2 := by
  unfold taggedRaw
  rw [tagTail_snoc]
  rfl

theorem taggedRaw_vals (k : ℕ) : vals (taggedRaw k) = raw k := by
  induction k with
  | zero => rfl
  | succ k ih => rw [taggedRaw_snoc, vals_append, tagged_vals, ih, raw_snoc]

theorem tagged_coefficient (k : ℕ) {a : ℝ} (q : ℕ) (ha : 1 ≤ a) (haq : a ≤ 2*(q:ℝ)^2) :
    ∀ h ∈ tagged k a q, h.1 ≤ 2*(h.2:ℝ)^2 := by
  induction k generalizing a q with
  | zero =>
    intro h hh
    simp only [tagged,List.mem_singleton] at hh
    subst h
    exact haq
  | succ k ih =>
    obtain ⟨hslo,hshi⟩ := small_bounds ha
    have hqc : large a ≤ 2*((2*q:ℕ):ℝ)^2 := by
      push_cast
      nlinarith only [pair_add a,hslo,haq]
    intro h hh
    rcases List.mem_append.mp hh with hh | hh
    · exact ih 1 hslo (by simpa using hshi) h hh
    · exact ih (2*q) (by linarith [large_lower ha]) hqc h hh

theorem raw_coefficient (k : ℕ) : ∀ h ∈ taggedRaw k, h.1 ≤ 2*(h.2:ℝ)^2 := by
  induction k with
  | zero =>
    exact tagged_coefficient 0 (a := 1) 1 (by norm_num) (by norm_num)
  | succ k ih =>
    intro h hh
    rw [taggedRaw_snoc] at hh
    rcases List.mem_append.mp hh with hh | hh
    · exact ih h hh
    · exact tagged_coefficient k (a := 2) 2 (by norm_num) (by norm_num) h hh

private theorem end_scale (k : ℕ) (a : ℝ) (q : ℕ) :
    ∃ b : ℝ, (b,2^k*q) ∈ tagged k a q := by
  induction k generalizing a q with
  | zero => exact ⟨a,by simp [tagged]⟩
  | succ k ih =>
    obtain ⟨b,hb⟩ := ih (large a) (2*q)
    refine ⟨b,List.mem_append.mpr (Or.inr ?_)⟩
    rw [pow_succ,mul_assoc]
    exact hb

private theorem mass_at_scale (k : ℕ) {a Q : ℝ} {q : ℕ}
    (haq : a ≤ 2*(q:ℝ)^2) (hQ : ((2:ℕ)^k*q : ℕ) ≤ Q) :
    a*(4:ℝ)^k ≤ 2*Q^2 := by
  have hQr : (2:ℝ)^k*(q:ℝ) ≤ Q := by exact_mod_cast hQ
  have hpow : ((2:ℝ)^k)^2 = (4:ℝ)^k := by rw [pow_two,← mul_pow]; norm_num
  have hscaled := mul_le_mul_of_nonneg_right haq (by positivity : 0 ≤ (4:ℝ)^k)
  have hsq := mul_self_le_mul_self (show 0 ≤ (2:ℝ)^k*(q:ℝ) by positivity) hQr
  rw [← hpow] at hscaled ⊢
  nlinarith only [hscaled, hsq]

private theorem vals_cut (k : ℕ) (a : ℝ) (q : ℕ) (l x r : List (ℝ × ℕ))
    (h : tagged k a q = l ++ (x ++ r)) :
    descendants k a = vals l ++ (vals x ++ vals r) := by
  rw [← tagged_vals k a q,h,vals_append,vals_append]

/-- The max-scale estimate is stated with any common upper bound Q on the
scales in the queried interval, so it also handles the empty interval. -/
theorem tagged_interval (k : ℕ) {a z Q : ℝ} (q : ℕ) (ha : 1 ≤ a)
    (haq : a ≤ 2*(q:ℝ)^2) (hz : 0 ≤ z) (h₁ : z ≤ 1) (l x r : List (ℝ × ℕ))
    (h : tagged k a q = l ++ (x ++ r)) (hQ : ∀ h ∈ x, (h.2:ℝ) ≤ Q) :
    |prod z (vals x)| ≤ max 1 (2*Q^2*z) := by
  induction k generalizing a q l x r with
  | zero =>
    cases x with
    | nil => simp [vals,prod]
    | cons b x =>
      cases l with
      | nil =>
        obtain ⟨he,ht⟩ := List.cons.inj h
        subst b
        have hx := (List.append_eq_nil.mp ht.symm).1
        subst x
        have hm := mass_at_scale 0 haq (by simpa using hQ (a,q) (by simp))
        have hw := descendants_interval 0 ha hz h₁ _ _ _ (vals_cut 0 a q _ _ _ h)
        exact hw.trans (max_le_max_left _ (mul_le_mul_of_nonneg_right hm hz))
      | cons b l =>
        have ht := (List.cons.inj h).2
        have hr := (List.append_eq_nil.mp ht.symm).2
        cases hr
  | succ k ih =>
    have hsmall := small_bounds ha
    have hc : 1 ≤ large a := by linarith [large_lower ha]
    have hqc : large a ≤ 2*((2*q:ℕ):ℝ)^2 := by
      push_cast
      nlinarith only [pair_add a, hsmall.1, haq]
    have hqb : small a ≤ 2*((1:ℕ):ℝ)^2 := by simpa using hsmall.2
    rcases cut _ _ _ _ h with ⟨u,hA,hu⟩ | ⟨u,_,hB⟩
    · rcases cut _ _ _ _ hu with ⟨v,hux,_⟩ | ⟨v,hxv,hB⟩
      · exact ih 1 hsmall.1 hqb l x v (by rw [hA, hux]) hQ
      · by_cases hr : r = []
        · subst r
          obtain ⟨b,hb⟩ := end_scale k (large a) (2*q)
          simp only [List.append_nil] at hB
          have hscale := hQ (b,2^k*(2*q)) (by rw [hxv,← hB]; exact List.mem_append.mpr (Or.inr hb))
          have hbound : ((2:ℕ)^(k+1)*q : ℕ) ≤ Q := by rwa [pow_succ,mul_assoc]
          have hm := mass_at_scale (k+1) haq hbound
          have hw := descendants_interval (k+1) ha hz h₁ _ _ _ (vals_cut _ _ _ _ _ _ h)
          exact hw.trans (max_le_max_left _ (mul_le_mul_of_nonneg_right hm hz))
        · have hleft := ih 1 hsmall.1 hqb l u [] (by simpa using hA)
            (fun e he => hQ e (by rw [hxv]; exact List.mem_append.mpr (Or.inl he)))
          have hright := descendants_proper_prefix k hc hz h₁ (vals v) (vals r)
            (by simpa [vals] using hr) (by rw [← tagged_vals k (large a) (2*q),hB,vals_append])
          rw [hxv,vals_append,prod_append,abs_mul]
          simpa using mul_le_mul hleft hright (abs_nonneg _) (le_trans (abs_nonneg _) hleft)
    · exact ih (2*q) hc hqc u x r hB hQ

/-- Every consecutive raw interval is bounded by its largest *local* binary
scale. The full raw list is the first-coordinate projection of taggedRaw. -/
theorem raw_local_interval (k : ℕ) {z Q : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (l x r : List (ℝ × ℕ)) (h : taggedRaw k = l ++ (x ++ r))
    (hQ : ∀ h ∈ x, (h.2:ℝ) ≤ Q) : |prod z (vals x)| ≤ max 1 (2*Q^2*z) := by
  induction k generalizing l x r with
  | zero =>
    exact tagged_interval 0 1 (a := 1) (by norm_num) (by norm_num) hz h₁ l x r h hQ
  | succ k ih =>
    rw [taggedRaw_snoc] at h
    rcases cut _ _ _ _ h with ⟨u,hA,hu⟩ | ⟨u,_,hB⟩
    · rcases cut _ _ _ _ hu with ⟨v,hux,_⟩ | ⟨v,hxv,hB⟩
      · exact ih l x v (by rw [hA,hux]) hQ
      · have hl := ih l u [] (by simpa using hA)
            (fun e he => hQ e (by rw [hxv]; exact List.mem_append.mpr (Or.inl he)))
        have ht : descendants k 2 = vals v ++ vals r := by rw [← tagged_vals k 2 2,hB,vals_append]
        have hr : |prod z (vals v)| ≤ 1 := by
          by_cases hr : r = []
          · subst r
            have hn : vals [] = [] := rfl
            simp only [hn,List.append_nil] at ht
            rw [← ht]
            exact full_small k (by norm_num) (by norm_num) hz h₁
          · exact descendants_proper_prefix k (by norm_num) hz h₁ _ _ (by simpa [vals] using hr) ht
        rw [hxv,vals_append,prod_append,abs_mul]
        simpa using mul_le_mul hl hr (abs_nonneg _) (le_trans (abs_nonneg _) hl)
    · exact tagged_interval k 2 (a := 2) (by norm_num) (by norm_num) hz h₁ u x r hB hQ

end

end GDProof.RawScales
