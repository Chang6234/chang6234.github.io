import GDProof.GuardSizes
import GDProof.RawScales

/-!
# Scalar perturbation energies (Appendix A.3)

The recursions below sum the left endpoint first. In `response z r xs`,
each term is the endpoint weight `r h` times the product of squared
factors strictly before that endpoint. In `pairSum z l r xs`, the left
and right endpoints have weights `l` and `r`; the factors strictly
between them are squared.

The exact concatenation law partitions all ordered pairs. The two
squared Frobenius sums and the paper's dominating sum are instances of
the same recursion. The low-frequency theorem is uniform in the actual
length of the input list.
-/

namespace GDProof.Kernel
noncomputable section

def factor (z h : ℝ) : ℝ := (1 - z * h) ^ 2

def weight (z h : ℝ) : ℝ := h * (1 + z * h)

def product (z : ℝ) : List ℝ → ℝ
  | [] => 1
  | h :: xs => factor z h * product z xs

def response (z : ℝ) (r : ℝ → ℝ) : List ℝ → ℝ
  | [] => 0
  | h :: xs => r h + factor z h * response z r xs

def reverseResponse (z : ℝ) (l : ℝ → ℝ) : List ℝ → ℝ
  | [] => 0
  | h :: xs => l h * product z xs + reverseResponse z l xs

def pairSum (z : ℝ) (l r : ℝ → ℝ) : List ℝ → ℝ
  | [] => 0
  | h :: xs => l h * response z r xs + pairSum z l r xs

def D (z : ℝ) (xs : List ℝ) : ℝ := pairSum z (weight z) (weight z) xs

theorem product_append (z : ℝ) (xs ys : List ℝ) :
    product z (xs ++ ys) = product z xs * product z ys := by
  induction xs with
  | nil => simp [product]
  | cons h xs ih =>
    change factor z h * product z (xs ++ ys) = (factor z h * product z xs) * product z ys
    rw [ih, mul_assoc]

theorem response_append (z : ℝ) (r : ℝ → ℝ) (xs ys : List ℝ) :
    response z r (xs ++ ys) = response z r xs + product z xs * response z r ys := by
  induction xs with
  | nil => simp [response, product]
  | cons h xs ih =>
    change r h + factor z h * response z r (xs ++ ys) =
      r h + factor z h * response z r xs + (factor z h * product z xs) * response z r ys
    rw [ih]
    ring

theorem reverseResponse_append (z : ℝ) (l : ℝ → ℝ) (xs ys : List ℝ) :
    reverseResponse z l (xs ++ ys) =
      reverseResponse z l xs * product z ys + reverseResponse z l ys := by
  induction xs with
  | nil => simp [reverseResponse, product]
  | cons h xs ih =>
    change l h * product z (xs ++ ys) + reverseResponse z l (xs ++ ys) =
      (l h * product z xs + reverseResponse z l xs) * product z ys + reverseResponse z l ys
    rw [product_append, ih]
    ring

theorem pairSum_append (z : ℝ) (l r : ℝ → ℝ) (xs ys : List ℝ) :
    pairSum z l r (xs ++ ys) = pairSum z l r xs + pairSum z l r ys +
      reverseResponse z l xs * response z r ys := by
  induction xs with
  | nil => simp [pairSum, reverseResponse]
  | cons h xs ih =>
    change l h * response z r (xs ++ ys) + pairSum z l r (xs ++ ys) =
      (l h * response z r xs + pairSum z l r xs) + pairSum z l r ys +
        (l h * product z xs + reverseResponse z l xs) * response z r ys
    rw [response_append, ih]
    ring

def joinBlocks : List (List ℝ) → List ℝ
  | [] => []
  | x :: xs => x ++ joinBlocks xs

def withinBlocks (z : ℝ) : List (List ℝ) → ℝ
  | [] => 0
  | x :: xs => D z x + withinBlocks z xs

/-- For right endpoint blocks Y after the current block, this recursion
weights each U(Y) by the squared product of all intervening blocks. -/
def later (z : ℝ) : List (List ℝ) → ℝ
  | [] => 0
  | y :: ys => response z (weight z) y + product z y * later z ys

def acrossBlocks (z : ℝ) : List (List ℝ) → ℝ
  | [] => 0
  | x :: xs => reverseResponse z (weight z) x * later z xs + acrossBlocks z xs

theorem response_joinBlocks (z : ℝ) (bs : List (List ℝ)) :
    response z (weight z) (joinBlocks bs) = later z bs := by
  induction bs with
  | nil => rfl
  | cons x xs ih => simp only [joinBlocks, later, response_append, ih]

theorem partition_blocks (z : ℝ) (bs : List (List ℝ)) :
    D z (joinBlocks bs) = withinBlocks z bs + acrossBlocks z bs := by
  induction bs with
  | nil => simp [D, pairSum, joinBlocks, withinBlocks, acrossBlocks]
  | cons x xs ih =>
    change pairSum z (weight z) (weight z) (x ++ joinBlocks xs) =
      (D z x + withinBlocks z xs) +
        (reverseResponse z (weight z) x * later z xs + acrossBlocks z xs)
    rw [pairSum_append, response_joinBlocks]
    change D z x + D z (joinBlocks xs) + reverseResponse z (weight z) x * later z xs = _
    rw [ih]
    ring

/-- Guard triples in the order actually executed. The zero-degree empty
guards are kept. They have no endpoints and contribute zero on both sides. -/
def guardBlocks (prev : ℕ → List ℝ) (n : ℕ) : ℕ → List ℝ → List (List ℝ)
  | _, [] => []
  | j, a::as =>
    let g := prev (Schedule.guardSize n j)
    g :: [a] :: g :: guardBlocks prev n (j+1) as

def guardSum (z : ℝ) (prev : ℕ → List ℝ) (n : ℕ) : ℕ → List ℝ → ℝ
  | _, [] => 0
  | j, _::as => D z (prev (Schedule.guardSize n j)) + guardSum z prev n (j+1) as

theorem join_guardBlocks (prev : ℕ → List ℝ) (n j : ℕ) (as : List ℝ) :
    joinBlocks (guardBlocks prev n j as) = Schedule.splice prev n j as := by
  induction as generalizing j with
  | nil => rfl
  | cons a as ih =>
    simp only [guardBlocks, joinBlocks, Schedule.splice, ih, List.singleton_append]

theorem within_guardBlocks (z : ℝ) (prev : ℕ → List ℝ) (n j : ℕ) (as : List ℝ) :
    withinBlocks z (guardBlocks prev n j as) = 2 * guardSum z prev n j as := by
  induction as generalizing j with
  | nil => simp [guardBlocks, withinBlocks, guardSum]
  | cons a as ih =>
    have hone : D z [a] = 0 := by simp [D, pairSum, response]
    simp only [guardBlocks, withinBlocks, guardSum, ih, hone]
    ring

/-- Exact decomposition of the actual recursively guarded table into
the two copies' internal errors at each site and all pairs of distinct blocks. -/
theorem table_partition (z : ℝ) (k : ℕ) :
    D z (Schedule.table k) =
      2 * guardSum z (Schedule.history k) (2^k) 0 (Schedule.raw k) +
      acrossBlocks z (guardBlocks (Schedule.history k) (2^k) 0 (Schedule.raw k)) := by
  rw [Schedule.table_unfold, ← join_guardBlocks, partition_blocks, within_guardBlocks]

theorem factor_nonneg (z h : ℝ) : 0 ≤ factor z h := sq_nonneg _

theorem weight_nonneg {z h : ℝ} (hz : 0 ≤ z) (hh : 0 ≤ h) : 0 ≤ weight z h :=
  mul_nonneg hh (by linarith [mul_nonneg hz hh])

theorem product_nonneg (z : ℝ) (xs : List ℝ) : 0 ≤ product z xs := by
  induction xs with
  | nil => exact zero_le_one
  | cons h xs ih => exact mul_nonneg (factor_nonneg _ _) ih

theorem response_nonneg (z : ℝ) (r : ℝ → ℝ) (xs : List ℝ)
    (hr : ∀ h ∈ xs, 0 ≤ r h) : 0 ≤ response z r xs := by
  induction xs with
  | nil => exact le_rfl
  | cons h xs ih =>
    exact add_nonneg (hr h (by simp))
      (mul_nonneg (factor_nonneg _ _) (ih (fun t ht => hr t (by simp [ht]))))

theorem reverseResponse_nonneg (z : ℝ) (l : ℝ → ℝ) (xs : List ℝ)
    (hl : ∀ h ∈ xs, 0 ≤ l h) : 0 ≤ reverseResponse z l xs := by
  induction xs with
  | nil => exact le_rfl
  | cons h xs ih =>
    exact add_nonneg (mul_nonneg (hl h (by simp)) (product_nonneg z xs))
      (ih (fun t ht => hl t (by simp [ht])))

theorem pairSum_nonneg (z : ℝ) (l r : ℝ → ℝ) (xs : List ℝ)
    (hl : ∀ h ∈ xs, 0 ≤ l h) (hr : ∀ h ∈ xs, 0 ≤ r h) : 0 ≤ pairSum z l r xs := by
  induction xs with
  | nil => exact le_rfl
  | cons h xs ih =>
    have hl' : ∀ t ∈ xs, 0 ≤ l t := fun t ht => hl t (by simp [ht])
    have hr' : ∀ t ∈ xs, 0 ≤ r t := fun t ht => hr t (by simp [ht])
    exact add_nonneg (mul_nonneg (hl h (by simp)) (response_nonneg z r xs hr')) (ih hl' hr')

theorem response_mono (z : ℝ) (r s : ℝ → ℝ) (xs : List ℝ)
    (hrs : ∀ h ∈ xs, r h ≤ s h) : response z r xs ≤ response z s xs := by
  induction xs with
  | nil => exact le_rfl
  | cons h xs ih =>
    exact add_le_add (hrs h (by simp))
      (mul_le_mul_of_nonneg_left (ih (fun t ht => hrs t (by simp [ht]))) (factor_nonneg _ _))

theorem pairSum_mono (z : ℝ) (l r l' r' : ℝ → ℝ) (xs : List ℝ)
    (hl : ∀ h ∈ xs, l h ≤ l' h) (hr : ∀ h ∈ xs, r h ≤ r' h)
    (hlpos : ∀ h ∈ xs, 0 ≤ l' h) (hrpos : ∀ h ∈ xs, 0 ≤ r h) :
    pairSum z l r xs ≤ pairSum z l' r' xs := by
  induction xs with
  | nil => exact le_rfl
  | cons h xs ih =>
    have hr1 : ∀ t ∈ xs, r t ≤ r' t := fun t ht => hr t (by simp [ht])
    have hr0 : ∀ t ∈ xs, 0 ≤ r t := fun t ht => hrpos t (by simp [ht])
    apply add_le_add
    · exact mul_le_mul (hl h (by simp)) (response_mono z r r' xs hr1)
        (response_nonneg z r xs hr0) (hlpos h (by simp))
    · exact ih (fun t ht => hl t (by simp [ht])) hr1
        (fun t ht => hlpos t (by simp [ht])) hr0

/-- The squared entries of H have endpoint weights h_s and h_i.
For H-sharp the right weight is z*h_i^2. Both sums are bounded by D. -/
theorem squared_gains_le_D {z : ℝ} (hz : 0 ≤ z) (xs : List ℝ)
    (hx : ∀ h ∈ xs, 0 ≤ h) :
    pairSum z id id xs ≤ D z xs ∧ pairSum z id (fun h => z * h ^ 2) xs ≤ D z xs := by
  have hw : ∀ h ∈ xs, id h ≤ weight z h := by
    intro h hh
    dsimp [weight]
    nlinarith [mul_nonneg hz (sq_nonneg h)]
  have hw0 : ∀ h ∈ xs, 0 ≤ weight z h := fun h hh => weight_nonneg hz (hx h hh)
  have hsharp : ∀ h ∈ xs, z * h ^ 2 ≤ weight z h := by
    intro h hh
    unfold weight
    nlinarith [hx h hh]
  exact ⟨pairSum_mono z id id (weight z) (weight z) xs hw hw hw0 hx,
    pairSum_mono z id (fun h => z * h ^ 2) (weight z) (weight z) xs hw hsharp hw0
      (fun h _ => mul_nonneg hz (sq_nonneg h))⟩

theorem D_append (z : ℝ) (xs ys : List ℝ) :
    D z (xs ++ ys) = D z xs + D z ys +
      reverseResponse z (weight z) xs * response z (weight z) ys :=
  pairSum_append z (weight z) (weight z) xs ys

theorem D_snoc (z : ℝ) (xs : List ℝ) (a : ℝ) :
    D z (xs ++ [a]) = D z xs + reverseResponse z (weight z) xs * weight z a := by
  rw [D_append]
  simp [D, pairSum, response]

theorem weight_mono {z a b : ℝ} (hz : 0 ≤ z) (ha : 0 ≤ a) (hab : a ≤ b) :
    weight z a ≤ weight z b := by
  unfold weight
  exact mul_le_mul hab (add_le_add_left (mul_le_mul_of_nonneg_left hab hz) 1)
    (by linarith [mul_nonneg hz ha]) (le_trans ha hab)

theorem clippedLast_le {z a b : ℝ} (hz : 0 ≤ z) (ha : 0 ≤ a) (hab : a ≤ b)
    (xs : List ℝ) (hx : ∀ h ∈ xs, 0 ≤ h) :
    D z (xs ++ [a]) ≤ D z (xs ++ [b]) := by
  rw [D_snoc, D_snoc]
  exact add_le_add_left (mul_le_mul_of_nonneg_left (weight_mono hz ha hab)
    (reverseResponse_nonneg z (weight z) xs (fun h hh => weight_nonneg hz (hx h hh)))) _

theorem D_prefix_le {z : ℝ} (hz : 0 ≤ z) (xs ys : List ℝ)
    (hx : ∀ h ∈ xs, 0 ≤ h) (hy : ∀ h ∈ ys, 0 ≤ h) :
    D z xs ≤ D z (xs ++ ys) := by
  rw [D_append]
  have wx : ∀ h ∈ xs, 0 ≤ weight z h := fun h hh => weight_nonneg hz (hx h hh)
  have wy : ∀ h ∈ ys, 0 ≤ weight z h := fun h hh => weight_nonneg hz (hy h hh)
  have hD : 0 ≤ D z ys := pairSum_nonneg z _ _ ys wy wy
  linarith [mul_nonneg (reverseResponse_nonneg z _ xs wx) (response_nonneg z _ ys wy)]

/-- At zero normalized curvature twice D is exactly the square of the
total mass minus the sum of squares of the individual coefficients. -/
theorem response_zero (xs : List ℝ) : response 0 (weight 0) xs = xs.sum := by
  induction xs with
  | nil => rfl
  | cons h xs ih =>
    simp only [List.sum_cons]
    change weight 0 h + factor 0 h * response 0 (weight 0) xs = h + xs.sum
    rw [ih]
    simp [weight, factor]

theorem atZero_exact (xs : List ℝ) :
    2 * D 0 xs + (xs.map (fun h => h ^ 2)).sum = xs.sum ^ 2 := by
  induction xs with
  | nil => simp [D, pairSum]
  | cons h xs ih =>
    simp only [List.map_cons, List.sum_cons]
    change 2 * (weight 0 h * response 0 (weight 0) xs + D 0 xs) +
      (h ^ 2 + (xs.map (fun t => t ^ 2)).sum) = (h + xs.sum) ^ 2
    rw [response_zero]
    simp only [weight, zero_mul, add_zero, mul_one]
    nlinarith only [ih]

private theorem small_factor {z h : ℝ} (hz : 0 ≤ z) (hh : 0 ≤ h) (hsmall : z * h ≤ 1) :
    factor z h ≤ 1 := by
  unfold factor
  have h₂ : 0 ≤ 2 - z * h := by linarith
  nlinarith only [mul_nonneg (mul_nonneg hz hh) h₂]

private theorem small_weight {z h : ℝ} (hh : 0 ≤ h) (hsmall : z * h ≤ 1) :
    weight z h ≤ 2 * h := by
  unfold weight
  calc
    h * (1 + z * h) ≤ h * 2 := mul_le_mul_of_nonneg_left (by linarith) hh
    _ = 2 * h := mul_comm _ _

theorem response_small {z : ℝ} (hz : 0 ≤ z) (xs : List ℝ)
    (hs : ∀ h ∈ xs, 0 ≤ h ∧ z * h ≤ 1) : response z (weight z) xs ≤ 2 * xs.sum := by
  induction xs with
  | nil => simp [response]
  | cons h xs ih =>
    have hh := hs h (by simp)
    have ht : ∀ t ∈ xs, 0 ≤ t ∧ z * t ≤ 1 := fun t h' => hs t (by simp [h'])
    have hu := response_nonneg z (weight z) xs (fun t h' => weight_nonneg hz (ht t h').1)
    have hprod := mul_le_mul_of_nonneg_right (small_factor hz hh.1 hh.2) hu
    simp only [List.sum_cons]
    change weight z h + factor z h * response z (weight z) xs ≤ 2 * (h + xs.sum)
    linarith only [hprod, ih ht, small_weight hh.1 hh.2]

/-- A uniform squared-energy estimate for lists whose largest step satisfies
z*h ≤ 1. This covers the manuscript's low-frequency case. -/
theorem D_small {z : ℝ} (hz : 0 ≤ z) (xs : List ℝ)
    (hs : ∀ h ∈ xs, 0 ≤ h ∧ z * h ≤ 1) : D z xs ≤ 2 * xs.sum ^ 2 := by
  induction xs with
  | nil => simp [D, pairSum]
  | cons h xs ih =>
    have hh := hs h (by simp)
    have ht : ∀ t ∈ xs, 0 ≤ t ∧ z * t ≤ 1 := fun t h' => hs t (by simp [h'])
    have hu := response_nonneg z (weight z) xs (fun t h' => weight_nonneg hz (ht t h').1)
    have hcross := mul_le_mul (small_weight hh.1 hh.2) (response_small hz xs ht)
      hu (show 0 ≤ 2 * h by linarith [hh.1])
    simp only [List.sum_cons]
    change weight z h * response z (weight z) xs + D z xs ≤ 2 * (h + xs.sum) ^ 2
    nlinarith only [hcross, ih ht, sq_nonneg h]

/-- The scalar bound used for each of the three types of exceptional pair.
Taking a = q^2 gives the inequality in Appendix A.3. -/
theorem capped_weight {z a : ℝ} (hz : 0 < z) (ha : 0 ≤ a) :
    (1 + z * a) * min a z⁻¹ ≤ 2 * a := by
  have hid : z * z⁻¹ = 1 := by field_simp [ne_of_gt hz]
  by_cases h : a ≤ z⁻¹
  · rw [min_eq_left h]
    have hza := mul_le_mul_of_nonneg_left h hz.le
    rw [hid] at hza
    nlinarith only [mul_nonneg ha (sub_nonneg.mpr hza)]
  · rw [min_eq_right (le_of_lt (lt_of_not_ge h))]
    calc
      (1 + z * a) * z⁻¹ = z⁻¹ + a * (z * z⁻¹) := by ring
      _ ≤ 2 * a := by rw [hid, mul_one]; linarith

/-- The raw endpoint extension estimate in squared form. Multiplication by
the missing endpoint factor can thus be absorbed into a raw interval product. -/
theorem raw_endpoint {z a : ℝ} (hz : 0 < z) (ha : 0 ≤ a) :
    weight z a ≤ min a z⁻¹ * (2 + |1-z*a|)^2 := by
  have hid : z * z⁻¹ = 1 := by field_simp [ne_of_gt hz]
  have hza := mul_nonneg hz.le ha
  by_cases h : a ≤ z⁻¹
  · have hv := mul_le_mul_of_nonneg_left h hz.le
    rw [hid] at hv
    rw [min_eq_left h]
    apply mul_le_mul_of_nonneg_left _ ha
    nlinarith only [hv, abs_nonneg (1-z*a), sq_nonneg (|1-z*a|)]
  · have hv' := le_of_lt (lt_of_not_ge h)
    have hv := mul_le_mul_of_nonneg_left hv' hz.le
    rw [hid] at hv
    rw [min_eq_right hv', abs_of_nonpos (show 1-z*a ≤ 0 by linarith)]
    calc
      weight z a = z⁻¹ * (z*a*(1+z*a)) := by
        unfold weight
        field_simp [ne_of_gt hz] <;> ring
      _ ≤ z⁻¹ * ((1+z*a)^2) := by
        apply mul_le_mul_of_nonneg_left _ (inv_nonneg.mpr hz.le)
        nlinarith only [hza]
      _ = _ := by ring

/-- A nonempty guard of degree r with q² = 4nr compensates the raw
interval growth. Here t = √z; writing t explicitly avoids division by z. -/
theorem guard_attenuation {t n q r : ℝ} (ht : 0 ≤ t) (hn : 0 ≤ n)
    (hr : 0 ≤ r) (hscale : q ^ 2 = 4 * n * r) :
    1 + t ^ 2 * q ^ 2 ≤ (1 + 4 * n * t) * Real.sqrt (1 + t ^ 2 * r ^ 2) := by
  have hrad : 0 ≤ 1 + t ^ 2 * r ^ 2 := by positivity
  have hs := Real.sq_sqrt hrad
  have hnn := Real.sqrt_nonneg (1 + t ^ 2 * r ^ 2)
  have h₁ : 1 ≤ Real.sqrt (1 + t ^ 2 * r ^ 2) := by
    by_contra! hsmall
    have hp := mul_pos (sub_pos.mpr hsmall)
      (show 0 < 1 + Real.sqrt (1 + t ^ 2 * r ^ 2) by linarith)
    nlinarith only [hs, hp, sq_nonneg (t*r)]
  have h₂ : t * r ≤ Real.sqrt (1 + t ^ 2 * r ^ 2) := by
    by_contra! hn'
    have hc := mul_pos (sub_pos.mpr hn') (show 0 < t*r + Real.sqrt (1+t^2*r^2) by linarith)
    nlinarith only [hc, hs]
  have hmul := mul_le_mul_of_nonneg_left h₂ (show 0 ≤ 4*n*t by positivity)
  rw [hscale]
  nlinarith only [h₁, hmul]

/-- The analogous scalar estimate below the first nonempty guard scale. -/
theorem absent_guard {t n q : ℝ} (ht : 0 ≤ t) (ht' : t ≤ 1) (hn : 0 ≤ n)
    (hscale : q ^ 2 < 4 * n) : 1 + t ^ 2 * q ^ 2 ≤ 1 + 4 * n * t := by
  have ht₂ : t ^ 2 ≤ t := by nlinarith only [mul_nonneg ht (sub_nonneg.mpr ht')]
  have h₁ := mul_le_mul_of_nonneg_left hscale.le (sq_nonneg t)
  have h₂ := mul_le_mul_of_nonneg_right ht₂ (show 0 ≤ 4*n by linarith)
  nlinarith only [h₁, h₂]

/-- The summand at scale q divided by n/t is min(t*q, (t*q)⁻¹),
where t = √z. Its dyadic sum has a short rational telescoping bound. -/
def dyadicCost : ℕ → ℝ → ℝ
  | 0, _ => 0
  | k+1, x => min x x⁻¹ + dyadicCost k (2*x)

private theorem dyadic_term {x : ℝ} (hx : 0 < x) :
    min x x⁻¹ ≤ 6 / (1+x) - 6 / (1+2*x) := by
  have h₁ : 0 < 1+x := by linarith
  have h₂ : 0 < 1+2*x := by linarith
  have hd := mul_pos h₁ h₂
  have hb : min x x⁻¹ * ((1+x)*(1+2*x)) ≤ 6*x := by
    by_cases hh : x ≤ 1
    · have hprod : (1+x)*(1+2*x) ≤ 2*3 :=
        mul_le_mul (by linarith) (by linarith) h₂.le (by norm_num)
      calc
        _ ≤ x * ((1+x)*(1+2*x)) := mul_le_mul_of_nonneg_right (min_le_left _ _) hd.le
        _ ≤ x * (2*3) := mul_le_mul_of_nonneg_left hprod hx.le
        _ = 6*x := by ring
    · have hlarge : 1 ≤ x := le_of_lt (lt_of_not_ge hh)
      have hprod : (1+x)*(1+2*x) ≤ (2*x)*(3*x) :=
        mul_le_mul (by linarith) (by linarith) h₂.le (by positivity)
      calc
        _ ≤ x⁻¹ * ((1+x)*(1+2*x)) := mul_le_mul_of_nonneg_right (min_le_right _ _) hd.le
        _ ≤ x⁻¹ * ((2*x)*(3*x)) := mul_le_mul_of_nonneg_left hprod (inv_nonneg.mpr hx.le)
        _ = 6*x := by field_simp [ne_of_gt hx] <;> ring
  calc
    min x x⁻¹ ≤ 6*x / ((1+x)*(1+2*x)) := by
      first
      | exact (le_div_iff hd).2 hb
      | exact (le_div_iff₀ hd).2 hb
    _ = 6/(1+x) - 6/(1+2*x) := by
      field_simp [ne_of_gt h₁, ne_of_gt h₂] <;> ring

theorem dyadic_uniform (k : ℕ) (x : ℝ) (hx : 0 < x) :
    dyadicCost k x ≤ 6 / (1+x) := by
  induction k generalizing x with
  | zero =>
    change 0 ≤ 6 / (1+x)
    positivity
  | succ k ih =>
    change min x x⁻¹ + dyadicCost k (2*x) ≤ _
    linarith only [dyadic_term hx, ih (2*x) (by positivity)]

theorem dyadic_growth (k : ℕ) (x : ℝ) (hx : 0 ≤ x) :
    dyadicCost k x ≤ ((2 : ℝ)^k - 1) * x := by
  induction k generalizing x with
  | zero => simp [dyadicCost]
  | succ k ih =>
    change min x x⁻¹ + dyadicCost k (2*x) ≤ _
    rw [pow_succ]
    nlinarith only [min_le_left x x⁻¹, ih (2*x) (by positivity)]

/-- Sum of the site upper bounds (n/q) min(q², 1/t²), over k consecutive
dyadic scales beginning at q. -/
def scaleMass (n t : ℝ) : ℕ → ℝ → ℝ
  | 0, _ => 0
  | k+1, q => (n/q) * min (q^2) (t^2)⁻¹ + scaleMass n t k (2*q)

private theorem mul_min_eq {c : ℝ} (hc : 0 ≤ c) (a b : ℝ) :
    c * min a b = min (c*a) (c*b) := by
  by_cases h : a ≤ b
  · rw [min_eq_left h, min_eq_left (mul_le_mul_of_nonneg_left h hc)]
  · have h' := le_of_lt (lt_of_not_ge h)
    rw [min_eq_right h', min_eq_right (mul_le_mul_of_nonneg_left h' hc)]

theorem scaleMass_eq {n t : ℝ} (hn : 0 ≤ n) (ht : 0 < t) (k : ℕ) (q : ℝ) (hq : 0 < q) :
    scaleMass n t k q = (n/t) * dyadicCost k (t*q) := by
  induction k generalizing q with
  | zero => simp [scaleMass, dyadicCost]
  | succ k ih =>
    change n/q * min (q^2) (t^2)⁻¹ + scaleMass n t k (2*q) =
      n/t * (min (t*q) (t*q)⁻¹ + dyadicCost k (2*(t*q)))
    rw [ih (2*q) (by positivity), mul_add,
      mul_min_eq (div_nonneg hn hq.le), mul_min_eq (div_nonneg hn ht.le)]
    have hfirst : n/q * q^2 = n/t * (t*q) := by
      field_simp [ne_of_gt hq, ne_of_gt ht] <;> ring
    have hsecond : n/q * (t^2)⁻¹ = n/t * (t*q)⁻¹ := by
      field_simp [ne_of_gt hq, ne_of_gt ht] <;> ring_nf <;> simp
    rw [hfirst, hsecond, (show t*(2*q) = 2*(t*q) by ring)]

/-- The site-weight estimate in the paper, with the numerical constant 6.
For t = √z and n = 2^k it reads ∑ (n/q) min(q², 1/z) ≤ 6 min(n², n/√z). -/
theorem dyadic_weight_bound (k : ℕ) {t : ℝ} (ht : 0 < t) :
    scaleMass ((2 : ℝ)^k) t (k+1) 1 ≤ 6 * min (((2 : ℝ)^k)^2) ((2 : ℝ)^k / t) := by
  have hn : 0 ≤ (2 : ℝ)^k := by positivity
  have hmult := div_nonneg hn ht.le
  rw [scaleMass_eq hn ht (k+1) 1 (by norm_num), mul_one,
    mul_min_eq (show 0 ≤ (6 : ℝ) by norm_num)]
  apply le_min
  · have h := mul_le_mul_of_nonneg_left (dyadic_growth (k+1) t ht.le) hmult
    have heq : (2 : ℝ)^k/t * ((2^(k+1)-1)*t) = (2 : ℝ)^k * (2*(2:ℝ)^k-1) := by
      rw [pow_succ]
      field_simp [ne_of_gt ht] <;> ring
    rw [heq] at h
    nlinarith only [h, hn, sq_nonneg ((2:ℝ)^k)]
  · have h₁ : 6 / (1+t) ≤ (6 : ℝ) := by
      have hp : 0 < 1+t := by linarith
      first
      | exact (div_le_iff hp).2 (by linarith)
      | exact (div_le_iff₀ hp).2 (by linarith)
    have h := mul_le_mul_of_nonneg_left (le_trans (dyadic_uniform (k+1) t ht) h₁) hmult
    linarith only [h]

private theorem sum_dominates (v : ℕ → ℝ) (c : ℝ) (js : List ℕ)
    (h : ∀ j ∈ js, v j ≤ c * (j : ℝ)^4) :
    (js.map v).sum ≤ c * (js.map (fun j : ℕ => (j : ℝ)^4)).sum := by
  induction js with
  | nil => simp
  | cons j js ih =>
    simp only [List.map_cons, List.sum_cons, mul_add]
    exact add_le_add (h j (by simp)) (ih (fun k hk => h k (by simp [hk])))

/-- Algebraic end of the proof. Children count the two copies separately.
The total cross-block cost and fourth-moment contraction are inputs.
Establishing them for the actual guard layout is a separate claim. -/
theorem close_recursion (d : ℕ → ℝ) (children : ℕ → List ℕ) {c : ℝ} (hc : 0 ≤ c)
    (hlt : ∀ n r, r ∈ children n → r < n)
    (hfourth : ∀ n, ((children n).map (fun r : ℕ => (r : ℝ)^4)).sum ≤ (n : ℝ)^4 / 127)
    (hstep : ∀ n, d n ≤ c * (n : ℝ)^4 + ((children n).map d).sum) :
    ∀ n, d n ≤ (2 * c) * (n : ℝ)^4 := by
  intro n
  induction n using Nat.strong_induction_on with
  | h n ih =>
    have hsum := sum_dominates d (2*c) (children n) (fun r hr => ih r (hlt n r hr))
    have hm := mul_le_mul_of_nonneg_left (hfourth n) (show 0 ≤ 2*c by linarith)
    have hbudget : 0 ≤ c * (n : ℝ)^4 := mul_nonneg hc (by positivity)
    nlinarith only [hstep n, hsum, hm, hbudget]

open scoped BigOperators

def gcdMoment (n : ℕ) : ℝ := ∑ j ∈ Finset.range n, (Nat.gcd n (j+1) : ℝ)^8

private theorem even_split (f : ℕ → ℝ) (m : ℕ) :
    (∑ i ∈ Finset.range (2*m), f i) = ∑ j ∈ Finset.range m, (f (2*j) + f (2*j+1)) := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [show 2*(m+1) = (2*m+1)+1 by omega, Finset.sum_range_succ, Finset.sum_range_succ,
      Finset.sum_range_succ, ih]
    ring

private theorem gcdMoment_double (k : ℕ) :
    gcdMoment (2^(k+1)) = (2:ℝ)^k + 256*gcdMoment (2^k) := by
  have he : (2:ℕ)^(k+1) = 2*(2^k) := by rw [pow_succ, Nat.mul_comm]
  have hsite (j : ℕ) :
      (Nat.gcd (2*(2^k)) (2*j+1) : ℝ)^8 + (Nat.gcd (2*(2^k)) (2*j+1+1) : ℝ)^8 =
        1 + 256*(Nat.gcd (2^k) (j+1) : ℝ)^8 := by
    have ho : Odd (2*j+1) := ⟨j, rfl⟩
    have hcop := Nat.Coprime.pow_left (k+1) (Nat.coprime_two_left.mpr ho)
    rw [← he, hcop.gcd_eq_one, he, show 2*j+1+1 = 2*(j+1) by omega, Nat.gcd_mul_left]
    push_cast
    ring
  unfold gcdMoment
  rw [he, even_split]
  simp_rw [hsite]
  rw [Finset.sum_add_distrib, ← Finset.mul_sum]
  simp

theorem gcdMoment_bound (k : ℕ) :
    127*gcdMoment (2^k) + (2:ℝ)^k ≤ 128*((2:ℝ)^k)^8 := by
  induction k with
  | zero => norm_num [gcdMoment]
  | succ k ih =>
    rw [gcdMoment_double, pow_succ]
    have hp : 0 ≤ (2:ℝ)^k := by positivity
    nlinarith only [ih, hp]

private theorem guard_fourth_site (n j : ℕ) :
    (4*(n:ℝ))^4 * (Schedule.guardSize n j : ℝ)^4 ≤ (Nat.gcd n (j+1) : ℝ)^8 := by
  have h := Nat.div_mul_le_self ((Nat.gcd n (j+1))^2) (4*n)
  have h' : (Schedule.guardSize n j : ℝ) * (4*(n:ℝ)) ≤ (Nat.gcd n (j+1) : ℝ)^2 := by
    unfold Schedule.guardSize
    exact_mod_cast h
  have hp := pow_le_pow_left (show 0 ≤ (Schedule.guardSize n j : ℝ) * (4*(n:ℝ)) by positivity) h' 4
  nlinarith only [hp]

/-- Both copies of each nonempty guard counted, on the actual schedule:
the fourth moments contract by a factor of at most 1/127. -/
theorem guard_fourth_moment (k : ℕ) :
    2 * (∑ j ∈ Finset.range (2^k), (Schedule.guardSize (2^k) j : ℝ)^4) ≤ ((2:ℝ)^k)^4/127 := by
  have hsum := Finset.sum_le_sum (s := Finset.range (2^k))
    (fun j _ => guard_fourth_site (2^k) j)
  rw [← Finset.mul_sum] at hsum
  change (4*(↑((2:ℕ)^k) : ℝ))^4 * _ ≤ gcdMoment (2^k) at hsum
  push_cast at hsum
  apply (mul_le_mul_left (show 0 < (4*(2:ℝ)^k)^4 by positivity)).mp
  have hn : 0 ≤ (2:ℝ)^k := by positivity
  nlinarith only [hsum, gcdMoment_bound k, hn]

private theorem guardSum_majorant (z c : ℝ) (prev : ℕ → List ℝ) (n j : ℕ) (as : List ℝ)
    (hp : ∀ r : ℕ, D z (prev r) ≤ c*(r:ℝ)^4) :
    guardSum z prev n j as ≤ c * ∑ i ∈ Finset.range as.length,
      (Schedule.guardSize n (j+i) : ℝ)^4 := by
  induction as generalizing j with
  | nil => simp [guardSum]
  | cons a as ih =>
    rw [List.length_cons, Finset.sum_range_succ', mul_add]
    simp only [guardSum, Nat.add_zero]
    have ht := ih (j+1)
    have he (i : ℕ) : j+(i+1) = j+1+i := by omega
    have hsum : (∑ i ∈ Finset.range as.length, (Schedule.guardSize n (j+(i+1)):ℝ)^4) =
        ∑ i ∈ Finset.range as.length, (Schedule.guardSize n (j+1+i):ℝ)^4 :=
      Finset.sum_congr rfl (fun i _ => by rw [he i])
    rw [hsum]
    linarith only [hp (Schedule.guardSize n j), ht]

/-- For the actual schedule, an estimate on different-block pairs is sufficient.
Both same-block copies, the fourth-moment contraction, and the induction over
the guarded table are discharged here. -/
theorem table_D_of_across {z c : ℝ} (hc : 0 ≤ c)
    (hcross : ∀ k : ℕ, acrossBlocks z (guardBlocks (Schedule.history k) (2^k) 0
      (Schedule.raw k)) ≤ c*((2:ℝ)^k)^4) (k : ℕ) :
    D z (Schedule.table k) ≤ 2*c*((2:ℝ)^k)^4 := by
  have hb : ∀ level n : ℕ, D z (Schedule.history level n) ≤ 2*c*(n:ℝ)^4 := by
    intro level
    induction level with
    | zero =>
      intro n
      simp only [Schedule.history, D, pairSum]
      positivity
    | succ level ih =>
      intro n
      by_cases hn : n = 2^level
      · subst n
        change D z (Schedule.table level) ≤ _
        rw [table_partition]
        push_cast
        have hi := guardSum_majorant z (2*c) (Schedule.history level) (2^level) 0
          (Schedule.raw level) ih
        simp only [Schedule.raw_length, Nat.zero_add] at hi
        have hf := mul_le_mul_of_nonneg_left (guard_fourth_moment level)
          (show 0 ≤ 2*c by linarith)
        have hbudget : 0 ≤ c*((2:ℝ)^level)^4 := mul_nonneg hc (by positivity)
        nlinarith only [hi, hcross level, hf, hbudget]
      · rw [Schedule.history, if_neg hn]
        exact ih n
  simpa only [Schedule.table, Nat.cast_pow, Nat.cast_ofNat] using hb (k+1) (2^k)


/-- The stated paper constant 2 on the full guarded table at zero curvature. -/
theorem table_D_at_zero (k : ℕ) : D 0 (Schedule.table k) ≤ 2*((2:ℝ)^k)^4 := by
  have hmass := GuardSizes.table_mass k
  have hnon : 0 ≤ (Schedule.table k).sum := List.sum_nonneg
    (fun a ha => le_trans (by norm_num) (Schedule.table_lower k a ha))
  have hsq := pow_le_pow_left hnon hmass 2
  have hss : 0 ≤ ((Schedule.table k).map (fun a : ℝ => a^2)).sum := by
    apply List.sum_nonneg
    intro a ha
    obtain ⟨t, _, rfl⟩ := List.mem_map.mp ha
    exact sq_nonneg t
  nlinarith only [hsq, hss, atZero_exact (Schedule.table k)]

private theorem later_as_sum (z : ℝ) (bs : List (List ℝ)) :
    later z bs = ∑ j ∈ Finset.range bs.length,
      product z (joinBlocks (bs.take j)) * response z (weight z) (bs.getD j []) := by
  induction bs with
  | nil => simp [later]
  | cons b bs ih =>
    rw [List.length_cons, Finset.sum_range_succ']
    simp only [later, ih, List.getD_cons_zero, List.getD_cons_succ, List.take_succ_cons,
      List.take_zero, joinBlocks, product, one_mul, product_append]
    rw [Finset.mul_sum]
    ring_nf

def blockPair (z : ℝ) (bs : List (List ℝ)) (i t : ℕ) : ℝ :=
  reverseResponse z (weight z) (bs.getD i []) *
    (product z (joinBlocks (((bs.drop (i+1)).take t))) *
      response z (weight z) (bs.getD (i+1+t) []))

theorem across_as_sum (z : ℝ) (bs : List (List ℝ)) :
    acrossBlocks z bs = ∑ i ∈ Finset.range bs.length, ∑ t ∈ Finset.range (bs.length-(i+1)),
      blockPair z bs i t := by
  induction bs with
  | nil => simp [acrossBlocks]
  | cons b bs ih =>
    rw [List.length_cons, Finset.sum_range_succ']
    have hm : ∀ i t : ℕ, blockPair z (b::bs) (i+1) t = blockPair z bs i t := by
      intro i t
      unfold blockPair
      rw [show i+1+1+t = (i+1+t)+1 by omega]
      rfl
    simp only [hm, Nat.succ_sub_succ_eq_sub, Nat.sub_zero]
    rw [acrossBlocks, ih, add_comm, later_as_sum, Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    unfold blockPair
    rw [show 0+1+i = i+1 by omega]
    rfl

/-- With the slot convention 3j, 3j+1, 3j+2 the raw coefficient is in
the middle. If a pair includes that raw site and encloses neither adjacent
guard in its open interval, there are exactly three possible pairs. -/
theorem exceptional_slots {x y j : ℕ} (hxy : x < y) (hleft : x ≤ 3*j+1)
    (hright : 3*j+1 ≤ y) (h₁ : ¬(x < 3*j ∧ 3*j < y))
    (h₂ : ¬(x < 3*j+2 ∧ 3*j+2 < y)) :
    (x = 3*j ∧ y = 3*j+1) ∨ (x = 3*j+1 ∧ y = 3*j+2) ∨ (x = 3*j ∧ y = 3*j+2) := by omega

theorem guardBlocks_length (prev : ℕ → List ℝ) (n j : ℕ) (as : List ℝ) :
    (guardBlocks prev n j as).length = 3*as.length := by
  induction as generalizing j with
  | nil => rfl
  | cons a as ih =>
    simp only [guardBlocks, List.length_cons, ih]
    omega

theorem guardBlocks_site (prev : ℕ → List ℝ) (n j : ℕ) (as : List ℝ)
    (i : ℕ) (hi : i < as.length) :
    let bs := guardBlocks prev n j as
    let g := prev (Schedule.guardSize n (j+i))
    bs.getD (3*i) [] = g ∧ bs.getD (3*i+1) [] = [as.getD i 0] ∧ bs.getD (3*i+2) [] = g := by
  induction as generalizing i j with
  | nil => simp at hi
  | cons a as ih =>
    cases i with
    | zero => simp [guardBlocks]
    | succ i =>
      have ht : i < as.length := by simpa using hi
      have hh := ih (j+1) i ht
      rw [show 3*(i+1) = 3*i+1+1+1 by omega,
        show 3*i+1+1+1+1 = (3*i+1)+1+1+1 by omega,
        show 3*i+1+1+1+2 = (3*i+2)+1+1+1 by omega]
      dsimp only [guardBlocks]
      simp only [List.getD_cons_succ]
      simpa only [show j+(i+1) = j+1+i by omega] using hh

open GDProof.RawScales GDProof.Schedule

private def correct (k : ℕ) : ℕ → List (ℝ × ℕ) → Prop
  | _, [] => True
  | j, x::xs => x.2 = Nat.gcd (2^k) (j+1) ∧ correct k (j+1) xs

private theorem odd_site (k j : ℕ) : Nat.gcd (2^k) (2*j+1) = 1 :=
  Nat.Coprime.gcd_eq_one ((Nat.coprime_two_left.mpr (show Odd (2*j+1) from ⟨j,rfl⟩)).pow_left k)

private theorem even_site (k j : ℕ) : Nat.gcd (2^(k+1)) (2*j+1+1) = 2*Nat.gcd (2^k) (j+1) := by
  rw [pow_succ', show 2*j+1+1 = 2*(j+1) by omega, Nat.gcd_mul_left]

private theorem correct_children (k j : ℕ) (xs : List (ℝ × ℕ)) (hc : correct k j xs) :
    correct (k+1) (2*j) (tagChildren xs) := by
  induction xs generalizing j with
  | nil => trivial
  | cons x xs ih =>
    obtain ⟨a,q⟩ := x
    obtain ⟨hq,ht⟩ := hc
    change 1 = Nat.gcd (2^(k+1)) (2*j+1) ∧
      2*q = Nat.gcd (2^(k+1)) (2*j+1+1) ∧ correct (k+1) (2*j+1+1) (tagChildren xs)
    refine ⟨(odd_site _ _).symm, ?_, ?_⟩
    · simp only [even_site]; rw [←hq]
    · rw [show 2*j+1+1=2*(j+1) by omega]
      exact ih (j+1) ht

private theorem tail_correct (k : ℕ) : correct k 1 (tagTail k) := by
  induction k with
  | zero => trivial
  | succ k ih =>
    refine ⟨?_, correct_children k 1 _ ih⟩
    change 2 = Nat.gcd (2^(k+1)) 2
    simpa using (even_site k 0).symm

private theorem tagged_correct (k : ℕ) : correct k 0 (taggedRaw k) :=
  ⟨by simp, tail_correct k⟩

private theorem correct_get {k s : ℕ} {xs : List (ℝ × ℕ)} (hc : correct k s xs)
    (j : ℕ) (hj : j < xs.length) :
    (xs.getD j (0,0)).2 = Nat.gcd (2^k) (s+j+1) := by
  induction xs generalizing s j with
  | nil => simp at hj
  | cons h xs ih =>
    cases j with
    | zero => simpa using hc.1
    | succ j =>
      have h := ih hc.2 j (by simpa using hj)
      rw [List.getD_cons_succ, show s+(j+1)+1 = s+1+j+1 by omega]
      exact h

/-- At every physical raw index j the recursively generated scale is exactly
gcd(2^k,j+1), the label used in the implemented guard schedule. -/
theorem tagged_scale_eq_gcd (k j : ℕ) (hj : j < (taggedRaw k).length) :
    ((taggedRaw k).getD j (0,0)).2 = Nat.gcd (2^k) (j+1) := by
  simpa using correct_get (tagged_correct k) j hj

private theorem correct_cut {k s : ℕ} (l x r : List (ℝ × ℕ)) (h : correct k s (l ++ (x ++ r))) :
    correct k (s+l.length) x := by
  induction l generalizing s with
  | nil =>
    simp only [List.nil_append] at h
    simp only [List.length_nil, Nat.add_zero]
    induction x generalizing s with
    | nil => trivial
    | cons a x ih => exact ⟨h.1, ih h.2⟩
  | cons a l ih =>
    have hc := ih h.2
    simpa only [List.length_cons, show s+(l.length+1) = s+1+l.length by omega] using hc

/-- The arbitrary raw-interval bound driven by the same gcd values used by
guardSize at the physical raw indices. -/
theorem raw_local_gcd (k : ℕ) {z Q : ℝ} (hz : 0 ≤ z) (hz₁ : z ≤ 1)
    (l x r : List (ℝ × ℕ)) (he : taggedRaw k = l ++ (x ++ r))
    (hq : ∀ i : ℕ, i < x.length → ((Nat.gcd (2^k) (l.length+i+1)):ℝ) ≤ Q) :
    |GDProof.Prefix.prod z (vals x)| ≤ max 1 (2*Q^2*z) := by
  apply raw_local_interval k hz hz₁ l x r he
  have h := tagged_correct k
  rw [he] at h
  have hc := correct_cut l x r h
  simp only [Nat.zero_add] at hc
  intro u hu
  obtain ⟨i, hi⟩ := List.mem_iff_get.mp hu
  have heq := correct_get hc i.val i.isLt
  rw [List.getD_eq_get _ _ i.isLt, hi] at heq
  exact heq ▸ hq i.val i.isLt

/-- Capped size summed over all physical raw indices, before multiplying by
the endpoint constants or accounting for the two neighbouring copies. -/
def siteMass (k : ℕ) (t : ℝ) : ℝ := ∑ j ∈ Finset.range (2^k),
  min ((Nat.gcd (2^k) (j+1) : ℝ)^2) (t^2)⁻¹

private theorem cap_double {a t : ℝ} (ht : 0 < t) :
    min ((2*a)^2) (t^2)⁻¹ = 4*min (a^2) ((2*t)^2)⁻¹ := by
  rw [mul_min_eq (show 0 ≤ (4:ℝ) by norm_num)]
  have hg : (t^2)⁻¹ = 4*((2*t)^2)⁻¹ := by field_simp [ne_of_gt ht] <;> ring
  rw [show (2*a)^2 = 4*a^2 by ring, hg]

theorem siteMass_succ (k : ℕ) {t : ℝ} (ht : 0 < t) :
    siteMass (k+1) t = (2:ℝ)^k*min 1 (t^2)⁻¹ + 4*siteMass k (2*t) := by
  unfold siteMass
  conv_lhs => rw [pow_succ', even_split]
  have hp (j : ℕ) :
      min ((Nat.gcd (2*2^k) (2*j+1) : ℝ)^2) (t^2)⁻¹ +
        min ((Nat.gcd (2*2^k) (2*j+1+1) : ℝ)^2) (t^2)⁻¹ =
      min 1 (t^2)⁻¹ + 4*min ((Nat.gcd (2^k) (j+1) : ℝ)^2) ((2*t)^2)⁻¹ := by
    have ho : Odd (2*j+1) := ⟨j,rfl⟩
    have hcop := Nat.Coprime.pow_left (k+1) (Nat.coprime_two_left.mpr ho)
    rw [pow_succ'] at hcop
    rw [hcop.gcd_eq_one, show 2*j+1+1=2*(j+1) by omega, Nat.gcd_mul_left]
    push_cast
    rw [one_pow, cap_double ht]
  simp_rw [hp]
  rw [Finset.sum_add_distrib, ← Finset.mul_sum]
  simp

private theorem cap_one {t : ℝ} (ht : 0 < t) :
    min 1 (t^2)⁻¹ = t⁻¹*min t t⁻¹ := by
  rw [mul_min_eq (inv_nonneg.mpr ht.le)]
  congr 1 <;> field_simp [ne_of_gt ht] <;> ring

theorem siteMass_dyadic (k : ℕ) {t : ℝ} (ht : 0 < t) :
    siteMass k t ≤ ((2:ℝ)^k/t) * dyadicCost (k+1) t := by
  induction k generalizing t with
  | zero =>
    simp [siteMass, dyadicCost, cap_one ht, one_div]
  | succ k ih =>
    rw [siteMass_succ k ht, dyadicCost, pow_succ (2:ℝ) k]
    have hi := mul_le_mul_of_nonneg_left (ih (show 0 < 2*t by positivity)) (show 0≤(4:ℝ) by norm_num)
    have h₁ : (2:ℝ)^k/t*(min t t⁻¹) = (2:ℝ)^k*min 1 (t^2)⁻¹ := by
      rw [cap_one ht, div_eq_mul_inv, mul_assoc]
    have h₂ : 4*((2:ℝ)^k/(2*t)) = ((2:ℝ)^k*2/t) := by field_simp [ne_of_gt ht] <;> ring
    rw [← mul_assoc, h₂] at hi
    have hsmall : 0 ≤ (2:ℝ)^k*min 1 (t^2)⁻¹ := by positivity
    rw [mul_add]
    have he : (2:ℝ)^k*2/t*min t t⁻¹ = 2*((2:ℝ)^k/t*min t t⁻¹) := by ring
    rw [he,h₁]
    linarith only [hi,hsmall]

/-- All physical sites of the implemented dyadic schedule satisfy the
capped total-weight bound used in the good-pair summation. -/
theorem siteMass_bound (k : ℕ) {t : ℝ} (ht : 0 < t) :
    siteMass k t ≤ 6 * min (((2:ℝ)^k)^2) ((2:ℝ)^k/t) := by
  have h := scaleMass_eq (show 0 ≤ (2:ℝ)^k by positivity) ht (k+1) 1 (by norm_num)
  rw [mul_one] at h
  simpa only [h] using (siteMass_dyadic k ht).trans (h ▸ dyadic_weight_bound k ht)
/-- The full guarded table obeys the quartic kernel bound throughout the
low-frequency band, including its transition point. -/
theorem table_D_low (k : ℕ) {z : ℝ} (hz : 0 ≤ z) (hband : z*((2:ℝ)^k)^2 ≤ 1) :
    D z (Schedule.table k) ≤ 8*((2:ℝ)^k)^4 := by
  have hmax (a : ℝ) (ha : a ∈ Schedule.table k) : a ≤ ((2:ℝ)^k)^2 := by
    cases k with
    | zero =>
      have h : a = 1 := by simpa [Schedule.table_one] using ha
      simp [h]
    | succ k =>
      have h := GuardSizes.table_step_upper k ha
      nlinarith only [h, sq_nonneg ((2:ℝ)^(k+1))]
  have hnon : ∀ a ∈ Schedule.table k, (0:ℝ) ≤ a := fun a ha =>
    le_trans (by norm_num) (Schedule.table_lower k a ha)
  have hs := D_small hz (Schedule.table k)
    (fun a ha => ⟨hnon a ha, (mul_le_mul_of_nonneg_left (hmax a ha) hz).trans hband⟩)
  have hmass := pow_le_pow_left (List.sum_nonneg hnon) (GuardSizes.table_mass k) 2
  nlinarith only [hs, hmass]

end
end GDProof.Kernel
