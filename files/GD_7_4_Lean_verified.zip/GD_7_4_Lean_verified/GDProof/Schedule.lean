import Mathlib

/-! The dyadic index k denotes the paper's size n = 2^k. -/
namespace GDProof.Schedule

noncomputable section

def small (a : ℝ) : ℝ := 2 / (1 + Real.sqrt (1 - 1 / a))

def large (a : ℝ) : ℝ := 4 * a - small a

theorem pair_add (a : ℝ) : small a + large a = 4 * a := by
  unfold large
  ring

private theorem root_bounds {a : ℝ} (ha : 1 ≤ a) :
    0 ≤ Real.sqrt (1 - 1 / a) ∧ Real.sqrt (1 - 1 / a) ≤ 1 ∧
    a * (Real.sqrt (1 - 1 / a)) ^ 2 = a - 1 := by
  have ha' : 0 < a := by linarith
  have hr : 0 ≤ 1 - 1 / a := by
    have h : 1 / a ≤ 1 := by
      apply (div_le_iff ha').2
      linarith
    linarith
  have hsq := Real.sq_sqrt hr
  refine ⟨Real.sqrt_nonneg _, ?_, ?_⟩
  · have hinv : 0 ≤ (1 : ℝ) / a := by positivity
    nlinarith [sq_nonneg (Real.sqrt (1 - 1 / a) - 1)]
  · rw [hsq]
    field_simp [ne_of_gt ha']

theorem small_bounds {a : ℝ} (ha : 1 ≤ a) : 1 ≤ small a ∧ small a ≤ 2 := by
  obtain ⟨h₀, h₁, _⟩ := root_bounds ha
  have hden : 0 < 1 + Real.sqrt (1 - 1 / a) := by linarith
  unfold small
  constructor
  · apply (le_div_iff hden).2
    linarith
  · apply (div_le_iff hden).2
    linarith

theorem large_lower {a : ℝ} (ha : 1 ≤ a) : 2 ≤ large a := by
  have hs := (small_bounds ha).2
  unfold large
  linarith

theorem pair_mul {a : ℝ} (ha : 1 ≤ a) : small a * large a = 4 * a := by
  obtain ⟨h₀, _, hsq⟩ := root_bounds ha
  have hden : 0 < 1 + Real.sqrt (1 - 1 / a) := by linarith
  unfold large small
  generalize Real.sqrt (1 - 1 / a) = u at hsq hden ⊢
  field_simp [ne_of_gt hden]
  nlinarith [hsq]

theorem pair_product {a : ℝ} (ha : 1 ≤ a) (z : ℝ) :
    (1 - small a * z) * (1 - large a * z) = 1 - 4 * a * z * (1 - z) := by
  calc
    _ = 1 - (small a + large a) * z + (small a * large a) * z ^ 2 := by ring
    _ = _ := by rw [pair_add, pair_mul ha]; ring

def children : List ℝ → List ℝ
  | [] => []
  | a :: as => small a :: large a :: children as

/-- The tail after the leading coefficient 1. At the next level keep the first
coefficient of the tail, 2, and split each entry of the old tail. -/
def rawTail : ℕ → List ℝ
  | 0 => []
  | k + 1 => 2 :: children (rawTail k)

def raw (k : ℕ) : List ℝ := 1 :: rawTail k

theorem children_length (as : List ℝ) : (children as).length = 2 * as.length := by
  induction as with
  | nil => rfl
  | cons a as ih =>
    simp only [children, List.length_cons, ih]
    omega

theorem children_sum (as : List ℝ) : (children as).sum = 4 * as.sum := by
  induction as with
  | nil => simp [children]
  | cons a as ih =>
    simp only [children, List.sum_cons, ih]
    linarith [pair_add a]

theorem rawTail_length (k : ℕ) : (rawTail k).length + 1 = 2 ^ k := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [rawTail, List.length_cons, children_length, pow_succ]
    omega

theorem raw_length (k : ℕ) : (raw k).length = 2 ^ k := by
  simpa [raw] using rawTail_length k

theorem rawTail_sum (k : ℕ) : 3 * (rawTail k).sum + 2 = 2 * (4 : ℝ) ^ k := by
  induction k with
  | zero => norm_num [rawTail]
  | succ k ih =>
    simp only [rawTail, List.sum_cons, children_sum, pow_succ]
    linarith

theorem raw_sum (k : ℕ) : (raw k).sum = (2 * ((2 : ℝ) ^ k) ^ 2 + 1) / 3 := by
  have hpow : ((2 : ℝ) ^ k) ^ 2 = (4 : ℝ) ^ k := by
    rw [pow_two, ← mul_pow]
    norm_num
  simp only [raw, List.sum_cons, hpow]
  linarith [rawTail_sum k]

private theorem children_lower (as : List ℝ) (h : ∀ a ∈ as, (1 : ℝ) ≤ a) :
    ∀ b ∈ children as, (1 : ℝ) ≤ b := by
  induction as with
  | nil => simp [children]
  | cons a as ih =>
    have ha := h a (by simp)
    have ht : ∀ b ∈ as, (1 : ℝ) ≤ b := by
      intro b hb
      exact h b (by simp [hb])
    intro b hb
    simp only [children, List.mem_cons] at hb
    rcases hb with rfl | rfl | hb
    · exact (small_bounds ha).1
    · linarith [large_lower ha]
    · exact ih ht b hb

theorem rawTail_lower (k : ℕ) : ∀ a ∈ rawTail k, (1 : ℝ) ≤ a := by
  induction k with
  | zero => simp [rawTail]
  | succ k ih =>
    intro a ha
    simp only [rawTail, List.mem_cons] at ha
    rcases ha with rfl | ha
    · norm_num
    · exact children_lower _ ih _ ha

theorem raw_lower (k : ℕ) : ∀ a ∈ raw k, (1 : ℝ) ≤ a := by
  intro a ha
  simp only [raw, List.mem_cons] at ha
  rcases ha with rfl | ha
  · exact le_rfl
  · exact rawTail_lower _ _ ha

/-- On the raw indices 0 ≤ j < n for dyadic n, gcd(n,j+1) is the
largest power of two dividing j+1. Natural division implements the cutoff. -/
def guardSize (n j : ℕ) : ℕ := (Nat.gcd n (j + 1)) ^ 2 / (4 * n)

def splice (previous : ℕ → List ℝ) (n : ℕ) : ℕ → List ℝ → List ℝ
  | _, [] => []
  | j, a :: as =>
    let guard := previous (guardSize n j)
    guard ++ (a :: (guard ++ splice previous n (j + 1) as))

/-- Store tables for physical sizes 1,...,2^(k-1) at their dyadic keys.
All missing keys, including the sentinel size zero, refer to the empty table. -/
def history : ℕ → ℕ → List ℝ
  | 0, _ => []
  | k + 1, n =>
    if n = 2 ^ k then splice (history k) n 0 (raw k) else history k n

def table (k : ℕ) : List ℝ := history (k + 1) (2 ^ k)

theorem table_unfold (k : ℕ) : table k = splice (history k) (2 ^ k) 0 (raw k) := by
  simp [table, history]

theorem history_zero (k : ℕ) : history k 0 = [] := by
  induction k with
  | zero => rfl
  | succ k ih =>
    have h : 0 < (2 : ℕ) ^ k := by positivity
    simp [history, ne_of_lt h, ih]

theorem history_at {j k : ℕ} (hj : j < k) : history k (2 ^ j) = table j := by
  induction k with
  | zero => omega
  | succ k ih =>
    by_cases he : j = k
    · subst j
      rfl
    · have hjk : j < k := by omega
      have hp : (2 : ℕ) ^ j < 2 ^ k := by
        exact pow_lt_pow_right (by decide : 1 < (2 : ℕ)) hjk
      simp [history, ne_of_lt hp, ih hjk]

theorem guardSize_lt {n : ℕ} (hn : 0 < n) (j : ℕ) : guardSize n j < n := by
  have hg := Nat.le_of_dvd hn (Nat.gcd_dvd_left n (j + 1))
  have hs := Nat.mul_le_mul hg hg
  have hpos := Nat.mul_pos hn hn
  unfold guardSize
  apply (Nat.div_lt_iff_lt_mul (by omega : 0 < 4 * n)).2
  rw [pow_two]
  nlinarith

private theorem splice_lower (previous : ℕ → List ℝ) (n : ℕ)
    (hg : ∀ r a, a ∈ previous r → (1 : ℝ) ≤ a) (j : ℕ) (as : List ℝ)
    (hs : ∀ a ∈ as, (1 : ℝ) ≤ a) : ∀ a ∈ splice previous n j as, (1 : ℝ) ≤ a := by
  induction as generalizing j with
  | nil => simp [splice]
  | cons b as ih =>
    intro a ha
    simp only [splice, List.mem_append, List.mem_cons] at ha
    rcases ha with ha | rfl | ha | ha
    · exact hg _ _ ha
    · exact hs a (by simp)
    · exact hg _ _ ha
    · exact ih (j + 1) (fun c hc => hs c (by simp [hc])) _ ha

theorem history_lower (k : ℕ) : ∀ n a, a ∈ history k n → (1 : ℝ) ≤ a := by
  induction k with
  | zero => simp [history]
  | succ k ih =>
    intro n a ha
    by_cases h : n = 2 ^ k
    · simp only [history, if_pos h] at ha
      exact splice_lower _ _ ih _ _ (raw_lower k) a ha
    · simp only [history, if_neg h] at ha
      exact ih _ _ ha

theorem table_lower (k : ℕ) : ∀ a ∈ table k, (1 : ℝ) ≤ a := history_lower _ _

private theorem splice_sum_lower (previous : ℕ → List ℝ) (n : ℕ)
    (hg : ∀ r, (0 : ℝ) ≤ (previous r).sum) (j : ℕ) (as : List ℝ) :
    as.sum ≤ (splice previous n j as).sum := by
  induction as generalizing j with
  | nil => simp [splice]
  | cons a as ih =>
    simp only [splice, List.sum_append, List.sum_cons]
    linarith [hg (guardSize n j), ih (j + 1)]

theorem table_sum_lower (k : ℕ) :
    (2 * ((2 : ℝ) ^ k) ^ 2 + 1) / 3 ≤ (table k).sum := by
  rw [← raw_sum, table_unfold]
  apply splice_sum_lower
  intro r
  have hnon : ∀ xs : List ℝ, (∀ a ∈ xs, (0 : ℝ) ≤ a) → 0 ≤ xs.sum := by
    intro xs
    induction xs with
    | nil => simp
    | cons a xs ih =>
      intro h
      rw [List.sum_cons]
      exact add_nonneg (h a (by simp)) (ih (fun b hb => h b (by simp [hb])))
  exact hnon _ (fun a ha => le_trans (by norm_num) (history_lower k r a ha))

theorem table_one : table 0 = [1] := by rfl
theorem table_two : table 1 = [1, 2] := by rfl
theorem table_four : table 2 = [1, 2, small 2, 1, large 2, 1] := by rfl

end

end GDProof.Schedule
