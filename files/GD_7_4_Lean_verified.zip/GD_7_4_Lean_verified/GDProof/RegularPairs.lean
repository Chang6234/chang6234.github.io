import GDProof.Kernel
import GDProof.GuardDecay
import GDProof.SlotWeight
import GDProof.RegularAlgebra

namespace GDProof.RegularPairs
open GDProof.Kernel GDProof.Prefix GDProof.GuardSizes GDProof.Schedule GDProof.RawScales
noncomputable section

/-- Number of raw slots strictly before a given guard-triple position. -/
def before (i : ℕ) := (i+1)/3

private theorem before_succ (i : ℕ) : before (i+1) = before i + (if i%3 = 1 then 1 else 0) := by
  unfold before
  split <;> omega

private theorem before_le (a b : ℕ) (h : a ≤ b) : before a ≤ before b := by
  unfold before
  omega

def scalarProd (f : ℕ → ℝ) (s : ℕ) : ℕ → ℝ
  | 0 => 1
  | l+1 => f (s+l) * scalarProd f s l

private theorem scalarProd_mul (f g : ℕ → ℝ) (s l : ℕ) :
    scalarProd (fun j => f j*g j) s l = scalarProd f s l * scalarProd g s l := by
  induction l with
  | zero => simp [scalarProd]
  | succ l ih => simp only [scalarProd, ih]; ring

private theorem scalarProd_ext {f g : ℕ → ℝ} (s l : ℕ)
    (h : ∀ i, s ≤ i → i < s+l → f i = g i) : scalarProd f s l = scalarProd g s l := by
  induction l with
  | zero => rfl
  | succ l ih =>
    rw [scalarProd, scalarProd, h (s+l) (by omega) (by omega), ih]
    exact fun i h₁ h₂ => h i h₁ (by omega)

private theorem scalarProd_cons (f : ℕ → ℝ) (s l : ℕ) :
    scalarProd f s (l+1) = f s * scalarProd f (s+1) l := by
  induction l with
  | zero => simp [scalarProd]
  | succ l ih =>
    change f (s+(l+1)) * scalarProd f s (l+1) = f s * (f ((s+1)+l)*scalarProd f (s+1) l)
    rw [ih,show s+(l+1)=s+1+l by omega]
    ring

theorem scalarProd_le_one (f : ℕ → ℝ) (s l : ℕ)
    (hf : ∀ i, s ≤ i → i < s+l → |f i| ≤ 1) : |scalarProd f s l| ≤ 1 := by
  induction l with
  | zero => simp [scalarProd]
  | succ l ih =>
    rw [scalarProd,abs_mul]
    exact mul_le_one (hf (s+l) (by omega) (by omega)) (abs_nonneg _)
      (ih (fun i h₁ h₂ => hf i h₁ (by omega)))

theorem scalarProd_pick (f : ℕ → ℝ) (s l i : ℕ) (hl : s ≤ i) (hr : i < s+l)
    (hf : ∀ j, s ≤ j → j < s+l → |f j| ≤ 1) : |scalarProd f s l| ≤ |f i| := by
  induction l with
  | zero => omega
  | succ l ih =>
    rw [scalarProd,abs_mul]
    have htail : ∀ j, s ≤ j → j < s+l → |f j| ≤ 1 := fun j h₁ h₂ => hf j h₁ (by omega)
    by_cases hi : i = s+l
    · rw [hi]
      simpa using mul_le_mul_of_nonneg_left (scalarProd_le_one f s l htail) (abs_nonneg (f (s+l)))
    · have h := mul_le_mul (hf (s+l) (by omega) (by omega)) (ih (by omega) htail)
        (abs_nonneg _) zero_le_one
      simpa using h

private theorem scalarProd_shift (f : ℕ → ℝ) (s l : ℕ) :
    scalarProd f (s+1) l = scalarProd (fun j => f (j+1)) s l := by
  induction l with
  | zero => rfl
  | succ l ih => simp only [scalarProd, ih, show s+1+l=s+l+1 by omega]

private theorem list_slice {α : Type*} (a₀ : α) (f : α → ℝ) (w : List α) (s l : ℕ)
    (hl : s+l ≤ w.length) :
    (((w.drop s).take l).map f).prod = scalarProd (fun j => f (w.getD j a₀)) s l := by
  induction s generalizing w l with
  | zero =>
    induction l generalizing w with
    | zero => simp [scalarProd]
    | succ l ih =>
      cases w with
      | nil => simp at hl
      | cons a w =>
        rw [scalarProd_cons, scalarProd_shift]
        have ht : 0 + l ≤ w.length := by simp at hl; omega
        simp only [Nat.zero_add, List.drop_zero, List.take_succ_cons, List.map_cons, List.prod_cons,
          List.getD_cons_zero, List.getD_cons_succ]
        simpa using congrArg (fun y => f a * y) (ih w ht)
  | succ s ih =>
    cases w with
    | nil => simp at hl
    | cons h w =>
      have ht : s+l ≤ w.length := by simp at hl; omega
      simpa only [List.drop_succ_cons, scalarProd_shift (fun j => f ((h::w).getD j a₀)) s l,
        List.getD_cons_succ] using (ih w l ht)

private theorem prod_map (z : ℝ) (w : List ℝ) : prod z w = (w.map (fun a => 1-z*a)).prod := by
  induction w with
  | nil => rfl
  | cons a w ih => simp [prod,ih]

private theorem slice_prod (z : ℝ) (w : List ℝ) (s l : ℕ) (hl : s+l ≤ w.length) :
    prod z ((w.drop s).take l) = scalarProd (fun j => 1-z*w.getD j 0) s l := by
  rw [prod_map]
  exact list_slice 0 _ _ _ _ hl

private theorem tags_length (k : ℕ) : (taggedRaw k).length = 2^k := by
  simpa [vals, raw_length] using congrArg List.length (taggedRaw_vals k)

private theorem raw_slice (k : ℕ) {z Q : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (s l : ℕ) (hl : s+l ≤ 2^k)
    (hq : ∀ j : ℕ, s ≤ j → j < s+l → (Nat.gcd (2^k) (j+1) : ℝ) ≤ Q) :
    |scalarProd (fun j => 1-z*(raw k).getD j 0) s l| ≤ max 1 (2*Q^2*z) := by
  let tags := taggedRaw k
  let left := tags.take s
  let mid := (tags.drop s).take l
  let right := (tags.drop s).drop l
  have hs : left.length = s := by
    simp [left,tags,List.length_take,tags_length, Nat.min_eq_left (show s ≤ 2^k by omega)]
  have hmid : mid.length ≤ l := by simp [mid,List.length_take]
  have he : tags = left ++ (mid ++ right) := by
    dsimp [left,mid,right]; rw [List.take_append_drop,List.take_append_drop]
  have hp := raw_local_gcd k hz h₁ left mid right he (fun i hi => by
    rw [hs]; exact hq (s+i) (by omega) (by omega))
  have hval : vals mid = ((raw k).drop s).take l := by
    rw [←taggedRaw_vals]; simp [mid,tags,vals,List.map_take,List.map_drop]
  rw [hval,slice_prod] at hp
  · exact hp
  · simpa [raw_length] using hl

def rawFactor (k : ℕ) (z : ℝ) (i : ℕ) :=
  if i%3=1 then 1-z*(raw k).getD (i/3) 0 else 1

def guardFactor (k : ℕ) (z : ℝ) (i : ℕ) :=
  if i%3=1 then 1 else prod z (history k (guardSize (2^k) (i/3)))

private theorem raw_slot_interval (k : ℕ) (z : ℝ) (s l : ℕ) :
    scalarProd (rawFactor k z) s l =
      scalarProd (fun j => 1-z*(raw k).getD j 0) (before s) (before (s+l)-before s) := by
  induction l with
  | zero => simp [scalarProd]
  | succ l ih =>
    rw [scalarProd,ih, show s+(l+1) = (s+l)+1 by omega, before_succ]
    have hle := before_le s (s+l) (by omega)
    by_cases hm : (s+l)%3=1
    · rw [if_pos hm, show before (s+l)+1-before s = (before (s+l)-before s)+1 by omega,
        scalarProd, rawFactor, if_pos hm, show before s+(before (s+l)-before s) = (s+l)/3 by
          unfold before at *; omega]
    · rw [if_neg hm, Nat.add_zero,rawFactor,if_neg hm,one_mul]

private theorem slot_eq (k i : ℕ) (z : ℝ) (hi : i < 3*2^k) :
    prod z ((guardBlocks (history k) (2^k) 0 (raw k)).getD i []) =
      rawFactor k z i * guardFactor k z i := by
  have hn : i / 3 < (raw k).length := by rw [raw_length]; omega
  obtain ⟨h₀,h₁,h₂⟩ := guardBlocks_site (history k) (2^k) 0 (raw k) (i/3) hn
  simp only [Nat.zero_add] at h₀ h₂
  by_cases h : i%3=1
  · have hh : 3*(i/3)+1=i := by omega
    rw [hh] at h₁
    simp [h₁,rawFactor,guardFactor,h,prod]
  · by_cases hv : i%3=0
    · have hh : 3*(i/3)=i := by omega
      rw [hh] at h₀
      simp [h₀,rawFactor,guardFactor,h]
    · have hh : 3*(i/3)+2=i := by omega
      rw [hh] at h₂
      simp [h₂,rawFactor,guardFactor,h]

private theorem guard_le (k : ℕ) {z : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1) (i : ℕ) :
    |guardFactor k z i| ≤ 1 := by
  unfold guardFactor
  split
  · norm_num
  · obtain ⟨hs,hn⟩ := Guarded.history_stable k (guardSize (2^k) (i/3)) z hz h₁
    have hsq := GuardDecay.stable_prod_sq _ hz hs hn
    exact abs_le.mpr ⟨by nlinarith [sq_nonneg (prod z (history k (guardSize (2^k) (i/3)))+1)],
      by nlinarith [sq_nonneg (prod z (history k (guardSize (2^k) (i/3)))-1)]⟩

private theorem raw_window (k x y : ℕ) {z Q : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (hy : y < 3*2^k)
    (hq : ∀ j : ℕ, x ≤ 3*j+1 → 3*j+1 ≤ y → (Nat.gcd (2^k) (j+1) : ℝ) ≤ Q)
    (s l : ℕ) (hs : x ≤ s) (hl : s+l ≤ y+1) :
    |scalarProd (rawFactor k z) s l| ≤ max 1 (2*Q^2*z) := by
  rw [raw_slot_interval]
  apply raw_slice k hz h₁
  · unfold before
    omega
  · intro j hj₁ hj₂
    apply hq j <;> unfold before at * <;> omega

private theorem interval_expand (f : ℕ → ℝ) (x t : ℕ) (B : ℝ)
    (hb : ∀ s l, x ≤ s → s+l ≤ x+1+t+1 → |scalarProd f s l| ≤ B) :
    (2+|f x|)*|scalarProd f (x+1) t| *(2+|f (x+1+t)|) ≤ 9*B := by
  have h0 := hb (x+1) t (by omega) (by omega)
  have hleft := hb x (t+1) le_rfl (by omega)
  rw [scalarProd_cons,abs_mul] at hleft
  have hright := hb (x+1) (t+1) (by omega) (by omega)
  rw [scalarProd,abs_mul] at hright
  have hboth := hb x ((t+1)+1) le_rfl (by omega)
  rw [scalarProd_cons] at hboth
  change |f x * (f (x+1+t) * scalarProd f (x+1) t)| ≤ B at hboth
  rw [abs_mul,abs_mul] at hboth
  nlinarith only [h0,hleft,hright,hboth]

private theorem guard_damps (k x t j : ℕ) (z : ℝ) (hz : 0 < z) (h₁ : z ≤ 1)
    (he : x/3 ≠ (x+1+t)/3) (hj₁ : x ≤ 3*j+1) (hj₂ : 3*j+1 ≤ x+1+t) :
    max 1 (2*(Nat.gcd (2^k) (j+1):ℝ)^2*z) * |scalarProd (guardFactor k z) (x+1) t| ≤
      2*(1+4*((2:ℝ)^k)*Real.sqrt z) := by
  let q : ℝ := Nat.gcd (2^k) (j+1)
  let n := (2:ℝ)^k
  let v := Real.sqrt z
  let T := |scalarProd (guardFactor k z) (x+1) t|
  have hn : 0 < n := by dsimp [n]; positivity
  have hv : 0 < v := Real.sqrt_pos.2 hz
  have hv₁ : v ≤ 1 := Real.sqrt_le_one.2 h₁
  have hvs : v^2 = z := Real.sq_sqrt hz.le
  have ht : T ≤ 1 := scalarProd_le_one _ _ _ (fun i _ _ => guard_le k hz.le h₁ i)
  have ht0 : 0 ≤ T := abs_nonneg _
  have hbase : T ≤ 2*(1+4*n*v) := by nlinarith only [ht, mul_nonneg hn.le hv.le]
  change max 1 (2*q^2*z)*T ≤ 2*(1+4*n*v)
  rw [max_mul_of_nonneg _ _ ht0, one_mul, max_le_iff]
  refine ⟨hbase,?_⟩
  rcases guard_cases k j with ⟨_,hsmall⟩ | ⟨e,_,hr,hlarge,hist⟩
  · have hsmall' : q^2 < 4*n := by dsimp [q,n]; exact_mod_cast hsmall
    have hz' : z ≤ v := by nlinarith only [hvs, mul_nonneg hv.le (sub_nonneg.mpr hv₁)]
    calc
      2*q^2*z*T ≤ 2*q^2*z*1 := mul_le_mul_of_nonneg_left ht (by positivity)
      _ ≤ 2*(4*n)*v := by
        rw [mul_one, mul_assoc, mul_assoc]
        exact mul_le_mul_of_nonneg_left (mul_le_mul hsmall'.le hz' hz.le (by positivity)) (by norm_num)
      _ ≤ _ := by linarith
  · have hpidx : (x < 3*j ∧ 3*j < x+1+t) ∨ (x < 3*j+2 ∧ 3*j+2 < x+1+t) := by omega
    have hguard : T ≤ |prod z (table e)| := by
      rcases hpidx with ⟨ha,hb⟩ | ⟨_ha,hb⟩
      · have h := scalarProd_pick (guardFactor k z) (x+1) t (3*j) (by omega) hb
          (fun i _ _ => guard_le k hz.le h₁ i)
        simpa only [T,guardFactor,show 3*j%3 ≠ 1 by omega,if_false,
          show 3*j/3=j by omega,hist] using h
      · have h := scalarProd_pick (guardFactor k z) (x+1) t (3*j+2) (by omega) hb
          (fun i _ _ => guard_le k hz.le h₁ i)
        simpa only [T,guardFactor,show (3*j+2)%3 ≠ 1 by omega,if_false,
          show (3*j+2)/3=j by omega,hist] using h
    have hraw : |prod z (table e)| ≤ |prod z (raw e)| := by
      have hsq := GuardDecay.table_le_raw e z hz.le h₁
      exact sq_le_sq.mp hsq
    have hdecay := (hguard.trans hraw).trans (RawProduct.raw_product_decay e z hz h₁)
    change T ≤ 1 / (2*(2:ℝ)^e*v) at hdecay
    have hpt := (le_div_iff (show 0 < 2*(2:ℝ)^e*v by positivity)).1 hdecay
    rw [hr] at hlarge
    have heq : q^2 = 4*n*(2:ℝ)^e := by dsimp [q,n]; exact_mod_cast hlarge
    rw [heq,← hvs]
    have hh := mul_le_mul_of_nonneg_left hpt (show 0 ≤ 4*n*v by positivity)
    nlinarith only [hh,mul_nonneg hn.le hv.le]

/-- In a cross-site pair, both possibly raw endpoint factors and all unweighted
intermediate factors can be accounted for with one absolute constant. -/
theorem regular_product (k x t : ℕ) {z : ℝ} (hz : 0 < z) (h₁ : z ≤ 1)
    (hy : x+1+t < 3*2^k) (he : x/3 ≠ (x+1+t)/3) :
    (2+|rawFactor k z x|)*|scalarProd (rawFactor k z) (x+1) t| *(2+|rawFactor k z (x+1+t)|)*
      |scalarProd (guardFactor k z) (x+1) t| ≤ 18*(1+4*((2:ℝ)^k)*Real.sqrt z) := by
  classical
  let I := (Finset.range (2^k)).filter fun j => x ≤ 3*j+1 ∧ 3*j+1 ≤ x+1+t
  have hI (j : ℕ) : j ∈ I ↔ x ≤ 3*j+1 ∧ 3*j+1 ≤ x+1+t := by
    simp only [I,Finset.mem_filter,Finset.mem_range]
    omega
  by_cases hne : I.Nonempty
  · obtain ⟨j,hj,hmax⟩ := I.exists_max_image (fun j => Nat.gcd (2^k) (j+1)) hne
    have hw := raw_window k x (x+1+t) hz.le h₁ hy (Q:=(Nat.gcd (2^k) (j+1):ℝ))
      (fun p hxl hxr => by exact_mod_cast hmax p ((hI p).mpr ⟨hxl,hxr⟩))
    have hp := interval_expand _ x t _ hw
    have hm := mul_le_mul_of_nonneg_right hp (abs_nonneg (scalarProd (guardFactor k z) (x+1) t))
    have hd := guard_damps k x t j z hz h₁ he ((hI j).mp hj).1 ((hI j).mp hj).2
    linarith only [hm,hd]
  · have hw := raw_window k x (x+1+t) hz.le h₁ hy (Q:=0)
      (fun p hxl hxr => False.elim (hne ⟨p,(hI p).mpr ⟨hxl,hxr⟩⟩))
    have hp := interval_expand _ x t _ hw
    norm_num at hp
    have ht := scalarProd_le_one (guardFactor k z) (x+1) t (fun i _ _ => guard_le k hz.le h₁ i)
    have hm := mul_le_mul hp ht (abs_nonneg _) (by norm_num)
    have hn : 0 ≤ ((2:ℝ)^k)*Real.sqrt z := by positivity
    linarith only [hm,hn]

private theorem product_square (z : ℝ) (w : List ℝ) : product z w = (prod z w)^2 := by
  induction w with
  | nil => norm_num [prod,product]
  | cons a w ih => simp [prod,product,factor,ih,mul_pow]

private theorem join_prod (z : ℝ) (bs : List (List ℝ)) :
    prod z (joinBlocks bs) = (bs.map (prod z)).prod := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp only [joinBlocks,prod_append,List.map_cons,List.prod_cons,ih]

private theorem middle_product (k s l : ℕ) (z : ℝ) (hs : s+l ≤ 3*2^k) :
    let bs := guardBlocks (history k) (2^k) 0 (raw k)
    product z (joinBlocks ((bs.drop s).take l)) =
      (scalarProd (rawFactor k z) s l * scalarProd (guardFactor k z) s l)^2 := by
  dsimp only
  let bs := guardBlocks (history k) (2^k) 0 (raw k)
  have hl : s+l ≤ bs.length := by simpa [bs,guardBlocks_length,raw_length] using hs
  rw [product_square,join_prod,list_slice [] (prod z) bs s l hl,← scalarProd_mul]
  congr 1
  apply scalarProd_ext
  intro i _ hi
  exact slot_eq k i z (by omega)


/-- Uniform cross-site estimate for the actual list of triples in the guarded table. -/
theorem bound :
    ∃ K : ℝ, 0 < K ∧ ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 → ∀ x l : ℕ,
      x+1+l < 3*2^k → x/3 ≠ (x+1+l)/3 →
      blockPair z (guardBlocks (history k) (2^k) 0 (raw k)) x l ≤
        K*(1+4*((2:ℝ)^k)*Real.sqrt z)^2 *
          min ((Nat.gcd (2^k) (x/3+1):ℝ)^2) z⁻¹ *
          min ((Nat.gcd (2^k) ((x+1+l)/3+1):ℝ)^2) z⁻¹ := by
  obtain ⟨C,hC,hslot⟩ := SlotWeight.bound
  have hc : 0 < C := by linarith
  refine ⟨(18*C)^2,by positivity,?_⟩
  intro k z hz h₁ x l hy hdiff
  let y := x+1+l
  let bs := guardBlocks (history k) (2^k) 0 (raw k)
  have hn : 0 ≤ response z (weight z) (bs.getD y []) :=
    response_nonneg _ _ _ (fun a ha => weight_nonneg hz.le (Endpoint.block_nonnegative k y a ha))
  have hleft := (max_le_iff.mp (hslot k z hz h₁ x (by omega))).2
  have hright := (max_le_iff.mp (hslot k z hz h₁ y hy)).1
  have hpair := RegularAlgebra.regular_pair hn
    (le_min (sq_nonneg _) (inv_nonneg.mpr hz.le)) (le_min (sq_nonneg _) (inv_nonneg.mpr hz.le))
    hc.le hleft hright (regular_product k x l hz h₁ hy hdiff)
  unfold blockPair
  rw [middle_product k (x+1) l z (by omega)]
  exact hpair

end
end GDProof.RegularPairs
