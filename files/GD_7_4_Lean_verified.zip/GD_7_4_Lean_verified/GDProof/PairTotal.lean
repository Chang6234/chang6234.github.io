import GDProof.Kernel
import GDProof.GuardSizes

namespace GDProof.PairTotal

open Finset
open scoped BigOperators

theorem sum_triples (f : ℕ → ℝ) (n : ℕ) :
    (∑ i ∈ range (3*n), f (i/3)) = 3 * ∑ j ∈ range n, f j := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show 3*(n+1) = 3*n+1+1+1 by omega]
    rw [sum_range_succ, sum_range_succ, sum_range_succ, ih, sum_range_succ]
    rw [show 3*n/3=n by omega, show (3*n+1)/3=n by omega, show (3*n+1+1)/3=n by omega]
    ring

private theorem tail_bound (f : ℕ → ℝ) (hf : ∀ i, 0 ≤ f i) {i n : ℕ} (hi : i < n) :
    (∑ t ∈ range (n-(i+1)), f (i+1+t)) ≤ ∑ t ∈ range n, f t := by
  have h := sum_range_add f (i+1) (n-(i+1))
  rw [Nat.add_sub_of_le hi] at h
  have h0 : 0 ≤ ∑ t ∈ range (i+1), f t := sum_nonneg (fun a _ => hf a)
  linarith only [h,h0]

private theorem exceptions (i limit : ℕ) (B : ℝ) (hB : 0 ≤ B) :
    (∑ t ∈ range limit, if i/3 = (i+1+t)/3 then B else 0) ≤ 3*B := by
  have h : ∀ t, (if i/3 = (i+1+t)/3 then B else 0) ≤ (if t<3 then B else 0) := by
    intro t
    split_ifs <;> first | omega | positivity | exact le_rfl
  have h' := sum_le_sum (s:=range limit) (fun t _ => h t)
  have hsub : (range limit).filter (fun t => t<3) ⊆ range 3 := by
    intro t ht
    exact mem_range.mpr (mem_filter.mp ht).2
  have hh := Finset.sum_le_sum_of_subset_of_nonneg hsub (f:=fun _ => B) (fun _ _ _ => hB)
  rw [Finset.sum_filter] at hh
  simp only [sum_const, card_range, nsmul_eq_mul, Nat.cast_ofNat] at hh
  exact h'.trans hh

/-- Sum all pairs of distinct physical slots. All three slots at a site share
one weight, and each left endpoint has at most three same-site partners. -/
theorem sum_pair_bound {n : ℕ} (W Q : ℕ → ℝ) (cost : ℕ → ℕ → ℝ) {A K : ℝ}
    (hA : 0 ≤ A) (hK : 0 ≤ K) (hW : ∀ j, 0 ≤ W j) (hQ : ∀ j, 0 ≤ Q j)
    (hpair : ∀ i t, i < 3*n → t < 3*n-(i+1) →
      cost i t ≤ A*W (i/3)*W ((i+1+t)/3)+(if i/3=(i+1+t)/3 then K*Q (i/3) else 0)) :
    (∑ i ∈ range (3*n), ∑ t ∈ range (3*n-(i+1)), cost i t) ≤
      9*A*(∑ j ∈ range n, W j)^2 + 9*K* ∑ j ∈ range n, Q j := by
  let S := ∑ j ∈ range n, W j
  have hrow : ∀ i ∈ range (3*n), (∑ t ∈ range (3*n-(i+1)), cost i t) ≤
      A*W (i/3)*(3*S) + 3*K*Q (i/3) := by
    intro i hi
    have hi' := mem_range.mp hi
    have hshift := tail_bound (fun x => W (x/3)) (fun x => hW _) hi'
    rw [sum_triples] at hshift
    have hw := mul_le_mul_of_nonneg_left hshift (mul_nonneg hA (hW (i/3)))
    have hex := exceptions i (3*n-(i+1)) (K*Q (i/3)) (mul_nonneg hK (hQ _))
    have hp := sum_le_sum (s:=range (3*n-(i+1))) (fun j hj => hpair i j hi' (mem_range.mp hj))
    rw [sum_add_distrib, ← mul_sum] at hp
    change _ ≤ _ + 3*K*Q (i/3)
    dsimp only [S]
    nlinarith only [hp,hw,hex]
  have htotal := sum_le_sum hrow
  rw [sum_add_distrib, ← mul_sum] at htotal
  have h₁ : (∑ i ∈ range (3*n), A*W (i/3)*(3*S)) = (A*(3*S))*(3*S) := by
    simp_rw [mul_right_comm A _ (3*S), ← mul_sum, sum_triples]
  rw [h₁, sum_triples Q] at htotal
  dsimp only [S] at htotal
  nlinarith only [htotal]


open Kernel Schedule

noncomputable def blocks (k : ℕ) := guardBlocks (history k) (2^k) 0 (raw k)
def q (k j : ℕ) : ℝ := Nat.gcd (2^k) (j+1)
noncomputable def weightAt (k : ℕ) (t : ℝ) (j : ℕ) := min ((q k j)^2) (t^2)⁻¹

private theorem gcd_fourth_sum (k : ℕ) :
    (∑ i ∈ range (2^k), (q k i)^4) ≤ 2 * ((2:ℝ)^k)^4 := by
  let n := (2:ℝ)^k
  have hn : 0 < (2:ℕ)^k := by positivity
  have hb (i : ℕ) : q k i ≤ n := by
    dsimp [q,n]
    exact_mod_cast Nat.le_of_dvd hn (Nat.gcd_dvd_left (2^k) (i+1))
  have hg := GuardSizes.gcdMass_exact k
  have hc : 2*(∑ i ∈ range (2^k), (q k i)^2) + n = 3*n^2 := by
    dsimp [q,n]
    unfold GuardSizes.gcdMass at hg
    exact_mod_cast hg
  have hd (i : ℕ) : (q k i)^4 ≤ (q k i)^2*n^2 := by
    have hq : 0 ≤ q k i := by unfold q; positivity
    calc
      _ = (q k i)^2*(q k i)^2 := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (pow_le_pow_left hq (hb i) 2) (sq_nonneg _)
  have hh := sum_le_sum (s:=range (2^k)) (fun i _ => hd i)
  rw [← sum_mul] at hh
  have hh' : (∑ i ∈ range (2^k), (q k i)^2) ≤ 2*n^2 := by
    have hp : 0 ≤ n := by dsimp [n]; positivity
    nlinarith only [hc,hp,sq_nonneg n]
  calc
    _ ≤ _ := hh
    _ ≤ (2*n^2)*n^2 := mul_le_mul_of_nonneg_right hh' (sq_nonneg n)
    _ = _ := by change _ = 2*n^4; ring

private theorem compensated_mass (k : ℕ) {t : ℝ} (ht : 0 < t) :
    (1+4*(2:ℝ)^k*t)*siteMass k t ≤ 30*((2:ℝ)^k)^2 := by
  let n := (2:ℝ)^k
  let w := min (n^2) (n/t)
  have hn : 0 ≤ n := by dsimp [n]; positivity
  have hb : siteMass k t ≤ 6*w := siteMass_bound k ht
  have h1 : w ≤ n^2 := min_le_left _ _
  have h2 : w*t ≤ n := (le_div_iff ht).mp (min_le_right _ _)
  have h3 := mul_le_mul_of_nonneg_left h2 hn
  have hmul := mul_le_mul_of_nonneg_left hb (show 0 ≤ 1+4*n*t by positivity)
  change (1+4*n*t)*siteMass k t ≤ 30*n^2
  nlinarith only [hmul,h1,h3]

/-- Pointwise control for the ordinary pairs and the three exceptional
same-site configurations gives a quartic bound on the actual block sum. -/
theorem cross_bound (k : ℕ) {z t K : ℝ} (ht : 0 < t) (hK : 0 ≤ K)
    (hp : ∀ i l, i < 3*2^k → l < 3*2^k-(i+1) →
      blockPair z (blocks k) i l ≤
        (K*(1+4*(2:ℝ)^k*t)^2)*weightAt k t (i/3)*weightAt k t ((i+1+l)/3) +
        (if i/3=(i+1+l)/3 then K*(q k (i/3))^4 else 0)) :
    acrossBlocks z (blocks k) ≤ (8118*K)*((2:ℝ)^k)^4 := by
  let n := (2:ℝ)^k
  let S := siteMass k t
  have hs : 0 ≤ S := sum_nonneg (fun i _ => le_min (sq_nonneg _) (by positivity))
  have hp0 : 0 ≤ (1+4*n*t)*S := by
    have hn : 0 ≤ n := by dsimp [n]; positivity
    positivity
  have hx : ((1+4*n*t)*S)^2 ≤ (30*n^2)^2 :=
    pow_le_pow_left hp0 (compensated_mass k ht) 2
  have hreg := mul_le_mul_of_nonneg_left hx (show 0 ≤ 9*K by positivity)
  have hexc := mul_le_mul_of_nonneg_left (gcd_fourth_sum k) (show 0 ≤ 9*K by positivity)
  have hlen : (blocks k).length = 3*2^k := by rw [blocks,guardBlocks_length,raw_length]
  rw [across_as_sum,hlen]
  have hsum := sum_pair_bound (n:=2^k) (weightAt k t) (fun j => q k j ^4) (blockPair z (blocks k))
    (by positivity : 0 ≤ K*(1+4*(2:ℝ)^k*t)^2) hK
    (fun j => le_min (sq_nonneg _) (by positivity)) (fun j => by positivity) hp
  change _ ≤ 9*(K*(1+4*n*t)^2)*S^2 + 9*K* ∑ j ∈ range (2^k), q k j^4 at hsum
  change 9*K*(∑ j ∈ range (2^k), q k j^4) ≤ 9*K*(2*n^4) at hexc
  change _ ≤ (8118*K)*n^4
  nlinarith only [hsum,hreg,hexc]

end GDProof.PairTotal
