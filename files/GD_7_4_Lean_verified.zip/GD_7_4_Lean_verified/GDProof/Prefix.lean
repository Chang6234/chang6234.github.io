import Mathlib

namespace GDProof.Prefix

noncomputable section

/-- Multiplier at the end of a finite word of GD steps. -/
def prod (z : ℝ) : List ℝ → ℝ
  | [] => 1
  | h :: t => (1 - z * h) * prod z t

/-- Sum of the weighted squared prefix multipliers of the word. -/
def energy (z : ℝ) : List ℝ → ℝ
  | [] => 0
  | h :: t => z * h + (1 - z * h) ^ 2 * energy z t

def potential (z : ℝ) (w : List ℝ) : ℝ := energy z w + (prod z w) ^ 2

/-- Every prefix, including the empty and complete word, has potential at most one. -/
def Stable (z : ℝ) (w : List ℝ) : Prop :=
  ∀ p s : List ℝ, w = p ++ s → potential z p ≤ 1

def Nonnegative (w : List ℝ) : Prop := ∀ h ∈ w, (0 : ℝ) ≤ h

theorem prod_append (z : ℝ) (p s : List ℝ) :
    prod z (p ++ s) = prod z p * prod z s := by
  induction p with
  | nil => simp [prod]
  | cons a p ih => simp [prod, ih, mul_assoc]

theorem energy_append (z : ℝ) (p s : List ℝ) :
    energy z (p ++ s) = energy z p + (prod z p) ^ 2 * energy z s := by
  induction p with
  | nil => simp [energy, prod]
  | cons a p ih =>
    change z * a + (1 - z * a) ^ 2 * energy z (p ++ s) =
      z * a + (1 - z * a) ^ 2 * energy z p +
      ((1 - z * a) * prod z p) ^ 2 * energy z s
    rw [ih]
    ring

theorem potential_append (z : ℝ) (p s : List ℝ) :
    potential z (p ++ s) = energy z p + (prod z p) ^ 2 * potential z s := by
  unfold potential
  rw [prod_append, energy_append]
  ring

theorem energy_nonneg {z : ℝ} (hz : 0 ≤ z) (p : List ℝ) (hp : Nonnegative p) :
    0 ≤ energy z p := by
  induction p with
  | nil => simp [energy]
  | cons a p ih =>
    have ha : 0 ≤ a := hp a (by simp)
    have ht : Nonnegative p := fun h hh => hp h (by simp [hh])
    exact add_nonneg (mul_nonneg hz ha) (mul_nonneg (sq_nonneg _) (ih ht))

theorem stable_full {z : ℝ} {p : List ℝ} (hp : Stable z p) : potential z p ≤ 1 :=
  hp p [] (by simp)

theorem stable_left {z : ℝ} {p s : List ℝ} (hw : Stable z (p ++ s)) : Stable z p := by
  intro x y h
  exact hw x (y ++ s) (by rw [h, List.append_assoc])

/-- Two cuts of a single word are ordered; the second case identifies the remainder. -/
theorem splitCut {α : Type*} (u v p s : List α) (h : u ++ v = p ++ s) :
    (∃ t, p = u ++ t) ∨ (∃ t, u = p ++ t ∧ t ++ v = s) := by
  induction u generalizing p with
  | nil => exact Or.inl ⟨p, rfl⟩
  | cons a u ih =>
    cases p with
    | nil => exact Or.inr ⟨a :: u, rfl, h⟩
    | cons b p =>
      obtain ⟨hab, htail⟩ := List.cons.inj h
      subst b
      rcases ih p htail with ⟨t, ht⟩ | ⟨t, ht, hv⟩
      · exact Or.inl ⟨t, congrArg (List.cons a) ht⟩
      · exact Or.inr ⟨t, congrArg (List.cons a) ht, hv⟩

private theorem inserted_bound {A K E B C : ℝ} (hk : 0 ≤ K) (heb : E + B ≤ 1)
    (hb₀ : 0 ≤ B) (hb₁ : B ≤ 1) (ha : A + K ≤ 1) (hac : A + K * C ≤ 1) :
    A + K * (E + B * C) ≤ 1 := by
  calc
    A + K * (E + B * C) ≤ A + K * ((1 - B) + B * C) :=
      add_le_add_left (mul_le_mul_of_nonneg_left
        (add_le_add_right (by linarith : E ≤ 1 - B) _) hk) _
    _ = (1 - B) * (A + K) + B * (A + K * C) := by ring
    _ ≤ (1 - B) * 1 + B * 1 :=
      add_le_add (mul_le_mul_of_nonneg_left ha (sub_nonneg.mpr hb₁))
        (mul_le_mul_of_nonneg_left hac hb₀)
    _ = 1 := by ring

/-- Inserting any nonnegative stable word at any cut preserves all prefix bounds. -/
theorem stable_insert {z : ℝ} (p q s : List ℝ) (hz : 0 ≤ z)
    (hn : Nonnegative q) (hw : Stable z (p ++ s)) (hq : Stable z q) :
    Stable z (p ++ (q ++ s)) := by
  have hp := stable_full (stable_left hw)
  intro x y hxy
  rcases splitCut x y p (q ++ s) hxy.symm with ⟨t, ht⟩ | ⟨t, hxt, hty⟩
  · exact hw x (t ++ s) (by rw [ht, List.append_assoc])
  · subst x
    rcases splitCut t y q s hty with ⟨v, hv⟩ | ⟨v, htv, hvs⟩
    · rw [potential_append]
      calc
        energy z p + (prod z p) ^ 2 * potential z t
            ≤ energy z p + (prod z p) ^ 2 * 1 :=
          add_le_add_left (mul_le_mul_of_nonneg_left (hq t v hv) (sq_nonneg _)) _
        _ ≤ 1 := by simpa [potential] using hp
    · subst t
      have hpv := hw (p ++ v) y (by rw [← hvs, List.append_assoc])
      rw [potential_append] at hpv
      have heb := stable_full hq
      change energy z q + (prod z q) ^ 2 ≤ 1 at heb
      have hb : (prod z q) ^ 2 ≤ 1 := by linarith [energy_nonneg hz q hn]
      rw [potential_append z p (q ++ v), potential_append z q v]
      exact inserted_bound (sq_nonneg _) heb (sq_nonneg _) hb hp hpv

/-- Convex interpolation of the last step bounds its potential by the two endpoints. -/
theorem terminal_interpolate (z : ℝ) (p : List ℝ) (a θ : ℝ) (hθ₀ : 0 ≤ θ)
    (hθ₁ : θ ≤ 1) :
    potential z (p ++ [θ * a]) ≤
      (1 - θ) * potential z p + θ * potential z (p ++ [a]) := by
  rw [potential_append z p [θ * a], potential_append z p [a]]
  simp only [potential, energy, prod, mul_zero, add_zero, mul_one]
  have h := mul_nonneg (sq_nonneg (prod z p * z * a)) (mul_nonneg hθ₀ (sub_nonneg.mpr hθ₁))
  nlinarith only [h]

private theorem stable_snoc {z a : ℝ} {p : List ℝ} (hp : Stable z p)
    (hfull : potential z (p ++ [a]) ≤ 1) : Stable z (p ++ [a]) := by
  intro x y hxy
  rcases splitCut x y p [a] hxy.symm with ⟨t, ht⟩ | ⟨t, hxt, hty⟩
  · exact hp x t ht
  · subst x
    cases t with
    | nil => simpa using stable_full hp
    | cons b t =>
      obtain ⟨hb, hy⟩ := List.cons.inj hty
      subst b
      cases t with
      | nil => exact hfull
      | cons c t => cases hy

theorem stable_shorten_fraction {z a θ : ℝ} {p : List ℝ}
    (hw : Stable z (p ++ [a])) (hθ₀ : 0 ≤ θ) (hθ₁ : θ ≤ 1) :
    Stable z (p ++ [θ * a]) := by
  have hp := stable_left hw
  apply stable_snoc hp
  calc
    potential z (p ++ [θ * a])
        ≤ (1 - θ) * potential z p + θ * potential z (p ++ [a]) :=
      terminal_interpolate z p a θ hθ₀ hθ₁
    _ ≤ (1 - θ) * 1 + θ * 1 :=
      add_le_add (mul_le_mul_of_nonneg_left (stable_full hp) (sub_nonneg.mpr hθ₁))
        (mul_le_mul_of_nonneg_left (stable_full hw) hθ₀)
    _ = 1 := by ring

/-- Replacing the last coefficient by any value between zero and itself preserves stability. -/
theorem stable_shorten {z a b : ℝ} {p : List ℝ}
    (hw : Stable z (p ++ [a])) (hb : 0 ≤ b) (hba : b ≤ a) :
    Stable z (p ++ [b]) := by
  by_cases ha : a = 0
  · have he : b = a := by linarith
    simpa [he] using hw
  · have hapos : 0 < a := lt_of_le_of_ne (le_trans hb hba) (Ne.symm ha)
    have hratio : b / a ≤ 1 := (div_le_one hapos).2 hba
    have h := stable_shorten_fraction hw (div_nonneg hb hapos.le) hratio
    have he : b / a * a = b := by field_simp [ha]
    rwa [he] at h

/-- Weighted sum with each contribution multiplied by the square of the
prefix product strictly before that index. -/
def weighted (z : ℝ) (f : ℝ → ℝ) : List ℝ → ℝ
  | [] => 0
  | h :: t => f h + (1 - z * h) ^ 2 * weighted z f t

theorem energy_eq_weighted (z : ℝ) (w : List ℝ) :
    energy z w = z * weighted z id w := by
  induction w with
  | nil => simp [energy, weighted]
  | cons a t ih =>
    simp only [energy, weighted, id_eq, ih]
    ring

/-- Exact telescoping of successive squared multipliers. -/
theorem telescope (z : ℝ) (w : List ℝ) :
    z ^ 2 * weighted z (fun h => h ^ 2) w =
      2 * energy z w + (prod z w) ^ 2 - 1 := by
  induction w with
  | nil => simp [weighted, energy, prod]
  | cons a t ih =>
    simp only [weighted, energy, prod]
    linear_combination (1 - z * a) ^ 2 * ih

/-- Frozen curvature is dominated by the ordinary weighted gradient energy. -/
theorem frozen_curvature {z : ℝ} {w : List ℝ} (hz : 0 < z) (hw : Stable z w) :
    z * weighted z (fun h => h ^ 2) w ≤ weighted z id w := by
  have hp := stable_full hw
  change energy z w + (prod z w) ^ 2 ≤ 1 at hp
  have h : z ^ 2 * weighted z (fun h => h ^ 2) w ≤ energy z w := by
    linarith [telescope z w]
  rw [energy_eq_weighted] at h
  apply (mul_le_mul_left hz).mp
  calc
    z * (z * weighted z (fun h => h ^ 2) w)
        = z ^ 2 * weighted z (fun h => h ^ 2) w := by ring
    _ ≤ z * weighted z id w := h

/-- The endpoint sum U(W) from the manuscript, in the positive curvature regime. -/
theorem endpoint_forward {z : ℝ} {w : List ℝ} (hw : Stable z w) :
    z * weighted z (fun h => h * (1 + z * h)) w ≤ 2 := by
  have hsplit : ∀ t : List ℝ, weighted z (fun h => h * (1 + z * h)) t =
      weighted z id t + z * weighted z (fun h => h ^ 2) t := by
    intro t
    induction t with
    | nil => simp [weighted]
    | cons a t ih =>
      simp only [weighted, id_eq, ih]
      ring
  rw [hsplit]
  have hp := stable_full hw
  change energy z w + (prod z w) ^ 2 ≤ 1 at hp
  have he := energy_eq_weighted z w
  have ht := telescope z w
  nlinarith only [hp, he, ht, sq_nonneg (prod z w)]

end

end GDProof.Prefix
