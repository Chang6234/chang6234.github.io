import Mathlib

/-! A scalar storage inequality for perturbed gradient descent, and its
telescoping consequence on every prefix of a table. -/

namespace GDProof.Riccati

/-- One step of the backwards storage argument, with input coefficient s. -/
theorem step {p v s a q τ g w : ℝ}
    (hd : 0 < τ - v * s ^ 2)
    (hp : q + τ * v * a ^ 2 / (τ - v * s ^ 2) ≤ p) :
    q * g ^ 2 + v * (a * g + s * w) ^ 2 ≤ p * g ^ 2 + τ * w ^ 2 := by
  have heq :
      (q + τ * v * a ^ 2 / (τ - v * s ^ 2)) * g ^ 2 + τ * w ^ 2 -
          (q * g ^ 2 + v * (a * g + s * w) ^ 2) =
        ((τ - v * s ^ 2) * w - v * a * s * g) ^ 2 / (τ - v * s ^ 2) := by
    field_simp [hd.ne']
    ring
  have hsq := div_nonneg (sq_nonneg ((τ - v * s ^ 2) * w - v * a * s * g)) hd.le
  rw [← heq] at hsq
  exact le_trans (sub_nonneg.mp hsq)
    (add_le_add_right (mul_le_mul_of_nonneg_right hp (sq_nonneg g)) _)

/-- A sequence of backward inequalities implies a forward gain bound for
every prefix. For gradient descent, aᵢ=1−zhᵢ, sᵢ=√hᵢ and qᵢ=zhᵢ²−βhᵢ. -/
theorem prefix_bound {N : ℕ} {τ : ℝ} (a s q v g w : ℕ → ℝ)
    (hzero : v 0 = 0) (hv : ∀ i ≤ N, 0 ≤ v i)
    (hd : ∀ i < N, 0 < τ - v (i+1) * (s i) ^ 2)
    (hp : ∀ i < N, q i + τ * v (i+1) * (a i) ^ 2 /
                          (τ - v (i+1) * (s i) ^ 2) ≤ v i)
    (hg : ∀ i < N, g (i+1) = a i * g i + s i * w i) :
    ∀ t ≤ N, ∑ i in Finset.range t, q i * (g i) ^ 2 ≤
             ∑ i in Finset.range t, τ * (w i) ^ 2 := by
  have hs : ∀ t ≤ N, (∑ i in Finset.range t, q i * (g i) ^ 2) + v t * (g t) ^ 2 ≤
                      ∑ i in Finset.range t, τ * (w i) ^ 2 := by
    intro t
    induction t with
    | zero => intro _; simp [hzero]
    | succ t ih =>
      intro ht
      have ht' : t < N := ht
      have hstep := step (g := g t) (w := w t) (hd t ht') (hp t ht')
      rw [← hg t ht'] at hstep
      simp only [Finset.sum_range_succ]
      linarith [ih ht'.le]
  intro t ht
  linarith [hs t ht, mul_nonneg (hv t ht) (sq_nonneg (g t))]

/-- A shortened last step contributes at most the larger endpoint supply. -/
theorem shortened_last (z β h u : ℝ) (hz : 0 ≤ z) (hu : 0 ≤ u) (huh : u ≤ h) :
    z * u ^ 2 - β * u ≤ max 0 (z * h ^ 2 - β * h) := by
  by_cases hs : z * u - β ≤ 0
  · apply le_trans _ (le_max_left _ _)
    nlinarith [mul_nonpos_of_nonneg_of_nonpos hu hs]
  · apply le_trans _ (le_max_right _ _)
    have hf : 0 ≤ z * (h + u) - β := by
      nlinarith [mul_nonneg hz (le_trans hu huh)]
    nlinarith [mul_nonneg (sub_nonneg.mpr huh) hf]

#print axioms shortened_last
#print axioms step
#print axioms prefix_bound

end GDProof.Riccati
