import GDProof.Scale

/-! Real inequalities and finite geometric sums in the explicit epoch-count
argument. Decreases and increases in the counting lemmas are measured in
units of ε²/L. The midpoint estimates enter as explicit hypotheses. -/
namespace GDProof.EpochArithmetic

open scoped BigOperators

/-- A normalized midpoint variation bounds the test error. -/
theorem threshold_passes {m e δ h c : ℝ} (hm : 0 < m) (hδ : 0 ≤ δ)
    (hmid : δ ≤ e / (2*m^4)) (he : e ≤ m^2/2250) (hh : h ≤ m^2/2)
    (hc : 1 - (1+900*m^2*δ)^2 - h*δ ≤ c) : -(1/2 : ℝ) ≤ c := by
  have hm2 : 0 < m^2 := sq_pos_of_pos hm
  have hm4 : 0 < 2*m^4 := by positivity
  have h1 := (le_div_iff hm4).mp hmid
  have h2 : m^2 * δ ≤ 1/4500 := by
    apply (mul_le_mul_right hm2).mp
    nlinarith only [h1, he]
  have h3 := mul_le_mul_of_nonneg_right hh hδ
  have h4 : 1+900*m^2*δ ≤ 6/5 := by linarith only [h2]
  have hp := pow_le_pow_left (show 0 ≤ 1+900*m^2*δ by positivity) h4 2
  nlinarith only [hp,h3,h2,hc]

/-- Halving the last failing cap preserves the normalized floor. -/
theorem cap_floor {m e : ℝ} (he : m^2/2250 < e) : m^2/4500 ≤ e/2 := by linarith

/-- A twelfth failure is impossible: after eleven halvings the cap is small enough. -/
theorem eleven_halvings {m e₀ : ℝ} (h₀ : e₀ ≤ m^2/2) {j : ℕ} (hj : 11 ≤ j) :
    e₀ / (2:ℝ)^j ≤ m^2/2250 := by
  apply (div_le_iff (by positivity : 0 < (2:ℝ)^j)).mpr
  have hpow := pow_le_pow_right (show (1:ℝ) ≤ 2 by norm_num) hj
  norm_num at hpow
  have hprod := mul_le_mul_of_nonneg_left hpow (show 0 ≤ m^2 by positivity)
  nlinarith only [h₀,hprod,sq_nonneg m]

/-- The step count for a passing epoch is at most 770/m times its decrease. -/
theorem passing_charge {m e steps decrease : ℝ} (hm : 0 < m) (he : 0 < e)
    (hcap : m^2/4500 ≤ e) (hsteps : steps ≤ Real.sqrt (6*e)+12*e/m)
    (hdec : 11*e/48 ≤ decrease) : steps ≤ 770*decrease/m := by
  have hroot : Real.sqrt (6*e) ≤ (822/5)*e/m := by
    apply Real.sqrt_le_iff.mpr
    refine ⟨by positivity, ?_⟩
    rw [div_pow]
    apply (le_div_iff (sq_pos_of_pos hm)).mpr
    have hh := mul_le_mul_of_nonneg_left hcap he.le
    nlinarith only [hh,sq_nonneg e]
  have hsum : Real.sqrt (6*e)+12*e/m ≤ 770*decrease/m := by
    have h := add_le_add_right hroot (12*e/m)
    apply le_trans h
    rw [div_add_div_same]
    exact div_le_div_of_nonneg_right (by linarith) hm.le
  exact hsteps.trans hsum

/-- Charge a unit step when the normalized cap is less than one. -/
theorem small_cap_charge {m e decrease : ℝ} (hm : 0 < m) (he : e < 1)
    (hcap : m^2/4500 ≤ e) (hd : (1:ℝ)/2 ≤ decrease) : 1 ≤ 770*decrease/m := by
  apply (le_div_iff hm).mpr
  nlinarith [sq_nonneg (m-68)]

/-- Bound one failed increase after normalizing its cap by m². -/
theorem single_failure {u a b inc : ℝ} (hu : 0 ≤ u) (ha : 0 ≤ a) (hau : a ≤ u/2)
    (hbu : b ≤ u/4) (hi : inc ≤ u*(( (1+900*a)^2 + b)/2-1)) :
    inc ≤ (450 + 1/8)*u^2+(900^2/8)*u^3 := by
  have hbase : 1+900*a ≤ 1+450*u := by linarith
  have hpow := pow_le_pow_left (show 0 ≤ 1+900*a by positivity) hbase 2
  have hsum : ((1+900*a)^2 + b)/2-1 ≤ ((1+450*u)^2 + u/4)/2-1 := by linarith
  have h := mul_le_mul_of_nonneg_left hsum hu
  nlinarith only [h,hi,hu]

/-- A finite sum of the failed charges is bounded uniformly over the number of halvings. -/
theorem failed_sum (n : ℕ) :
    (∑ j in Finset.range n, (((450+1/8 : ℝ)/4)*(1/4:ℝ)^j
      + (900^2/64 : ℝ)*(1/8:ℝ)^j)) ≤ 14615 := by
  rw [Finset.sum_add_distrib, ← Finset.mul_sum, ← Finset.mul_sum]
  have h₂ := geom_sum_mul_neg (1/4:ℝ) n
  have h₃ := geom_sum_mul_neg (1/8:ℝ) n
  have h2n : 0 ≤ (1/4:ℝ)^n := by positivity
  have h3n : 0 ≤ (1/8:ℝ)^n := by positivity
  linarith only [h₂,h₃,h2n,h3n]

/-- Sum the failed charges for any sequence bounded by the halved initial cap.
Here u is the cap divided by m²ε², and inc is the increase divided by m²ε²/L. -/
theorem halved_failed_charges (n : ℕ) (u inc : ℕ → ℝ)
    (hnon : ∀ j < n, 0 ≤ u j)
    (hcap : ∀ j < n, u j ≤ (1/2)*(1/2:ℝ)^j)
    (hinc : ∀ j < n, inc j ≤ (450+1/8)*(u j)^2+(900^2/8)*(u j)^3) :
    (∑ j in Finset.range n, inc j) ≤ 14615 := by
  apply le_trans _ (failed_sum n)
  apply Finset.sum_le_sum
  intro j hj
  have hj' := Finset.mem_range.mp hj
  have h2 := pow_le_pow_left (hnon j hj') (hcap j hj') 2
  have h3 := pow_le_pow_left (hnon j hj') (hcap j hj') 3
  have hpow2 : ((1/2:ℝ)^j)^2 = (1/4:ℝ)^j := by
    rw [← pow_mul, Nat.mul_comm j 2, pow_mul]
    norm_num
  have hpow3 : ((1/2:ℝ)^j)^3 = (1/8:ℝ)^j := by
    rw [← pow_mul, Nat.mul_comm j 3, pow_mul]
    norm_num
  rw [mul_pow, hpow2] at h2
  rw [mul_pow, hpow3] at h3
  linarith only [hinc j hj',h2,h3]

/-- The preceding charges imply the coefficient in the original-degree count. -/
theorem original_count {m X P N : ℝ} (hm : 0 < m)
    (hpass : P ≤ 770*(X + 14615*m^2)/m) (hN : N ≤ 1+P+48*m) :
    N ≤ 1+11300000*m+770*X/m := by
  have hid : 770*(X+14615*m^2)/m = 770*X/m + (770*14615)*m := by
    field_simp
    ring
  rw [hid] at hpass
  linarith

/-- With the conservative degree, the midpoint estimates give both decrease and passage. -/
theorem conservative_descent {a b d c : ℝ} (ha : 0 ≤ a) (hscale : a ≤ 1/16384)
    (hb : b ≤ 1/32768) (hd : 1-((1+900*a)^2+b)/2 ≤ d)
    (hc : 1-(1+900*a)^2-b ≤ c) : 11/25 ≤ d ∧ -(3/25 : ℝ) ≤ c := by
  have hbase : 1+900*a ≤ 1+900/16384 := by linarith
  have hpow := pow_le_pow_left (show 0 ≤ 1+900*a by positivity) hbase 2
  constructor <;> nlinarith only [hpow,hb,hd,hc]

/-- Convert a conservative-degree epoch and update count to the 21 coefficient. -/
theorem conservative_count {m X N epochs : ℝ} (hm : 0 < m) (hX : 0 ≤ X)
    (hE : epochs ≤ 75*X/(11*m^2)) (hN : N ≤ 1+3*m+3*m*epochs) :
    N ≤ 1+3*m+21*X/m := by
  have h := mul_le_mul_of_nonneg_left hE (show 0 ≤ 3*m by positivity)
  have hh : 3*m*(75*X/(11*m^2)) = (225*X/11)/m := by
    field_simp
    ring
  rw [hh] at h
  have h' : (225*X/11)/m ≤ 21*X/m := div_le_div_of_nonneg_right (by linarith) hm.le
  linarith

/-- Dyadic rounding gives the explicit 336 coefficient for X/r. -/
theorem conservative_rounding {r m X N : ℝ} (hr : 0 < r) (hm : 0 < m) (hX : 0 ≤ X)
    (hlo : r/16 ≤ m) (hhi : m ≤ r/8) (hN : N ≤ 1+3*m+21*X/m) :
    N ≤ 1+(3/8)*r+336*X/r := by
  have hcross : 21*X/m ≤ 336*X/r := by
    apply (div_le_div_iff hm hr).mpr
    nlinarith only [mul_nonneg hX (sub_nonneg.mpr hlo)]
  linarith

/-- For r≥16 the conservative dyadic degree is at least two and brackets r/8. -/
theorem conservative_degree (r : ℝ) (hr : 16 ≤ r) :
    let m := (2:ℝ) ^ Degree.exponent (r/8)
    2 ≤ m ∧ r/16 < m ∧ m ≤ r/8 := by
  dsimp only
  obtain ⟨hlo,hhi⟩ := Degree.exponent_spec (r/8) (by linarith)
  rw [pow_succ] at hhi
  have hpos : 1 ≤ Degree.exponent (r/8) := by
    by_contra bad
    have hz : Degree.exponent (r/8) = 0 := by omega
    rw [hz, pow_zero] at hhi
    linarith
  exact ⟨by simpa using pow_le_pow_right (show (1:ℝ) ≤ 2 by norm_num) hpos,
    by linarith, hlo⟩

/-- Convert the conservative epoch estimates into the actual real-power bound.
The two hypotheses on epochs and N encode the decrease and length estimates. -/
theorem conservative_gradient_estimate {L ρ ε Δ epochs N : ℝ} (hL : 0 < L)
    (hρ : 0 < ρ) (hε : 0 < ε) (hΔ : 0 ≤ Δ) (hr : 16 ≤ Scale.target L ρ ε) :
    let m := (2:ℝ) ^ Degree.exponent (Scale.target L ρ ε / 8)
    epochs ≤ 75*(L*Δ/ε^2)/(11*m^2) → N ≤ 1+3*m+3*m*epochs →
    N ≤ 1+(3/8)*Scale.target L ρ ε+336*Scale.weightedGap L ρ ε Δ := by
  intro m hE hN
  obtain ⟨hm, hlo, hhi⟩ := conservative_degree _ hr
  have hm' : 0 < m := lt_of_lt_of_le (by norm_num : (0:ℝ) < 2) hm
  have hr' : 0 < Scale.target L ρ ε := by linarith
  have hX : 0 ≤ L*Δ/ε^2 := by positivity
  have hb := conservative_rounding hr' hm' hX hlo.le hhi (conservative_count hm' hX hE hN)
  rw [Scale.scale_identity hL hρ hε] at hb
  have hid : 336*(Scale.target L ρ ε * Scale.weightedGap L ρ ε Δ) / Scale.target L ρ ε =
      336*Scale.weightedGap L ρ ε Δ := by
    field_simp [hr'.ne']
    ring
  exact hid ▸ hb

end GDProof.EpochArithmetic
