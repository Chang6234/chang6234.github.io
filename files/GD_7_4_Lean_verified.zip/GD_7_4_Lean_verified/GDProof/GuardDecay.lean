import GDProof.Guarded
import GDProof.RawProduct

namespace GDProof.GuardDecay

open GDProof.Schedule GDProof.Prefix GDProof.Guarded GDProof.RawProduct
noncomputable section

private def guards (z : ℝ) (prev : ℕ → List ℝ) (n : ℕ) : ℕ → List ℝ → ℝ
  | _, [] => 1
  | j, _ :: xs => (prod z (prev (guardSize n j)))^2 * guards z prev n (j+1) xs

private theorem splice_prod (z : ℝ) (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) :
    prod z (splice prev n j w) = prod z w * guards z prev n j w := by
  induction w generalizing j with
  | nil => simp [splice, prod, guards]
  | cons a w ih =>
    rw [splice, prod_append, prod, prod_append, ih, prod, guards]
    ring

private theorem guards_bounds (z : ℝ) (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ)
    (hp : ∀ i, (prod z (prev i))^2 ≤ 1) : 0 ≤ guards z prev n j w ∧ guards z prev n j w ≤ 1 := by
  induction w generalizing j with
  | nil => simp [guards]
  | cons a t ih =>
    obtain ⟨ht₀, ht₁⟩ := ih (j+1)
    refine ⟨mul_nonneg (sq_nonneg _) ht₀, ?_⟩
    exact (mul_le_mul_of_nonneg_right (hp _) ht₀).trans (by simpa using ht₁)

private theorem last_guard (z : ℝ) (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ)
    (hw : w ≠ []) (hp : ∀ i, (prod z (prev i))^2 ≤ 1) :
    guards z prev n j w ≤ (prod z (prev (guardSize n (j + w.length - 1))))^2 := by
  induction w generalizing j with
  | nil => exact False.elim (hw rfl)
  | cons a t ih =>
    cases t with
    | nil => simp [guards]
    | cons b t =>
      have htail := ih (j+1) (by simp)
      have ht := (guards_bounds z prev n (j+1) (b::t) hp).1
      calc
        guards z prev n j (a::b::t) ≤ guards z prev n (j+1) (b::t) := by
          change _ * _ ≤ _
          simpa using mul_le_mul_of_nonneg_right (hp (guardSize n j)) ht
        _ ≤ _ := by simpa [Nat.add_assoc, Nat.add_comm 1] using htail

theorem stable_prod_sq {z : ℝ} (w : List ℝ) (hz : 0 ≤ z)
    (hs : Stable z w) (hn : Nonnegative w) : (prod z w)^2 ≤ 1 := by
  have h := stable_full hs
  change energy z w + (prod z w)^2 ≤ 1 at h
  linarith [energy_nonneg hz w hn]

private theorem hist_prod (k i : ℕ) (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) :
    (prod z (history k i))^2 ≤ 1 := by
  obtain ⟨hs, hn⟩ := history_stable k i z hz hz'
  exact stable_prod_sq _ hz hs hn

theorem final_size (k : ℕ) :
    guardSize (2^(k+2)) (2^(k+2)-1) = 2^k := by
  have hn : 0 < (2:ℕ)^(k+2) := by positivity
  unfold guardSize
  rw [show (2:ℕ)^(k+2)-1+1 = 2^(k+2) by omega, Nat.gcd_self]
  have he : (2:ℕ)^(k+2) = 4*2^k := by rw [pow_add]; ring
  rw [show ((2:ℕ)^(k+2))^2 = 2^k*(4*2^(k+2)) by rw [he]; ring]
  exact Nat.mul_div_cancel _ (by positivity)

def scale (k : ℕ) (z : ℝ) : ℝ := 1 + z * (4:ℝ)^k

theorem scale_pos (k : ℕ) (z : ℝ) (hz : 0 ≤ z) : 0 < scale k z := by unfold scale; positivity

private theorem raw_base (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    scale k z * (prod z (raw k))^2 ≤ 2 := by
  have ht := raw_product_sq k z hz h₁
  have hp := stable_prod_sq (raw k) hz (RawPrefix.raw_stable k z hz h₁)
    (fun a ha => le_trans zero_le_one (raw_lower k a ha))
  rw [pow_succ] at ht
  unfold scale
  have hn : 0 ≤ (4:ℝ)^k * z * (prod z (raw k))^2 := by positivity
  nlinarith only [hn, hz, ht, hp]

theorem table_le_raw (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    (prod z (table k))^2 ≤ (prod z (raw k))^2 := by
  obtain ⟨hg, hg'⟩ := guards_bounds z (history k) (2^k) 0 (raw k)
    (fun i => hist_prod k i z hz h₁)
  rw [table_unfold, splice_prod, mul_pow]
  have h : (guards z (history k) (2^k) 0 (raw k))^2 ≤ 1^2 := by gcongr
  simpa using mul_le_mul_of_nonneg_left h (sq_nonneg (prod z (raw k)))

/-- In the final raw position both guarding copies have physical degree n/4. -/
theorem two_final_guards (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    (prod z (table (k+2)))^2 ≤ (prod z (raw (k+2)))^2 * ((prod z (table k))^2)^2 := by
  let n : ℕ := 2^(k+2)
  let prev := history (k+2)
  have hp : ∀ i, (prod z (prev i))^2 ≤ 1 := fun i => hist_prod _ i z hz h₁
  have hg := last_guard z prev n 0 (raw (k+2)) (by simp [raw]) hp
  have he : prev (guardSize n (0 + (raw (k+2)).length - 1)) = table k := by
    dsimp [n, prev]
    rw [raw_length, Nat.zero_add, final_size, history_at (by omega : k < k+2)]
  rw [he] at hg
  rw [table_unfold, splice_prod, mul_pow]
  apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
  change (guards z prev n 0 (raw (k+2)))^2 ≤ _
  have hnn := (guards_bounds z prev n 0 (raw (k+2)) hp).1
  gcongr

private def Decay (d : ℕ) : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ k : ℕ, ∀ z : ℝ, 0 ≤ z → z ≤ 1 →
    (scale k z)^d * (prod z (table k))^2 ≤ C

private theorem base : Decay 1 := by
  refine ⟨2, by norm_num, ?_⟩
  intro k z hz h₁
  rw [pow_one]
  exact (mul_le_mul_of_nonneg_left (table_le_raw k z hz h₁) (scale_pos k z hz).le).trans
    (raw_base k z hz h₁)

private theorem improve (d : ℕ) (h : Decay d) : Decay (1+2*d) := by
  obtain ⟨C, _, h⟩ := h
  refine ⟨max (5^(1+2*d)) (2*(16^d*C)^2), lt_of_lt_of_le (by positivity) (le_max_left _ _), ?_⟩
  intro k z hz h₁
  by_cases hk : k < 2
  · have hs : scale k z ≤ 5 := by
      interval_cases k <;> norm_num [scale] <;> linarith
    have hp := hist_prod (k+1) (2^k) z hz h₁
    change (prod z (table k))^2 ≤ 1 at hp
    apply le_trans _ (le_max_left _ _)
    calc
      _ ≤ (5:ℝ)^(1+2*d)*1 :=
        mul_le_mul (pow_le_pow_left (scale_pos k z hz).le hs _) hp (sq_nonneg _) (by positivity)
      _ = _ := mul_one _
  · obtain ⟨j, rfl⟩ : ∃ j, k = j+2 := ⟨k-2, by omega⟩
    have hs : scale (j+2) z ≤ 16 * scale j z := by
      unfold scale
      rw [pow_add]
      ring_nf
      linarith
    have hp : (scale (j+2) z)^d * (prod z (table j))^2 ≤ 16^d * C := by
      calc
        _ ≤ (16 * scale j z)^d * (prod z (table j))^2 :=
          mul_le_mul_of_nonneg_right (pow_le_pow_left (scale_pos (j+2) z hz).le hs _) (sq_nonneg _)
        _ = 16^d * ((scale j z)^d * (prod z (table j))^2) := by rw [mul_pow]; ring
        _ ≤ 16^d*C := mul_le_mul_of_nonneg_left (h j z hz h₁) (by positivity)
    apply le_trans _ (le_max_right _ _)
    calc
      _ ≤ (scale (j+2) z)^(1+2*d) *
          ((prod z (raw (j+2)))^2 * ((prod z (table j))^2)^2) :=
        mul_le_mul_of_nonneg_left (two_final_guards j z hz h₁) (pow_nonneg (scale_pos _ _ hz).le _)
      _ = (scale (j+2) z*(prod z (raw (j+2)))^2) *
          ((scale (j+2) z)^d * (prod z (table j))^2)^2 := by
        rw [pow_add, pow_one, mul_comm 2 d, pow_mul]
        ring
      _ ≤ 2 * (16^d*C)^2 := by
        apply mul_le_mul (raw_base (j+2) z hz h₁) _ (sq_nonneg _) (by norm_num)
        apply pow_le_pow_left _ hp
        exact mul_nonneg (pow_nonneg (scale_pos _ _ hz).le _) (sq_nonneg _)

theorem complete_decay_sq : ∃ C : ℝ, 0 < C ∧ ∀ k : ℕ, ∀ z : ℝ, 0 ≤ z → z ≤ 1 →
    (scale k z)^7 * (prod z (table k))^2 ≤ C :=
  improve 3 (improve 1 base)

/-- Squared damping converted to the manuscript's exponent 7/2. -/
theorem complete_decay : ∃ C : ℝ, 0 < C ∧ ∀ k : ℕ, ∀ z : ℝ, 0 ≤ z → z ≤ 1 →
    |prod z (table k)| ≤ C / (1 + z * ((2:ℝ)^k)^2)^(7/2:ℝ) := by
  obtain ⟨C, hC, h⟩ := complete_decay_sq
  refine ⟨Real.sqrt C, Real.sqrt_pos.2 hC, ?_⟩
  intro k z hz h₁
  have hp : ((2:ℝ)^k)^2 = (4:ℝ)^k := by rw [pow_two, ← mul_pow]; norm_num
  rw [hp]
  change _ ≤ _ / (scale k z)^(7/2:ℝ)
  have hs := scale_pos k z hz
  apply (le_div_iff (Real.rpow_pos_of_pos hs _)).2
  have he : ((scale k z)^(7/2:ℝ))^2 = (scale k z)^7 := by
    rw [← Real.rpow_mul_natCast hs.le]
    norm_num
    exact Real.rpow_natCast _ 7
  have hb : (|prod z (table k)| * (scale k z)^(7/2:ℝ))^2 ≤ C := by
    rw [mul_pow, he, sq_abs, mul_comm]
    exact h k z hz h₁
  exact Real.le_sqrt_of_sq_le hb

end
end GDProof.GuardDecay
