import GDProof.GuardDecay
import GDProof.GuardSizes
import GDProof.RawInterval
import GDProof.Kernel

namespace GDProof.Suffix

open GDProof.Schedule GDProof.Prefix GDProof.GuardDecay GDProof.RawInterval
noncomputable section

def Bounded (z M : ℝ) (w : List ℝ) : Prop :=
  ∀ l s, w = l ++ s → |prod z s| ≤ M

private inductive Block
  | guarded : List ℝ → Block
  | rawStep : ℝ → Block

private def word : Block → List ℝ
  | .guarded w => w
  | .rawStep a => [a]

private def skeleton : Block → List ℝ
  | .guarded _ => []
  | .rawStep a => [a]

private def join (f : Block → List ℝ) : List Block → List ℝ
  | [] => []
  | b :: bs => f b ++ join f bs

private theorem join_append (f : Block → List ℝ) (bs cs : List Block) :
    join f (bs ++ cs) = join f bs ++ join f cs := by
  induction bs with
  | nil => rfl
  | cons b bs ih =>
    change f b ++ join f (bs ++ cs) = _
    rw [ih]
    simp [join, List.append_assoc]

private def Good (z M : ℝ) : Block → Prop
  | .guarded w => |prod z w| ≤ 1 ∧ Bounded z M w
  | .rawStep _ => True

private theorem complete_blocks (z M : ℝ) (bs : List Block) (hg : ∀ b ∈ bs, Good z M b) :
    |prod z (join word bs)| ≤ |prod z (join skeleton bs)| := by
  induction bs with
  | nil => exact le_refl _
  | cons b bs ih =>
    have ht := ih (fun x hx => hg x (by simp [hx]))
    have hb := hg b (by simp)
    simp only [join, prod_append, abs_mul]
    apply mul_le_mul _ ht (abs_nonneg _) (abs_nonneg _)
    cases b with
    | rawStep a => exact le_refl _
    | guarded w => simpa [word, skeleton, prod] using hb.1

/-- A partially cut first block contributes at most M, while subsequent
complete guards have modulus at most one. The uncancelled raw steps are a suffix. -/
private theorem blocks_suffix (z M : ℝ) (hM : 1 ≤ M) (bs : List Block)
    (hg : ∀ b ∈ bs, Good z M b) (l s : List ℝ) (hcut : join word bs = l ++ s) :
    ∃ v u, join skeleton bs = v ++ u ∧ |prod z s| ≤ M * |prod z u| := by
  induction bs generalizing l s with
  | nil =>
    have he : l ++ s = [] := hcut.symm
    obtain ⟨_, rfl⟩ := List.append_eq_nil.mp he
    exact ⟨[], [], rfl, by simpa [prod] using hM⟩
  | cons b bs ih =>
    have ht : ∀ x ∈ bs, Good z M x := fun x hx => hg x (by simp [hx])
    have hb := hg b (by simp)
    have hc := complete_blocks z M bs ht
    rcases cut (word b) (join word bs) l s hcut with ⟨t, he, hs⟩ | ⟨t, _, hs⟩
    · cases b with
      | guarded w =>
        refine ⟨[], join skeleton bs, rfl, ?_⟩
        rw [← hs, prod_append, abs_mul]
        exact mul_le_mul (hb.2 l t he) hc (abs_nonneg _) (by linarith)
      | rawStep a =>
        cases l with
        | nil =>
          change [a] = t at he
          subst t
          refine ⟨[], a :: join skeleton bs, rfl, ?_⟩
          rw [← hs]
          calc
            _ ≤ |prod z (a :: join skeleton bs)| := by
              change |(1-z*a)*prod z (join word bs)| ≤ |(1-z*a)*prod z (join skeleton bs)|
              rw [abs_mul, abs_mul]
              exact mul_le_mul_of_nonneg_left hc (abs_nonneg _)
            _ ≤ _ := by simpa using mul_le_mul_of_nonneg_right hM (abs_nonneg (prod z (a :: join skeleton bs)))
        | cons x l =>
          have he' : l ++ t = [] := (List.cons.inj he).2.symm
          obtain ⟨_, rfl⟩ := List.append_eq_nil.mp he'
          refine ⟨[a], join skeleton bs, rfl, ?_⟩
          rw [← hs, List.nil_append]
          exact hc.trans (by simpa using mul_le_mul_of_nonneg_right hM (abs_nonneg (prod z (join skeleton bs))))
    · obtain ⟨v,u,hu,h⟩ := ih ht t s hs
      exact ⟨skeleton b ++ v,u,by simp [join, hu, List.append_assoc],h⟩

private def blocks (prev : ℕ → List ℝ) (n : ℕ) : ℕ → List ℝ → List Block
  | _, [] => []
  | j, a :: w =>
    let g := prev (guardSize n j)
    .guarded g :: .rawStep a :: .guarded g :: blocks prev n (j+1) w

private theorem blocks_word (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) :
    join word (blocks prev n j w) = splice prev n j w := by
  induction w generalizing j with
  | nil => rfl
  | cons a t ih => simp [join, word, blocks, splice, ih]

private theorem blocks_raw (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) :
    join skeleton (blocks prev n j w) = w := by
  induction w generalizing j with
  | nil => rfl
  | cons a t ih => simp [join, skeleton, blocks, ih]

private theorem blocks_good (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) (z M : ℝ)
    (hg : ∀ i, |prod z (prev i)| ≤ 1 ∧ Bounded z M (prev i)) :
    ∀ b ∈ blocks prev n j w, Good z M b := by
  induction w generalizing j with
  | nil => simp [blocks]
  | cons a t ih =>
    intro b hb
    simp only [blocks,List.mem_cons] at hb
    rcases hb with rfl | rfl | rfl | hb
    · apply hg
    · trivial
    · apply hg
    · exact ih _ _ hb

private theorem blocks_snoc (prev : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) (a : ℝ) :
    blocks prev n j (w++[a]) = blocks prev n j w ++
      [.guarded (prev (guardSize n (j+w.length))), .rawStep a, .guarded (prev (guardSize n (j+w.length)))] := by
  induction w generalizing j with
  | nil => simp [blocks]
  | cons b w ih =>
    change _ :: _ :: _ :: blocks prev n (j + 1) (w ++ [a]) = _
    rw [ih]
    simp [blocks, Nat.add_assoc, Nat.add_comm 1]

/-- Removing the final F_{n/4} leaves a sequence whose every suffix is at
most M times the worst raw interval, whenever all smaller guards are M-bounded. -/
theorem remove_final (k : ℕ) (z M : ℝ) (hM : 1 ≤ M) (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (hb : ∀ i, Bounded z M (history (k+2) i)) :
    ∃ q, table (k+2) = q ++ table k ∧ Bounded z (M * scale (k+2) z) q := by
  let n : ℕ := 2^(k+2)
  let prev := history (k+2)
  let W := raw (k+2)
  have hne : W ≠ [] := by simp [W, raw]
  obtain ⟨w, a, hwa⟩ : ∃ w a, W = w ++ [a] :=
    ⟨W.dropLast, W.getLast hne, (List.dropLast_append_getLast hne).symm⟩
  have hn : w.length + 1 = n := by simpa [W,n,hwa] using
    (show (w++[a]).length = n by rw [← hwa]; exact raw_length _)
  have he : prev (guardSize n (0+w.length)) = table k := by
    change history (k+2) (guardSize (2^(k+2)) (0+w.length)) = _
    have hlen : 0+w.length = n-1 := by omega
    rw [hlen,final_size, history_at (by omega : k < k+2)]
  let B := blocks prev n 0 w ++ [.guarded (table k), .rawStep a]
  have decomposition : blocks prev n 0 W = B ++ [.guarded (table k)] := by
    rw [hwa,blocks_snoc,he]
    simp [B,List.append_assoc]
  have hskel : join skeleton B = W := by
    have h := blocks_raw prev n 0 W
    rw [decomposition,join_append] at h
    simpa [join,skeleton] using h
  have hgood : ∀ b ∈ B, Good z M b := by
    intro b hs
    refine blocks_good prev n 0 W z M ?_ b ?_
    · intro i
      obtain ⟨hs,hn⟩ := Guarded.history_stable (k+2) i z hz h₁
      have hq := stable_prod_sq (prev i) hz hs hn
      exact ⟨by rw [abs_le]; constructor <;> nlinarith [sq_nonneg (prod z (prev i)-1),sq_nonneg (prod z (prev i)+1)],hb i⟩
    · rw [decomposition]
      simp [hs]
  refine ⟨join word B, ?_, ?_⟩
  · rw [table_unfold, ← blocks_word]
    change join word (blocks prev n 0 W) = _
    rw [decomposition, join_append]
    simp [join,word]
  · intro l s hs
    obtain ⟨v,u,hu,hp⟩ := blocks_suffix z M hM B hgood l s hs
    rw [hskel] at hu
    have hi := raw_interval (k+2) z hz h₁ v u [] (by simpa using hu)
    have hc : max 1 ((4:ℝ)^(k+2)/2*z) ≤ scale (k+2) z := by
      have hh : 0 ≤ z*(4:ℝ)^(k+2) := by positivity
      unfold scale
      apply max_le <;> linarith
    exact hp.trans (mul_le_mul_of_nonneg_left (hi.trans hc) (by linarith))

theorem last_decay : ∃ C : ℝ, 0 < C ∧ ∀ k z, 0 ≤ z → z ≤ 1 →
    (scale (k+2) z)^7 * (prod z (table k))^2 ≤ C := by
  obtain ⟨A,hA,h⟩ := complete_decay_sq
  refine ⟨16^7*A,by positivity,?_⟩
  intro k z hz h₁
  have hs : scale (k+2) z ≤ 16 * scale k z := by
    unfold scale
    rw [pow_add]
    ring_nf
    linarith
  calc
    _ ≤ (16 * scale k z)^7 * (prod z (table k))^2 :=
      mul_le_mul_of_nonneg_right (pow_le_pow_left (scale_pos _ _ hz).le hs _) (sq_nonneg _)
    _ = 16^7 * ((scale k z)^7 * (prod z (table k))^2) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (h k z hz h₁) (by positivity)

private theorem threshold : ∃ T : ℝ, 5 ≤ T ∧ ∀ k z, 0 ≤ z → z ≤ 1 → T < scale (k+2) z →
    scale (k+2) z * |prod z (table k)| ≤ 1 := by
  obtain ⟨C,_,hc⟩ := last_decay
  refine ⟨max 5 C,le_max_left _ _,?_⟩
  intro k z hz h₁ hT
  let X := scale (k+2) z
  have hX : 0 < X := scale_pos _ _ hz
  have h1 : 1 ≤ X := by have := (le_max_left (5:ℝ) C).trans hT.le; change 5 ≤ X at this; linarith
  have h3 : X^3 * (prod z (table k))^2 ≤ X :=
    (mul_le_mul_of_nonneg_right (pow_le_pow_right h1 (by decide : 3 ≤ 7)) (sq_nonneg _)).trans
      ((hc k z hz h₁).trans ((le_max_right _ _).trans hT.le))
  have hsq : (X * |prod z (table k)|)^2 ≤ 1 := by
    apply (mul_le_mul_left hX).mp
    rw [mul_one,mul_pow,sq_abs]
    calc
      _ = X^3 * (prod z (table k))^2 := by ring
      _ ≤ _ := h3
  change X * |prod z (table k)| ≤ 1
  nlinarith [sq_nonneg (X * |prod z (table k)| - 1)]

private theorem product_exp (z : ℝ) (hz : 0 ≤ z) (w : List ℝ) (hn : Nonnegative w) :
    |prod z w| ≤ Real.exp (z*w.sum) := by
  induction w with
  | nil => simp [prod]
  | cons a w ih =>
    have ha := hn a (by simp)
    have hb : |1-z*a| ≤ Real.exp (z*a) := by
      apply le_trans _ (Real.add_one_le_exp _)
      rw [abs_le]
      constructor <;> linarith [mul_nonneg hz ha]
    have ht := ih (fun t hh => hn t (by simp [hh]))
    simp only [prod, abs_mul, List.sum_cons, mul_add, Real.exp_add]
    exact mul_le_mul hb ht (abs_nonneg _) (Real.exp_pos _).le

private theorem small_suffix (k : ℕ) (z T : ℝ) (hz : 0 ≤ z) (h : scale k z ≤ T) :
    Bounded z (Real.exp (2*T)) (table k) := by
  intro l s hcut
  have hpos := Guarded.table_nonnegative k
  rw [hcut] at hpos
  have hs : Nonnegative s := fun a ha => hpos a (by simp [ha])
  have hl : 0 ≤ l.sum := List.sum_nonneg (fun a ha => hpos a (by simp [ha]))
  have hm := GuardSizes.table_mass k
  rw [hcut, List.sum_append] at hm
  have hp : ((2:ℝ)^k)^2 = (4:ℝ)^k := by rw [pow_two, ← mul_pow]; norm_num
  rw [hp] at hm
  apply (product_exp z hz s hs).trans (Real.exp_le_exp.mpr _)
  unfold scale at h
  nlinarith only [h,mul_le_mul_of_nonneg_left (show s.sum ≤ 2*(4:ℝ)^k by linarith) hz]

/-- Uniform absolute bound on every suffix product of every actual guarded schedule. -/
theorem uniform_suffix : ∃ M : ℝ, 1 ≤ M ∧ ∀ k z, 0 ≤ z → z ≤ 1 → Bounded z M (table k) := by
  obtain ⟨T,hT,ht⟩ := threshold
  let M := Real.exp (2*T)
  have hM : 1 ≤ M := by apply Real.one_le_exp; linarith
  refine ⟨M,hM,?_⟩
  intro k z hz h₁
  suffices hist : ∀ d i : ℕ, Bounded z M (history d i) from hist (k+1) (2^k)
  intro d
  induction d with
  | zero =>
    intro i l s he
    obtain ⟨_,rfl⟩ := List.append_eq_nil.mp he.symm
    simpa [prod] using hM
  | succ d ih =>
    intro i
    by_cases hi : i = 2^d
    · subst i
      change Bounded z M (table d)
      by_cases hs : scale d z ≤ T
      · exact small_suffix d z T hz hs
      · have hd : 2 ≤ d := by
          by_contra! hd
          interval_cases d <;> norm_num [scale] at hs <;> linarith
        obtain ⟨j,rfl⟩ : ∃ j, d=j+2 := ⟨d-2, by omega⟩
        obtain ⟨q,hq,hqq⟩ := remove_final j z M hM hz h₁ ih
        have hj := ih (2^j)
        rw [history_at (by omega : j < j+2)] at hj
        intro l s he
        rw [hq] at he
        rcases cut q (table j) l s he with ⟨v,hv,vs⟩ | ⟨v,_,vs⟩
        · rw [← vs,prod_append,abs_mul]
          calc
            _ ≤ (M*scale (j+2) z) * |prod z (table j)| :=
              mul_le_mul_of_nonneg_right (hqq l v hv) (abs_nonneg _)
            _ = M*(scale (j+2) z * |prod z (table j)|) := by ring
            _ ≤ M*1 := mul_le_mul_of_nonneg_left (ht j z hz h₁ (lt_of_not_ge hs)) (by linarith)
            _ = M := mul_one _
        · exact hj v s vs
    · simpa only [history, if_neg hi] using ih i

end
end GDProof.Suffix
