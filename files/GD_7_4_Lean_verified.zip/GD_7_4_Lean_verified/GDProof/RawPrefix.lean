import GDProof.Schedule
import GDProof.Prefix

namespace GDProof.RawPrefix

open GDProof.Schedule GDProof.Prefix

noncomputable section

private def liftZ (z : ℝ) := 4 * z * (1 - z)

private theorem lift_bounds {z : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    0 ≤ liftZ z ∧ liftZ z ≤ 1 := by
  unfold liftZ
  constructor
  · exact mul_nonneg (mul_nonneg (by norm_num) hz) (sub_nonneg.mpr h₁)
  · nlinarith [sq_nonneg (1 - 2 * z)]

private theorem pair_prod' {a : ℝ} (ha : 1 ≤ a) (z : ℝ) :
    (1 - z * small a) * (1 - z * large a) = 1 - liftZ z * a := by
  calc
    _ = (1 - small a * z) * (1 - large a * z) := by ring
    _ = _ := by rw [pair_product ha]; unfold liftZ; ring

private theorem split_prod (z : ℝ) (as : List ℝ) (hw : ∀ a ∈ as, (1 : ℝ) ≤ a) :
    prod z (children as) = prod (liftZ z) as := by
  induction as with
  | nil => rfl
  | cons a as ih =>
    have ha := hw a (by simp)
    have ht : ∀ b ∈ as, (1 : ℝ) ≤ b := fun b hb => hw b (by simp [hb])
    simp only [children, prod, ih ht, ← mul_assoc, pair_prod' ha]

theorem children_prod (z : ℝ) (as : List ℝ) (hw : ∀ a ∈ as, (1 : ℝ) ≤ a) :
    prod z (children as) = prod (4*z*(1-z)) as := split_prod z as hw

private theorem pair_energy {a z : ℝ} (ha : 1 ≤ a) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    (1 - z) * (z * small a + (1 - z * small a) ^ 2 * (z * large a)) ≤
      (1 - liftZ z / 2) * (liftZ z * a) := by
  have hb := (small_bounds ha).2
  have hy := (lift_bounds hz h₁).1
  calc
    _ = (1-z)*z*((small a+large a)-2*z*(small a*large a)
          + z^2*small a*(small a*large a)) := by ring
    _ = (liftZ z*a)*(1-2*z+z^2*small a) := by
      rw [pair_add, pair_mul ha]; unfold liftZ; ring
    _ ≤ (liftZ z*a)*(1-2*z+z^2*2) := by
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg hy (by linarith))
      exact add_le_add_left (mul_le_mul_of_nonneg_left hb (sq_nonneg _)) _
    _ = _ := by unfold liftZ; ring

private theorem split_energy {z : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (as : List ℝ) (hw : ∀ a ∈ as, (1 : ℝ) ≤ a) :
    (1-z)*energy z (children as) ≤ (1-liftZ z/2)*energy (liftZ z) as := by
  induction as with
  | nil => simp [children, energy]
  | cons a as ih =>
    have ha := hw a (by simp)
    have ht : ∀ b ∈ as, (1 : ℝ) ≤ b := fun b hb => hw b (by simp [hb])
    simp only [children, energy]
    calc
      _ = (1-z)*(z*small a + (1-z*small a)^2*(z*large a))
          + ((1-z*small a)*(1-z*large a))^2*((1-z)*energy z (children as)) := by ring
      _ ≤ (1-liftZ z/2)*(liftZ z*a)
          + (1-liftZ z*a)^2*((1-liftZ z/2)*energy (liftZ z) as) := by
        rw [pair_prod' ha]
        exact add_le_add (pair_energy ha hz h₁)
          (mul_le_mul_of_nonneg_left (ih ht) (sq_nonneg _))
      _ = _ := by ring

/-- A cut through children consists of complete pairs and at most one small child. -/
private theorem child_cut (as p s : List ℝ) (h : children as = p ++ s) :
    (∃ x t, as = x ++ t ∧ p = children x) ∨
    (∃ x a t, as = x ++ (a :: t) ∧ p = children x ++ [small a]) := by
  induction as generalizing p s with
  | nil =>
    cases p with
    | nil => exact Or.inl ⟨[], [], rfl, rfl⟩
    | cons b p => cases h
  | cons a as ih =>
    cases p with
    | nil => exact Or.inl ⟨[], a :: as, rfl, rfl⟩
    | cons b p =>
      obtain ⟨hb, hh⟩ := List.cons.inj h
      subst b
      cases p with
      | nil => exact Or.inr ⟨[], a, as, rfl, rfl⟩
      | cons c p =>
        obtain ⟨hc, hh'⟩ := List.cons.inj hh
        subst c
        rcases ih p s hh' with ⟨x,t,ht,hp⟩ | ⟨x,d,t,ht,hp⟩
        · exact Or.inl ⟨a :: x,t, congrArg (List.cons a) ht,
            congrArg (fun l => small a :: large a :: l) hp⟩
        · exact Or.inr ⟨a :: x,d,t, congrArg (List.cons a) ht,
            congrArg (fun l => small a :: large a :: l) hp⟩

private def weighted (z : ℝ) (w : List ℝ) : ℝ := (1-z)*energy z w + (prod z w)^2

private theorem even_cut {z : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1) (x : List ℝ)
    (hx : ∀ a ∈ x, (1 : ℝ) ≤ a) (h : weighted (liftZ z) x ≤ 1) :
    weighted z (2 :: children x) ≤ 1 := by
  obtain ⟨hy₀,hy₁⟩ := lift_bounds hz h₁
  have hsq : (1 - z*2)^2 = 1-liftZ z := by unfold liftZ; ring
  have hhead : (1-z)*(z*2) = liftZ z/2 := by unfold liftZ; ring
  calc
    _ = (1-z)*(z*2) + (1-z*2)^2*((1-z)*energy z (children x)
        + (prod z (children x))^2) := by simp only [weighted, energy, prod]; ring
    _ ≤ liftZ z/2 + (1-liftZ z)*((1-liftZ z/2)*energy (liftZ z) x
        + (prod (liftZ z) x)^2) := by
      rw [hsq, hhead, split_prod z x hx]
      exact add_le_add_left (mul_le_mul_of_nonneg_left
        (add_le_add_right (split_energy hz h₁ x hx) _) (sub_nonneg.mpr hy₁)) _
    _ ≤ liftZ z/2 + (1-liftZ z/2)*weighted (liftZ z) x := by
      unfold weighted
      nlinarith only [mul_nonneg hy₀ (sq_nonneg (prod (liftZ z) x))]
    _ ≤ liftZ z/2 + (1-liftZ z/2)*1 :=
      add_le_add_left (mul_le_mul_of_nonneg_left h (by linarith)) _
    _ = 1 := by ring

private theorem append_small {z b : ℝ} (hz : 0 ≤ z) (h₁ : z ≤ 1) (hb : 1 ≤ b)
    (h₂ : b ≤ 2) (p : List ℝ) : weighted z (p ++ [b]) ≤ weighted z p := by
  have hx : (b-1)*z ≤ 1 := calc
    _ ≤ 1*z := mul_le_mul_of_nonneg_right (by linarith) hz
    _ ≤ 1 := by linarith
  have hloc : (1-z)*(z*b) + (1-z*b)^2 ≤ 1 := by
    nlinarith only [mul_nonpos_of_nonneg_of_nonpos
      (mul_nonneg hz (show 0 ≤ b by linarith)) (sub_nonpos.mpr hx)]
  calc
    _ = (1-z)*energy z p + (prod z p)^2*((1-z)*(z*b) + (1-z*b)^2) := by
      simp only [weighted, energy_append, prod_append, energy, prod, mul_zero, add_zero, mul_one]
      ring
    _ ≤ (1-z)*energy z p + (prod z p)^2*1 :=
      add_le_add_left (mul_le_mul_of_nonneg_left hloc (sq_nonneg _)) _
    _ = _ := by simp [weighted]

private theorem tail_bound (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (p s : List ℝ) (h : rawTail k = p ++ s) : weighted z p ≤ 1 := by
  induction k generalizing p s z with
  | zero =>
    cases p with
    | nil => simp [weighted, prod, energy]
    | cons b p => cases h
  | succ k ih =>
    cases p with
    | nil => simp [weighted, prod, energy]
    | cons b p =>
      obtain ⟨hb, hh⟩ := List.cons.inj h
      subst b
      obtain ⟨hy₀,hy₁⟩ := lift_bounds hz h₁
      have hcut : ∀ x t : List ℝ, rawTail k = x ++ t →
          weighted z (2 :: children x) ≤ 1 := by
        intro x t hxt
        apply even_cut hz h₁ x
        · intro a ha
          apply rawTail_lower k a
          rw [hxt]
          exact List.mem_append.mpr (Or.inl ha)
        · exact ih (liftZ z) hy₀ hy₁ x t hxt
      rcases child_cut (rawTail k) p s hh with ⟨x,t,hxt,hp⟩ | ⟨x,a,t,hxt,hp⟩
      · rw [hp]
        exact hcut x t hxt
      · have ha : 1 ≤ a := by
          apply rawTail_lower k a
          rw [hxt]
          simp
        obtain ⟨hlo,hhi⟩ := small_bounds ha
        rw [hp]
        exact le_trans (append_small hz h₁ hlo hhi (2 :: children x)) (hcut x _ hxt)

/-- The full estimate for every prefix of the particular raw recursive schedule. -/
theorem raw_stable (k : ℕ) (z : ℝ) (hz₀ : 0 ≤ z) (hz₁ : z ≤ 1) :
    Stable z (raw k) := by
  intro p s h
  cases p with
  | nil => simp [potential, energy, prod]
  | cons b p =>
    obtain ⟨hb, hh⟩ := List.cons.inj h
    subst b
    have ht := tail_bound k z hz₀ hz₁ p s hh
    calc
      potential z (1 :: p) = z + (1-z)^2*(energy z p + (prod z p)^2) := by
        simp only [potential, energy, prod, mul_one]
        ring
      _ ≤ z + (1-z)*weighted z p := by
        unfold weighted
        nlinarith only [mul_nonneg (mul_nonneg hz₀ (sub_nonneg.mpr hz₁)) (sq_nonneg (prod z p))]
      _ ≤ z + (1-z)*1 :=
        add_le_add_left (mul_le_mul_of_nonneg_left ht (sub_nonneg.mpr hz₁)) _
      _ = 1 := by ring

end

end GDProof.RawPrefix
