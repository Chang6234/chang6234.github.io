import GDProof.Endpoint

namespace GDProof.SlotWeight
open GDProof.Kernel GDProof.GuardSizes GDProof.Schedule GDProof.RawScales GDProof.Prefix
noncomputable section

/-- Raw endpoint factor at a physical slot; the factor is one on inserted slots. -/
def slotFactor (k : ℕ) (z : ℝ) (i : ℕ) : ℝ :=
  if i%3=1 then 1-z*(raw k).getD (i/3) 0 else 1

theorem raw_at_scale (k j : ℕ) (hj : j < 2^k) :
    0 ≤ (raw k).getD j 0 ∧ (raw k).getD j 0 ≤ 2*((Nat.gcd (2^k) (j+1) : ℕ) : ℝ)^2 := by
  have hl : (taggedRaw k).length = 2^k := by
    simpa [vals, raw_length] using congrArg List.length (taggedRaw_vals k)
  have htag : j < (taggedRaw k).length := by omega
  have hraw : j < (raw k).length := by simpa [raw_length] using hj
  have ha : (raw k).getD j 0 ∈ raw k := by
    rw [List.getD_eq_get _ _ hraw]; exact List.get_mem _ _ hraw
  refine ⟨zero_le_one.trans (raw_lower k _ ha),?_⟩
  let b := (taggedRaw k).getD j ((0:ℝ),0)
  have hb : b ∈ taggedRaw k := by
    dsimp only [b]; rw [List.getD_eq_get _ _ htag]; exact List.get_mem _ _ htag
  have hf : (raw k).getD j 0 = b.1 := by
    rw [← taggedRaw_vals k]
    exact List.getD_map (l := taggedRaw k) (d := ((0:ℝ),0)) Prod.fst
  rw [hf, ← tagged_scale_eq_gcd k j htag]
  exact raw_coefficient k b hb

/-- Endpoint bounds at the genuine guard selected by the dyadic valuation,
including empty guards. The same constant works for both endpoint directions. -/
theorem guard_endpoint :
    ∃ C : ℝ, 4 ≤ C ∧ ∀ k j z, 0 < z → z ≤ 1 →
      let b := history k (guardSize (2^k) j)
      let w := min ((Nat.gcd (2^k) (j+1) : ℝ)^2) z⁻¹
      max (response z (weight z) b) (reverseResponse z (weight z) b) ≤ C*w := by
  obtain ⟨A,_,ha⟩ := GDProof.Endpoint.guard_endpoints
  refine ⟨max 4 A,le_max_left _ _,?_⟩
  intro k j z hz hz1
  obtain ⟨hr,hf⟩ := ha k j z hz hz1
  dsimp only
  apply (max_le hf hr).trans
  exact mul_le_mul_of_nonneg_right (le_max_right _ _) (le_min (sq_nonneg _) (inv_nonneg.mpr hz.le))

theorem bound :
    ∃ C : ℝ, 1 ≤ C ∧ ∀ k z, 0 < z → z ≤ 1 → ∀ i, i < 3*2^k →
      let b := (guardBlocks (history k) (2^k) 0 (raw k)).getD i []
      let w := min ((Nat.gcd (2^k) (i/3+1) : ℝ)^2) z⁻¹
      max (response z (weight z) b) (reverseResponse z (weight z) b) ≤ C*w*(2+|slotFactor k z i|)^2 := by
  obtain ⟨C,hC,hguard⟩ := guard_endpoint
  refine ⟨C,by linarith,?_⟩
  intro k z hz hz1 i hi
  dsimp only
  let q := (Nat.gcd (2^k) (i/3+1) : ℝ)
  let W := min (q^2) z⁻¹
  have hW : 0 ≤ W := le_min (sq_nonneg _) (inv_nonneg.mpr hz.le)
  have hlen : i/3 < (raw k).length := by rw [raw_length];omega
  obtain ⟨hl,hm,hr⟩ := guardBlocks_site (history k) (2^k) 0 (raw k) (i/3) hlen
  simp only [Nat.zero_add] at hl hr
  by_cases h : i%3=1
  · have hx : 3*(i/3)+1=i := by omega
    rw [hx] at hm
    rw [hm]
    simp only [response,reverseResponse,product,mul_zero,mul_one,add_zero,max_self,slotFactor,if_pos h]
    let a := (raw k).getD (i/3) 0
    obtain ⟨ha,haq⟩ := raw_at_scale k (i/3) (by rw [raw_length] at hlen;exact hlen)
    change weight z a ≤ C*W*(2+|1-z*a|)^2
    apply (raw_endpoint hz ha).trans
    apply mul_le_mul_of_nonneg_right _ (sq_nonneg _)
    have ht : min a z⁻¹ ≤ 2*W := by
      dsimp only [W]
      by_cases hc : q^2 ≤ z⁻¹
      · rw [min_eq_left hc]
        exact (min_le_left _ _).trans haq
      · rw [min_eq_right (le_of_not_ge hc)]
        linarith only [min_le_right a z⁻¹,inv_nonneg.mpr hz.le]
    exact ht.trans (mul_le_mul_of_nonneg_right (by linarith only [hC]) hW)
  · have hb : (guardBlocks (history k) (2^k) 0 (raw k)).getD i [] = history k (guardSize (2^k) (i/3)) := by
      by_cases h₀ : i%3=0
      · rwa [show 3*(i/3)=i by omega] at hl
      · rwa [show 3*(i/3)+2=i by omega] at hr
    rw [hb]
    simp only [slotFactor,if_neg h,abs_one]
    have hedge := hguard k (i/3) z hz hz1
    change _ ≤ C*W at hedge
    change _ ≤ C*W*(2+1)^2
    nlinarith only [hedge, mul_nonneg (by linarith only [hC] : 0 ≤ C) hW]
end
end GDProof.SlotWeight
