import GDProof.SlotWeight

namespace GDProof.SameSite

open Kernel
noncomputable section

private theorem shape (bs : List (List ℝ)) (z a : ℝ) (g : List ℝ) (j : ℕ)
    (hi : 3*j+1 < bs.length) (hg₀ : bs.getD (3*j) [] = g)
    (ha : bs.getD (3*j+1) [] = [a]) (hg₂ : bs.getD (3*j+2) [] = g) :
    blockPair z bs (3*j) 0 = reverseResponse z (weight z) g * weight z a ∧
    blockPair z bs (3*j+1) 0 = weight z a * response z (weight z) g ∧
    blockPair z bs (3*j) 1 = reverseResponse z (weight z) g *
      ((1-z*a)^2 * response z (weight z) g) := by
  have hh : ((bs.drop (3*j+1)).take 1) = [[a]] := by
    rw [List.drop_eq_get_cons hi]
    have he : bs.get ⟨3*j+1,hi⟩ = [a] := by simpa only [List.getD_eq_get _ _ hi] using ha
    simp [he]
  simp only [blockPair, Nat.add_zero, hg₀, ha, hg₂, hh, List.take_zero,
    joinBlocks, List.append_nil, product, response, reverseResponse, factor, zero_mul,
    mul_zero, add_zero, mul_one, one_mul, List.cons_append, List.nil_append]
  exact ⟨trivial, trivial, trivial⟩

/-- All three pairs inside a site carry at most a constant times its fourth
power scale. At most one raw coefficient lies strictly between the endpoints. -/
theorem scalar {z a Q C U V : ℝ} (hz : 0 < z) (hQ : 0 ≤ Q) (hC : 0 ≤ C)
    (ha : 0 ≤ a) (hmax : a ≤ 2*Q) (hU : 0 ≤ U)
    (hu : U ≤ C*min Q z⁻¹) (hv : V ≤ C*min Q z⁻¹) :
    V*weight z a ≤ 16*(1+C)^2*Q^2 ∧ weight z a*U ≤ 16*(1+C)^2*Q^2 ∧
    V*((1-z*a)^2*U) ≤ 16*(1+C)^2*Q^2 := by
  let W := min Q z⁻¹
  let s := 1+z*Q
  have hw : 0 ≤ W := le_min hQ (inv_nonneg.mpr hz.le)
  have hs : 0 ≤ s := by dsimp [s]; positivity
  have hws : W*s ≤ 2*Q := by simpa only [W,s,mul_comm] using capped_weight hz hQ
  have hza := mul_le_mul_of_nonneg_left hmax hz.le
  have h₁ : 0 ≤ 1+z*a := by positivity
  have h₂ : 1+z*a ≤ 2*s := by dsimp [s]; linarith only [hza]
  have hraw : weight z a ≤ 4*Q*s := by
    have hh := mul_le_mul hmax h₂ h₁ (mul_nonneg (by norm_num) hQ)
    unfold weight
    nlinarith only [hh]
  have habs : |1-z*a| ≤ 2*s := by
    rw [abs_le]
    dsimp only [s]
    have hp := mul_nonneg hz.le hQ
    have hp' := mul_nonneg hz.le ha
    constructor <;> linarith only [hza,hp,hp']
  have hsquare := pow_le_pow_left (abs_nonneg (1-z*a)) habs 2
  rw [sq_abs] at hsquare
  have hsqws := pow_le_pow_left (mul_nonneg hw hs) hws 2
  have hdom : 8*C*Q^2 ≤ 16*(1+C)^2*Q^2 := by
    apply mul_le_mul_of_nonneg_right _ (sq_nonneg _)
    nlinarith only [hC,sq_nonneg C]
  have bound (X : ℝ) (hx : X ≤ C*W) : X*weight z a ≤ 16*(1+C)^2*Q^2 := by
    have hl := mul_le_mul hx hraw (weight_nonneg hz.le ha) (mul_nonneg hC hw)
    have hr := mul_le_mul_of_nonneg_left hws (mul_nonneg (mul_nonneg (by norm_num : 0 ≤ (4:ℝ)) hC) hQ)
    apply le_trans _ hdom
    nlinarith only [hl,hr]
  refine ⟨bound V hv,by simpa only [mul_comm] using bound U hu,?_⟩
  calc
    _ = (V*U)*(1-z*a)^2 := by ring
    _ ≤ (C*W*(C*W))*(2*s)^2 := mul_le_mul
      (mul_le_mul hv hu hU (mul_nonneg hC hw)) hsquare (sq_nonneg _) (by positivity)
    _ = 4*C^2*(W*s)^2 := by ring
    _ ≤ 4*C^2*(2*Q)^2 := mul_le_mul_of_nonneg_left hsqws (by positivity)
    _ ≤ _ := by
      have hc : C^2 ≤ (1+C)^2 := pow_le_pow_left hC (by linarith) 2
      nlinarith only [mul_le_mul_of_nonneg_right hc (sq_nonneg Q)]

theorem at_site (bs : List (List ℝ)) (z a : ℝ) (g : List ℝ) (j : ℕ) {Q C : ℝ}
    (hi : 3*j+1 < bs.length) (hg₀ : bs.getD (3*j) [] = g)
    (ha' : bs.getD (3*j+1) [] = [a]) (hg₂ : bs.getD (3*j+2) [] = g)
    (hz : 0 < z) (hQ : 0 ≤ Q) (hC : 0 ≤ C) (ha : 0 ≤ a) (hmax : a ≤ 2*Q)
    (hg : ∀ b ∈ g, 0 ≤ b) (hu : response z (weight z) g ≤ C*min Q z⁻¹)
    (hv : reverseResponse z (weight z) g ≤ C*min Q z⁻¹)
    (i t : ℕ) (hij : i/3=j) (hij' : (i+1+t)/3=j) :
    blockPair z bs i t ≤ 16*(1+C)^2*Q^2 := by
  have hpos (b : ℝ) (hb : b ∈ g) : 0 ≤ weight z b := weight_nonneg hz.le (hg b hb)
  have hS := scalar hz hQ hC ha hmax (response_nonneg z _ g hpos)
    hu hv
  obtain ⟨h₁,h₂,h₃⟩ := shape bs z a g j hi hg₀ ha' hg₂
  have hcase : (i=3*j ∧ t=0) ∨ (i=3*j+1 ∧ t=0) ∨ (i=3*j ∧ t=1) := by omega
  rcases hcase with ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩ | ⟨rfl,rfl⟩
  · exact h₁.trans_le hS.1
  · exact h₂.trans_le hS.2.1
  · exact h₃.trans_le hS.2.2

open Schedule

theorem from_endpoint {C : ℝ} (hC : 4 ≤ C)
    (hraw : ∀ k j : ℕ, j < 2^k →
      0 ≤ (raw k).getD j 0 ∧ (raw k).getD j 0 ≤ 2*(Nat.gcd (2^k) (j+1):ℝ)^2)
    (hend : ∀ (k j : ℕ) (z : ℝ), 0 < z → z ≤ 1 →
      let g := history k (guardSize (2^k) j)
      max (response z (weight z) g) (reverseResponse z (weight z) g) ≤
        C*min ((Nat.gcd (2^k) (j+1):ℝ)^2) z⁻¹) :
    ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 → ∀ i t : ℕ, i < 3*2^k →
      t < 3*2^k-(i+1) → i/3=(i+1+t)/3 →
      blockPair z (guardBlocks (history k) (2^k) 0 (raw k)) i t ≤
        (16*(1+C)^2)*(Nat.gcd (2^k) (i/3+1):ℝ)^4 := by
  intro k z hz h₁ i t hi _ heq
  let j := i/3
  let Q := (Nat.gcd (2^k) (j+1):ℝ)^2
  let g := history k (guardSize (2^k) j)
  let bs := guardBlocks (history k) (2^k) 0 (raw k)
  have hj : j < 2^k := by dsimp only [j]; omega
  have hlen : j < (raw k).length := by simpa only [raw_length] using hj
  have hbl : 3*j+1 < bs.length := by
    dsimp only [bs]
    rw [guardBlocks_length,raw_length]
    omega
  obtain ⟨hg₀,ha,hg₂⟩ := guardBlocks_site (history k) (2^k) 0 (raw k) j hlen
  simp only [Nat.zero_add] at hg₀ hg₂
  obtain ⟨ha₀,hmax⟩ := hraw k j hj
  have hp : ∀ b ∈ g, 0 ≤ b := fun b hb => zero_le_one.trans (history_lower k _ b hb)
  have hb := hend k j z hz h₁
  have hh := at_site bs z ((raw k).getD j 0) g j (Q:=Q) (C:=C) hbl hg₀ ha hg₂ hz
    (sq_nonneg _) ((by norm_num : (0:ℝ) ≤ 4).trans hC) ha₀ hmax hp
    ((le_max_left _ _).trans hb) ((le_max_right _ _).trans hb) i t rfl heq.symm
  change blockPair z bs i t ≤ _ at hh ⊢
  calc
    _ ≤ _ := hh
    _ = _ := by dsimp [Q,j]; ring

/-- Uniform same-site contribution for all physical slot pairs of the
implemented guarded schedule. -/
theorem same_site : ∃ B : ℝ, 0 < B ∧ ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 →
    ∀ i t : ℕ, i < 3*2^k → t < 3*2^k-(i+1) → i/3=(i+1+t)/3 →
      blockPair z (guardBlocks (history k) (2^k) 0 (raw k)) i t ≤
        B*(Nat.gcd (2^k) (i/3+1):ℝ)^4 := by
  obtain ⟨C,hC,hguard⟩ := SlotWeight.guard_endpoint
  have hp : 0 < 1+C := by linarith only [hC]
  exact ⟨16*(1+C)^2, mul_pos (by norm_num) (sq_pos_of_pos hp),
    from_endpoint hC SlotWeight.raw_at_scale hguard⟩

end
end GDProof.SameSite
