import GDProof.Kernel

/-! Exact numerical estimates and the induction on the guarded schedule in
the appendix on propagation matrices. The final theorem accepts the
paper's estimate for pairs in distinct blocks as an explicit hypothesis. -/
namespace GDProof.KernelArithmetic
open scoped BigOperators
open GDProof.Kernel

noncomputable section

/-- Ordinary gain squared plus curvature-weighted gain squared. -/
def gain (z : ℝ) (w : List ℝ) : ℝ := pairSum z id (weight z) w

private theorem right_weights (z : ℝ) (w : List ℝ) :
    response z (weight z) w = response z id w + response z (fun h => z*h^2) w := by
  induction w with
  | nil => simp [response]
  | cons h w ih => simp only [response, ih, weight, id_eq]; ring

theorem gain_split (z : ℝ) (w : List ℝ) :
    gain z w = pairSum z id id w + pairSum z id (fun h => z*h^2) w := by
  induction w with
  | nil => simp [gain, pairSum]
  | cons h w ih =>
    unfold gain at *
    simp only [pairSum, right_weights, ih]
    ring

/-- Ordered pairs in two different physical blocks use the left suffix mass
and the right forward response. -/
def cross (z : ℝ) : List (List ℝ) → ℝ
  | [] => 0
  | w::ws => reverseResponse z id w * later z ws + cross z ws

private theorem partition (z : ℝ) (ws : List (List ℝ)) :
    gain z (joinBlocks ws) = (ws.map (gain z)).sum + cross z ws := by
  induction ws with
  | nil => simp [joinBlocks, gain, pairSum, cross]
  | cons w ws ih =>
    simp only [joinBlocks, List.map_cons, List.sum_cons, cross]
    unfold gain at *
    rw [pairSum_append, response_joinBlocks, ih]
    ring

private theorem guards (z : ℝ) (previous : ℕ → List ℝ) (n j : ℕ) (coeffs : List ℝ) :
    ((guardBlocks previous n j coeffs).map (gain z)).sum =
      2 * ∑ i ∈ Finset.range coeffs.length, gain z (previous (Schedule.guardSize n (j+i))) := by
  induction coeffs generalizing j with
  | nil => simp [guardBlocks]
  | cons a w ih =>
    have hsingle : gain z [a] = 0 := by simp [gain, pairSum, response]
    simp only [guardBlocks, List.map_cons, List.sum_cons, hsingle, ih, List.length_cons,
      Finset.sum_range_succ', Nat.add_zero]
    have shift : (∑ i ∈ Finset.range w.length, gain z (previous (Schedule.guardSize n (j+(i+1))))) =
        ∑ i ∈ Finset.range w.length, gain z (previous (Schedule.guardSize n (j+1+i))) :=
      Finset.sum_congr rfl (fun i _ => by rw [show j+(i+1)=j+1+i by omega])
    rw [shift]
    ring

def blocks (k : ℕ) := guardBlocks (Schedule.history k) (2^k) 0 (Schedule.raw k)

theorem gain_table_partition (z : ℝ) (k : ℕ) :
    gain z (Schedule.table k) =
      2 * ∑ j ∈ Finset.range (2^k), gain z (Schedule.history k (Schedule.guardSize (2^k) j)) +
      cross z (blocks k) := by
  rw [Schedule.table_unfold, ← join_guardBlocks, partition, guards, Schedule.raw_length]
  simp [blocks]

/-- Constants in the two geometric series bounding the endpoint sum. -/
theorem geometric_endpoints :
    (4/3:ℝ)*Real.sqrt 2048 < 61 ∧
    (256/Real.sqrt 2048)/(1-(1/262144:ℝ)) < 6 := by
  have hu : Real.sqrt 2048 < 91/2 := (Real.sqrt_lt' (by norm_num)).2 (by norm_num)
  have hl : 45 < Real.sqrt 2048 :=
    (Real.lt_sqrt (by norm_num : (0:ℝ) ≤ 45)).2 (by norm_num)
  constructor
  · linarith
  · apply (div_lt_iff (by norm_num : (0:ℝ) < 1-1/262144)).2
    apply (div_lt_iff (by positivity : 0 < Real.sqrt 2048)).2
    nlinarith only [hl]

theorem geometric_rows {q a : ℝ} (hq : 0 ≤ q) (hq1 : q < 1) (ha : 0 ≤ a) (N : ℕ) :
    ∑ i ∈ Finset.range N, a*q^i ≤ a/(1-q) := by
  rw [← Finset.mul_sum]
  apply (le_div_iff (by linarith : 0 < 1-q)).2
  rw [mul_assoc, geom_sum_mul_neg]
  nlinarith only [mul_nonneg ha (pow_nonneg hq N)]

theorem geometric_sum_bound (N M : ℕ) :
    (∑ i ∈ Finset.range N, Real.sqrt 2048*(1/4:ℝ)^i) +
    (∑ i ∈ Finset.range M, (256/Real.sqrt 2048)*(1/262144:ℝ)^i) < 67 := by
  have h1 := geometric_rows (q:=1/4) (a:=Real.sqrt 2048) (by norm_num) (by norm_num)
    (Real.sqrt_nonneg _) N
  have h2 := geometric_rows (q:=1/262144) (a:=256/Real.sqrt 2048) (by norm_num) (by norm_num)
    (by positivity) M
  obtain ⟨hc, hd⟩ := geometric_endpoints
  rw [show Real.sqrt 2048 / (1-1/4) = 4/3 * Real.sqrt 2048 by ring] at h1
  linarith

theorem endpoint_factors :
    1 + 8*Real.sqrt 2*25 < 284 ∧ 1 + 8*Real.sqrt 2*25*67 < 18952 := by
  have h : Real.sqrt 2 < 141422/100000 :=
    (Real.sqrt_lt' (by norm_num)).2 (by norm_num)
  constructor <;> linarith

theorem linear_endpoint {x T : ℝ} (hx : 1 ≤ x)
    (hT : T ≤ 1+8*Real.sqrt 2*25*x) : T ≤ 284*x := by
  have h := mul_le_mul_of_nonneg_right endpoint_factors.1.le (show 0 ≤ x by linarith)
  linarith

theorem uniform_endpoint {s T : ℝ} (hs : s ≤ 67)
    (hT : T ≤ 1+8*Real.sqrt 2*25*s) : T ≤ 18952 := by
  have h := mul_le_mul_of_nonneg_left hs (show 0 ≤ 8*Real.sqrt 2*25 by positivity)
  linarith [endpoint_factors.2]

/-- The cross-block coefficient from the regular and same-site pair estimates. -/
def crossCoefficient : ℝ :=
  16*(9+3*284/4)*(25+5/2)+(8/7)*(14*18952+4)

theorem quartic_margin : crossCoefficient + 405000/127 < 405000 := by
  norm_num [crossCoefficient]

/-- For the actual guarded table, the explicit bound for cross-block pairs
implies the advertised bound on both gains. The within-block recurrence,
the strict reduction in guard degrees and the fourth moment are discharged. -/
theorem table_gain_of_cross (z : ℝ)
    (hp : ∀ k, cross z (blocks k) ≤ crossCoefficient * ((2:ℝ)^k)^4)
    (k : ℕ) : gain z (Schedule.table k) ≤ (900:ℝ)^2/2 * ((2:ℝ)^k)^4 := by
  have hh : ∀ l n : ℕ, gain z (Schedule.history l n) ≤ 405000*(n:ℝ)^4 := by
    intro l
    induction l with
    | zero => intro n; simp only [Schedule.history,gain,pairSum]; positivity
    | succ l ih =>
      intro n
      by_cases hn : n=2^l
      · subst n
        change gain z (Schedule.table l) ≤ _
        rw [gain_table_partition]
        push_cast
        have hs := Finset.sum_le_sum (s:=Finset.range (2^l))
          (fun j _ => ih (Schedule.guardSize (2^l) j))
        rw [← Finset.mul_sum] at hs
        have hf := mul_le_mul_of_nonneg_left (guard_fourth_moment l)
          (show (0:ℝ) ≤ 405000 by norm_num)
        have hq := mul_le_mul_of_nonneg_right quartic_margin.le
          (show (0:ℝ) ≤ ((2:ℝ)^l)^4 by positivity)
        nlinarith only [hs,hf,hp l,hq]
      · rw [Schedule.history, if_neg hn]
        exact ih n
  simpa only [Schedule.table,Nat.cast_pow,Nat.cast_ofNat,
    show (900:ℝ)^2/2=405000 by norm_num] using hh (k+1) (2^k)

/-- The two nonnegative error norms combine by Cauchy--Schwarz on ℝ². -/
theorem transfer_factor {u v b : ℝ} (hb : 0 ≤ b)
    (h : u^2+v^2 ≤ 405000*b^2) : u+v ≤ 900*b := by
  have hk : (u+v)^2 ≤ (900*b)^2 := by nlinarith only [h, sq_nonneg (u-v)]
  by_contra hn
  push_neg at hn
  have hp := mul_pos (sub_pos.mpr hn) (show 0 < u+v+900*b by linarith)
  nlinarith only [hp,hk]

end
end GDProof.KernelArithmetic
