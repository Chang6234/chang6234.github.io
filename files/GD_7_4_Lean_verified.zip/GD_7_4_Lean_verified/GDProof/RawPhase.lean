import GDProof.RawInterval

/-! Exact trigonometric identities for the raw steps of the quadratic schedule. -/
namespace GDProof.RawPhase

open GDProof.Schedule GDProof.Prefix GDProof.RawInterval

private theorem double_angle (k : ℕ) (u : ℝ) :
    (2:ℝ)^(k+1)*u = 2*((2:ℝ)^k*u) := by rw [pow_succ]; ring

theorem folded_sine (k : ℕ) (u : ℝ) :
    folded k (Real.sin u ^ 2) = Real.sin ((2:ℝ)^k*u)^2 := by
  induction k with
  | zero => simp [folded]
  | succ k ih =>
    rw [folded, ih, double_angle, Real.sin_two_mul,
        ← Real.cos_sq' ((2:ℝ)^k*u)]
    ring

theorem layer_product (k : ℕ) (u : ℝ) :
    prod (Real.sin u ^ 2) (descendants k 2) = Real.cos ((2:ℝ)^(k+1)*u) := by
  rw [descendants_prod k (by norm_num : (1:ℝ) ≤ 2), folded_sine, double_angle,
    Real.cos_two_mul']
  linarith [Real.sin_sq_add_cos_sq ((2:ℝ)^k*u)]

theorem raw_phase_identity (k : ℕ) (u : ℝ) :
    ((2:ℝ)^(k+1) * Real.sin u) * prod (Real.sin u ^ 2) (raw k) =
      Real.cos u * Real.sin ((2:ℝ)^(k+1)*u) := by
  induction k with
  | zero =>
    simp only [Nat.zero_add, pow_one, raw, rawTail, prod, mul_one]
    rw [Real.sin_two_mul]
    rw [← Real.cos_sq' u]
    ring
  | succ k ih =>
    rw [raw_snoc, prod_append, layer_product, double_angle (k+1) u, Real.sin_two_mul]
    calc
      _ = 2 * (((2:ℝ)^(k+1)*Real.sin u)*prod (Real.sin u ^ 2) (raw k)) *
            Real.cos ((2:ℝ)^(k+1)*u) := by rw [pow_succ (2:ℝ) (k+1)]; ring
      _ = _ := by rw [ih]; ring

theorem raw_phase_product (k : ℕ) (u : ℝ) (h : Real.sin u ≠ 0) :
    prod (Real.sin u ^ 2) (raw k) =
      (Real.cos u * Real.sin ((2:ℝ)^(k+1)*u)) / ((2:ℝ)^(k+1)*Real.sin u) := by
  apply (eq_div_iff (mul_ne_zero (pow_ne_zero _ (by norm_num)) h)).2
  rw [mul_comm]
  exact raw_phase_identity k u

end GDProof.RawPhase
