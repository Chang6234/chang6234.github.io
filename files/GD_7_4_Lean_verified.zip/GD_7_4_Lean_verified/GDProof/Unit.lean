import GDProof.Statement
import GDProof.Descent
import GDProof.UnitTrace

namespace GDProof

/-- For the exact unit table, at most 2 + 2LΔ/ε² gradient evaluations
suffice, including the initial query. The result uses the true objective and
the actual Model.run; all smoothness input comes from Problem. -/
theorem unit_table_bound {d : ℕ} (P : Problem d) (ε : ℝ) (hε : 0 < ε) (x₀ : Space d) :
    ∃ (k : ℕ) (s : Model.State (Space d)),
      Model.run P.grad P.L ε [1] (Model.initial P.grad x₀ [1] ε) k = some s ∧
      ‖P.grad s.x‖ ≤ ε ∧
      ((k + 1 : ℕ) : ℝ) ≤ 2 + 2 * P.L * (P.f x₀ - sInf (Set.range P.f)) / ε^2 := by
  let l := sInf (Set.range P.f)
  let Δ := P.f x₀ - l
  let a := 2 * P.L * Δ / ε^2
  let N := ⌊a⌋₊ + 1
  have hl (x : Space d) : l ≤ P.f x := csInf_le P.bounded ⟨x, rfl⟩
  have hΔ : 0 ≤ Δ := sub_nonneg.mpr (hl x₀)
  have hL := P.L_pos
  have ha : 0 ≤ a := by dsimp [a]; positivity
  have h₂ : 0 < 2 * P.L := by positivity
  have hε₂ := sq_pos_of_pos hε
  have haN : a < (N : ℝ) := by
    simpa only [N, Nat.cast_add, Nat.cast_one] using Nat.lt_floor_add_one a
  change 2 * P.L * Δ / ε^2 < (N : ℝ) at haN
  have hm := (div_lt_iff hε₂).mp haN
  have hN : Δ < (N : ℝ) * (ε^2 / (2 * P.L)) := by
    rw [← mul_div_assoc, lt_div_iff h₂]
    nlinarith only [hm]
  obtain ⟨k, s, hk, hr, hs⟩ := UnitTrace.unit_terminates_by P.f P.grad P.L ε l x₀
    hL hε hl (Descent.ordinary_gradient_step P.f P.grad P.L hL P.gradientAt P.lipGrad) N hN
  refine ⟨k,s,hr,hs,?_⟩
  have hf := Nat.floor_le ha
  have hk' : (k : ℝ) ≤ (N : ℝ) := by exact_mod_cast hk
  rw [show (N : ℝ) = (⌊a⌋₊ : ℕ) + (1 : ℝ) by simp [N]] at hk'
  change ((k+1 : ℕ) : ℝ) ≤ 2 + a
  rw [Nat.cast_succ]
  linarith only [hf, hk']

end GDProof
