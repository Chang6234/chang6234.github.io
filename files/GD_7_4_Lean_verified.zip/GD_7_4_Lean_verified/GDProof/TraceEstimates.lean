import GDProof.Descent
import GDProof.TraceData
import GDProof.Statement

namespace GDProof.TraceData.Input
open GDProof.Model
open scoped BigOperators
noncomputable section

/-- The actual accumulated gradient test along an epoch, with the table mass
and the measured spending supplying the trajectory radius. -/
theorem observable {d : ℕ} (P : Problem d) (a : Input (Space d))
    (hg : a.grad = P.grad) (hL : a.L = P.L) (n : ℕ) (hn : n ≤ a.table.length)
    (H : ℝ) (ht : ∀ b ∈ a.table, 0 ≤ b) (hmax : ∀ b ∈ a.table, b ≤ H) :
    let R := Real.sqrt (a.table.sum*(a.row n).spent)/P.L
    |((a.row n).spent + (a.row n).cross)/2 - P.L*(P.f a.x0-P.f (a.row n).x)| ≤
      (a.row n).spent*((P.ρ*R/P.L)*H)/12 := by
  intro R
  have h := Descent.gd_prefix_observable P.f a.grad P.hess (by simpa [hg] using P.gradientAt)
    (by simpa [hg] using P.hessianAt) P.L P.ρ P.L_pos P.ρ_pos.le P.lipHess n
    (fun i => (a.row i).x) a.coef (fun i hi => a.coef_nonnegative i (by omega) ht)
    (fun i _ => by simpa only [hL] using a.row_succ_x i)
    a.table.sum H (a.sum_coef_le_table n hn ht) (fun i hi => (a.coef_le_table i).trans (by
      have hi' : i < a.table.length := by omega
      rw [List.getD_eq_get _ _ hi']
      exact hmax _ (List.get_mem _ _ _)))
  dsimp only at h
  rw [← a.spent_sum n, ← a.cross_sum n] at h
  change |((a.row n).spent+(a.row n).cross)/2 - P.L*(P.f a.x0-P.f (a.row n).x)| ≤
    P.ρ*R/(12*P.L)*H*(a.row n).spent at h
  convert h using 1
  ring

/-- When the squared starting gradient sets the cap, the first unit step
completes the epoch with nonnegative alignment and sufficient actual decrease. -/
theorem large_cap_drop {d : ℕ} (P : Problem d) (a : Input (Space d))
    (hg : a.grad = P.grad) (hL : a.L = P.L) (n : ℕ) (hn₀ : 0 < n)
    (hbefore : ∀ i < n, ¬ a.event i) (hfirst : a.table.getD 0 0 = 1)
    (hε : 0 ≤ a.ε) (hactive : a.ε < ‖a.grad a.x0‖) (hE : a.E ≤ ‖a.grad a.x0‖^2) :
    n = 1 ∧ 0 ≤ (a.row n).cross ∧ 3*a.E/16 ≤ P.L*(P.f a.x0-P.f (a.row n).x) := by
  have hq := sq_pos_of_pos (lt_of_le_of_lt hε hactive)
  have hcap : a.cap = ‖a.grad a.x0‖^2 := max_eq_right hE
  have hcoef : a.coef 0 = 1 := by simp [coef, row, hfirst, clip, hcap, hq.ne']
  have hspent : (a.row 1).spent = a.cap := by
    rw [show (1:ℕ)=0+1 by rfl, a.row_succ_spent, hcoef, hcap]
    simp [row]
  have hn : n = 1 := by
    by_contra hn
    exact hbefore 1 (by omega) (Or.inr hspent)
  subst n
  have hx : (a.row 1).x = a.x0 - (1/P.L) • P.grad a.x0 := by
    rw [show (1:ℕ)=0+1 by rfl, a.row_succ_x, hcoef, hL, hg]
    rfl
  have hdist : ‖(a.row 1).x-a.x0‖ = (1/P.L)*‖P.grad a.x0‖ := by
    rw [hx, show a.x0-(1/P.L) • P.grad a.x0-a.x0 = -((1/P.L) • P.grad a.x0) by abel,
      norm_neg, norm_smul_of_nonneg (show 0 ≤ 1/P.L by have := P.L_pos; positivity)]
  have hdiff : ‖P.grad (a.row 1).x - P.grad a.x0‖ ≤ ‖P.grad a.x0‖ := by
    calc
      _ ≤ _ := P.lipGrad _ _
      _ = _ := by rw [hdist]; field_simp [P.L_pos.ne']
  have hcross := Descent.unit_step_alignment _ _ hdiff
  have hdrop := Descent.ordinary_gradient_step P.f P.grad P.L P.L_pos P.gradientAt P.lipGrad a.x0
  rw [← hx] at hdrop
  have hdec : ‖P.grad a.x0‖^2 / (2*P.L) ≤ P.f a.x0 - P.f (a.row 1).x := by linarith
  have he := (div_le_iff (show 0 < 2*P.L by have := P.L_pos; positivity)).mp hdec
  rw [hg] at hE
  refine ⟨rfl, ?_, ?_⟩
  · rw [show (1:ℕ)=0+1 by rfl, a.row_succ_cross, hcoef]
    change 0 ≤ 0+1*⟪a.grad a.x0, a.grad (a.row 1).x⟫_ℝ
    simpa [hg] using hcross
  · nlinarith only [he, hE, sq_nonneg ‖P.grad a.x0‖]

end
end GDProof.TraceData.Input
