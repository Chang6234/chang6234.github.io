import GDProof.TraceEstimates
import GDProof.EpochLength
import GDProof.Reduction
import GDProof.Epoch
import GDProof.Geometry

/-! Local descent of the actual dyadic GD run from the nonlinear Taylor
estimate (B.2). The estimate is needed only on budget-capped first-event
prefixes. The counting and restart consequences are proved here. -/
namespace GDProof.Local
open GDProof.Schedule GDProof.TraceData GDProof.Model
noncomputable section

def epochInput {d : ℕ} (P : Problem d) (ε : ℝ) (k : ℕ) (x : Space d) (E : ℝ) :
    Input (Space d) := ⟨P.grad, P.L, ε, table (k+1), x, E⟩

/-- The remaining analytical hypothesis is (B.2) on the unreset rows of the
explicit GD algorithm. All budgets, coefficients and points here are fixed
by the stated problem and its initial data. -/
def BudgetChange {d : ℕ} (P : Problem d) (ε : ℝ) (k : ℕ) (K : ℝ) : Prop :=
  ∀ (x : Space d) (E : ℝ) (n : ℕ),
    let a := epochInput P ε k x E
    let m := (2 : ℝ)^(k+1)
    let R := Real.sqrt (a.table.sum*E)/P.L
    0 < E → E ≤ ε^2*a.table.sum/2 → a.cap = E → 0 < n → n ≤ a.table.length →
    (∀ i < n, ¬ a.event i) → (a.row n).spent = E →
    -(P.L*(P.f x-P.f (a.row n).x)) ≤
      E*(-1+(1+K*(m^2*(P.ρ*R/P.L)))^2/2+((P.ρ*R/P.L)*(m^2/2))/2)

private theorem root_two_coeff : (1 : ℝ)/Real.sqrt 2 ≤ 3/4 := by
  apply (div_le_iff (show 0 < Real.sqrt 2 by positivity)).2
  by_contra! h
  have hh : Real.sqrt 2 < 4/3 := by linarith
  have hs := pow_lt_pow_left hh (Real.sqrt_nonneg 2) (by decide : (2 : ℕ) ≠ 0)
  rw [Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)] at hs
  norm_num at hs

/-- Normalization of B.1 and B.2 with the exact constants used by the
observable alignment decision. The shrink factor does not depend on ε or d. -/
theorem normalize {L ρ ε m M E K C D : ℝ}
    (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε) (hM : 0 < M) (hE : 0 ≤ E)
    (hK : 0 ≤ K) (hmass : M ≤ 2*m^2) (hEhi : E ≤ ε^2*M/2)
    (hstable : ρ*ε*m^4/L^2 ≤ 1)
    (herr : let R := Real.sqrt (M*E)/L;
            |(E+C)/2-D| ≤ E*((ρ*R/L)*(m^2/2))/12)
    (hmodel : let R := Real.sqrt (M*E)/L;
              -D ≤ E*(-1+(1+K*(m^2*(ρ*R/L)))^2/2+((ρ*R/L)*(m^2/2))/2)) :
    Epoch.Estimates (K*Real.sqrt 2) E (ε^2*M/2) C D := by
  let R := Real.sqrt (M*E)/L
  let e := Real.sqrt (E/(ε^2*M/2))
  have hs := Geometry.epoch_scale (H := m^2/2) hL hρ hε hM hE hmass le_rfl hstable
  change ρ*R/L*(m^2/2) ≤ 1/Real.sqrt 2*e ∧ m^2*(ρ*R/L) ≤ Real.sqrt 2*e at hs
  refine ⟨hEhi, K*(m^2*(ρ*R/L)), (ρ*R/L)*(m^2/2), ?_, ?_, ?_, herr, hmodel⟩
  · dsimp only [R]
    positivity
  · calc
      K*(m^2*(ρ*R/L)) ≤ K*(Real.sqrt 2*e) := mul_le_mul_of_nonneg_left hs.2 hK
      _ = (K*Real.sqrt 2)*e := by ring
  · exact hs.1.trans (mul_le_mul_of_nonneg_right root_two_coeff (Real.sqrt_nonneg _))

/-- The actual reset-and-clip GD satisfies the one-epoch progress property
from the budget-case Taylor inequality alone. -/
theorem localEpoch_of_change {d : ℕ} (P : Problem d) (ε : ℝ) (k : ℕ) (K : ℝ)
    (hε : 0 < ε) (hK : 0 ≤ K)
    (hstable : P.ρ*ε*((2 : ℝ)^(k+1))^4/P.L^2 ≤ 1) (hB : BudgetChange P ε k K) :
    Reduction.LocalEpoch P ε (table (k+1))
      (Epoch.threshold (K*Real.sqrt 2) 1) ((1+K*Real.sqrt 2)^2) := by
  let M := (table (k+1)).sum
  let m := (2 : ℝ)^(k+1)
  let E₀ := ε^2*M/2
  let A := K*Real.sqrt 2
  let c := Epoch.threshold A 1
  have hM : 0 < M := by
    dsimp only [M]
    nlinarith only [table_sum_lower (k+1), sq_nonneg ((2 : ℝ)^(k+1))]
  have hE₀ : 0 < E₀ := by dsimp only [E₀]; positivity
  have hA : 0 ≤ A := by dsimp only [A]; positivity
  have hc : 0 < c := Epoch.threshold_pos hA zero_lt_one
  have heform : ε^2/2*(table (k+1)).sum = E₀ := by dsimp only [E₀,M]; ring
  have hth : Epoch.threshold A E₀ = c*E₀ := by dsimp only [c, Epoch.threshold]; ring
  intro x E hlo hhi hx
  rw [heform] at hlo hhi
  change c*E₀/2 ≤ E at hlo
  have hE : 0 < E := by linarith only [hlo, mul_pos hc hE₀]
  let a := epochInput P ε k x E
  obtain ⟨n, hn, hlen, he, hpre⟩ :=
    EpochLength.first_event a (k+1) rfl hε.le hx hhi
  refine ⟨n, a.endpoint n, hn, hlen, a.run_to_endpoint n hn hlen hpre, ?_, ?_⟩
  · rw [a.endpoint_g, a.endpoint_x]
    rfl
  rcases a.endpoint_of_event n he with hstop | ⟨hspent, hout⟩
  · exact Or.inl hstop
  right
  simp only [Input.endpoint_x, Input.endpoint_g]
  by_cases hbig : E ≤ ‖P.grad x‖^2
  · have hunit := Input.large_cap_drop P a rfl rfl n hn hpre (EpochLength.table_first (k+1))
      hε.le hx hbig
    rcases hout with ⟨_, hu⟩ | ⟨hf, _⟩
    · exact Or.inl ⟨hu, hunit.2.2⟩
    · have hnon : 0 ≤ (a.row n).spent := by
        rw [hspent]
        exact (sq_nonneg _).trans (le_max_right _ _)
      exfalso
      linarith only [hunit.2.1, hnon, hf]
  · have hcap : a.cap = E := max_eq_left (le_of_lt (lt_of_not_ge hbig))
    have hs : (a.row n).spent = E := hspent.trans hcap
    have hobs := Input.observable P a rfl rfl n hlen (m^2/2)
      (fun b hb => zero_le_one.trans (table_lower _ b hb))
      (fun _ hb => GuardSizes.table_step_upper k hb)
    change |((a.row n).spent+(a.row n).cross)/2 - P.L*(P.f x-P.f (a.row n).x)| ≤
      (a.row n).spent*((P.ρ*(Real.sqrt (M*(a.row n).spent)/P.L)/P.L)*(m^2/2))/12 at hobs
    rw [hs] at hobs
    have hb := hB x E n hE hhi hcap hn hlen hpre hs
    have est := normalize P.L_pos P.ρ_pos hε hM hE.le hK (GuardSizes.table_mass (k+1))
      hhi hstable hobs hb
    have hg := Epoch.budget_case hA hE.le hE₀ est
    rcases hout with ⟨hpass,hu⟩ | ⟨hfail,hu⟩
    · rw [hs] at hpass
      exact Or.inl ⟨hu, hg.1 (by linarith only [hpass])⟩
    · rw [hs] at hfail
      have hlarge : c*E₀ < E := by
        by_contra! hsmall
        have hsmall' : E ≤ Epoch.threshold A E₀ := hth.symm ▸ hsmall
        linarith only [hg.2.2 hsmall', hfail]
      refine Or.inr ⟨hu, ?_, ?_⟩
      · rw [heform]
        exact hlarge
      · change P.L*(P.f (a.row n).x-P.f x) ≤ (1+A)^2*E
        calc
          _ = -(P.L*(P.f x-P.f (a.row n).x)) := by ring
          _ ≤ _ := hg.2.1

end
end GDProof.Local
