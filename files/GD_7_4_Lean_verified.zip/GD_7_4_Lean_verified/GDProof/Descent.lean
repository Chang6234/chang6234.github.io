import GDProof.Geometry

/-! Scalar calculus and finite arithmetic used in Appendix B. -/

open scoped BigOperators

namespace GDProof.Descent

/-- The trapezoidal rule on a unit segment.  The derivative of the integrand
only needs a Lipschitz estimate against its value at the midpoint. -/
theorem segment_trapezoid (F φ d : ℝ → ℝ) (M : ℝ)
    (hF : ∀ t, HasDerivAt F (φ t) t) (hφ : ∀ t, HasDerivAt φ (d t) t)
    (hd : ∀ t : ℝ, |d t - d (1 / 2)| ≤ M * |t - 1 / 2|) :
    |(φ 0 + φ 1) / 2 - (F 1 - F 0)| ≤ M / 12 := by
  let ψ : ℝ → ℝ := fun t =>
    (t - 1 / 2) * φ t - F t - (t - 1 / 2)^2 * ((1 / 2) * d (1 / 2))
  let B : ℝ → ℝ := fun t => (t - 1 / 2)^3 * (M / 3)
  have ht (t : ℝ) : HasDerivAt (fun x : ℝ => x - 1 / 2) 1 t := by
    simpa using (hasDerivAt_id t).sub_const (1 / 2 : ℝ)
  have hψ (t : ℝ) : HasDerivAt ψ ((t - 1 / 2) * (d t - d (1 / 2))) t := by
    dsimp [ψ]
    convert ((((ht t).mul (hφ t)).sub (hF t)).sub
      (((ht t).pow 2).mul_const ((1 / 2 : ℝ) * d (1 / 2)))) using 1 <;> ring
  have hB (t : ℝ) : HasDerivAt B (M * (t - 1 / 2)^2) t := by
    dsimp [B]
    convert (((ht t).pow 3).mul_const (M / 3)) using 1 <;> ring
  have herr (t : ℝ) : |(t - 1 / 2) * (d t - d (1 / 2))| ≤ M * (t - 1 / 2)^2 := by
    rw [abs_mul]
    calc
      _ ≤ |t - 1 / 2| * (M * |t - 1 / 2|) := mul_le_mul_of_nonneg_left (hd t) (abs_nonneg _)
      _ = M * |t - 1 / 2|^2 := by ring
      _ = _ := by rw [sq_abs]
  have hm : Monotone (fun t => B t - ψ t) := by
    apply monotone_of_deriv_nonneg (fun t => ((hB t).sub (hψ t)).differentiableAt)
    intro t
    rw [((hB t).sub (hψ t)).deriv]
    linarith [(abs_le.mp (herr t)).2]
  have hp : Monotone (fun t => B t + ψ t) := by
    apply monotone_of_deriv_nonneg (fun t => ((hB t).add (hψ t)).differentiableAt)
    intro t
    rw [((hB t).add (hψ t)).deriv]
    linarith [(abs_le.mp (herr t)).1]
  have hu := hm (show (0 : ℝ) ≤ 1 by norm_num)
  have hl := hp (show (0 : ℝ) ≤ 1 by norm_num)
  dsimp [B, ψ] at hu hl
  apply abs_le.mpr
  constructor <;> linarith only [hu, hl]

/-- Operator-norm Lipschitzness of the Hessian gives the directional
Lipschitz modulus ρ ‖s‖³ along the whole line. -/
theorem directional_hessian_bound {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (H : V → V →L[ℝ] V →L[ℝ] ℝ) (ρ : ℝ)
    (hH : ∀ x y, ‖H x - H y‖ ≤ ρ * ‖x-y‖) (x s : V) (t u : ℝ) :
    |H (x+t•s) s s - H (x+u•s) s s| ≤ (ρ * ‖s‖^3) * |t-u| := by
  let A := H (x+t•s) - H (x+u•s)
  have hline : (x+t•s) - (x+u•s) = (t-u)•s := by rw [sub_smul] <;> abel
  have hop : ‖A‖ ≤ ρ * (|t-u| * ‖s‖) := by
    simpa only [A, hline, norm_smul, Real.norm_eq_abs] using hH (x+t•s) (x+u•s)
  calc
    _ = ‖A s s‖ := by rw [Real.norm_eq_abs] <;> rfl
    _ ≤ ‖A s‖ * ‖s‖ := (A s).le_opNorm s
    _ ≤ (‖A‖ * ‖s‖) * ‖s‖ := mul_le_mul_of_nonneg_right (A.le_opNorm s) (norm_nonneg s)
    _ ≤ ((ρ * (|t-u| * ‖s‖)) * ‖s‖) * ‖s‖ :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hop (norm_nonneg s)) (norm_nonneg s)
    _ = _ := by ring

/-- The one-step trapezoid estimate for a general smooth objective on a real
normed space, directly from its Fréchet derivatives and Hessian Lipschitzness. -/
theorem objective_segment_trapezoid {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (f : V → ℝ) (G : V → V →L[ℝ] ℝ) (H : V → V →L[ℝ] V →L[ℝ] ℝ)
    (hf : ∀ x, HasFDerivAt f (G x) x) (hG : ∀ x, HasFDerivAt G (H x) x)
    (ρ : ℝ) (hH : ∀ x y, ‖H x - H y‖ ≤ ρ * ‖x-y‖) (x s : V) :
    |(G x s + G (x+s) s)/2 - (f (x+s) - f x)| ≤ ρ * ‖s‖^3 / 12 := by
  let line : ℝ → V := fun t => x+t•s
  have hl (t : ℝ) : HasDerivAt line s t := by
    simpa [line] using ((hasDerivAt_const t x).add ((hasDerivAt_id t).smul_const s))
  have h₁ (t : ℝ) : HasDerivAt (fun u => f (line u)) (G (line t) s) t :=
    (hf (line t)).comp_hasDerivAt t (hl t)
  have h₂ (t : ℝ) : HasDerivAt (fun u => G (line u) s) (H (line t) s s) t := by
    have h := (hG (line t)).comp_hasDerivAt t (hl t)
    simpa [Function.comp_def] using h.clm_apply (hasDerivAt_const t s)
  have h₃ (t : ℝ) := directional_hessian_bound H ρ hH x s t (1/2)
  simpa [line] using segment_trapezoid (fun u => f (line u)) (fun u => G (line u) s)
    (fun u => H (line u) s s) (ρ * ‖s‖^3) h₁ h₂ h₃

/-- The descent lemma for arbitrary displacements, from a Lipschitz true gradient. -/
theorem gradient_quadratic_upper {V : Type*} [NormedAddCommGroup V]
    [InnerProductSpace ℝ V] [CompleteSpace V] (f : V → ℝ) (g : V → V) (L : ℝ)
    (hg : ∀ x, HasGradientAt f (g x) x)
    (hlip : ∀ x y, ‖g x - g y‖ ≤ L * ‖x-y‖) (x s : V) :
    f (x+s) ≤ f x + ⟪g x, s⟫_ℝ + L*‖s‖^2/2 := by
  let line : ℝ → V := fun t => x+t•s
  let a : ℝ := ⟪g x, s⟫_ℝ
  let P : ℝ → ℝ := fun t => f (line t) - (t*a + t^2 * (L*‖s‖^2/2))
  have ht (t : ℝ) : HasDerivAt line s t := by
    simpa [line] using ((hasDerivAt_const t x).add ((hasDerivAt_id t).smul_const s))
  have hline (t : ℝ) : HasDerivAt (fun u => f (line u)) ⟪g (line t), s⟫_ℝ t :=
    (hg (line t)).hasFDerivAt.comp_hasDerivAt t (ht t)
  have hP (t : ℝ) : HasDerivAt P (⟪g (line t), s⟫_ℝ - ⟪g x, s⟫_ℝ - t*L*‖s‖^2) t := by
    convert (hline t).sub (((hasDerivAt_id t).mul_const a).add
      (((hasDerivAt_id t).pow 2).mul_const (L*‖s‖^2/2))) using 1
    dsimp [a]
    ring
  have hm : AntitoneOn P (Set.Icc (0 : ℝ) 1) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc 0 1)
      (fun t _ => (hP t).continuousAt.continuousWithinAt)
      (fun t _ => (hP t).differentiableAt.differentiableWithinAt)
    intro t hi
    have hn : 0 ≤ t := (interior_subset hi).1
    have hdist : ‖g (line t)-g x‖ ≤ L*(t*‖s‖) := by
      simpa [line, norm_smul, Real.norm_eq_abs, abs_of_nonneg hn] using hlip (line t) x
    have hinner := real_inner_le_norm (g (line t)-g x) s
    rw [inner_sub_left] at hinner
    rw [(hP t).deriv]
    nlinarith only [hinner, mul_le_mul_of_nonneg_right hdist (norm_nonneg s)]
  have h := hm (show (0 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num)
    (show (1 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num) (by norm_num)
  simp [P, line, a] at h
  linarith

/-- One ordinary GD step of length 1/L decreases the true objective. -/
theorem ordinary_gradient_step {V : Type*} [NormedAddCommGroup V]
    [InnerProductSpace ℝ V] [CompleteSpace V] (f : V → ℝ) (g : V → V) (L : ℝ)
    (hL : 0 < L) (hg : ∀ x, HasGradientAt f (g x) x)
    (hlip : ∀ x y, ‖g x - g y‖ ≤ L * ‖x-y‖) (x : V) :
    f (x - (1/L) • g x) ≤ f x - ‖g x‖^2 / (2*L) := by
  have h := gradient_quadratic_upper f g L hg hlip x (-((1/L) • g x))
  rw [← sub_eq_add_neg, inner_neg_right, real_inner_smul_right, real_inner_self_eq_norm_sq,
    norm_neg, norm_smul_of_nonneg (show 0 ≤ 1/L by positivity)] at h
  calc
    _ ≤ _ := h
    _ = _ := by field_simp [ne_of_gt hL] <;> ring

/-- Adding edge errors also telescopes the primitive values along a prefix. -/
theorem prefix_trapezoid (f pred err : ℕ → ℝ) (n : ℕ)
    (h : ∀ i < n, |pred i - (f i - f (i+1))| ≤ err i) :
    |(∑ i in Finset.range n, pred i) - (f 0 - f n)| ≤ ∑ i in Finset.range n, err i := by
  induction n with
  | zero => simp
  | succ n ih =>
    have h₁ := ih (fun i hi => h i (Nat.lt_succ_of_lt hi))
    have h₂ := h n (Nat.lt_succ_self n)
    simp only [Finset.sum_range_succ]
    calc
      _ = |((∑ i in Finset.range n, pred i) - (f 0 - f n)) +
        (pred n - (f n - f (n+1)))| := by congr 1 <;> ring
      _ ≤ _ := (abs_add _ _).trans (add_le_add h₁ h₂)

/-- Sum the segment bounds and use the GD identity for the squared step length.
Here `cost i = hᵢ ‖gᵢ‖²`, `H` bounds the coefficients and `R` bounds segment lengths.
The supplied derivatives are the first and second directional derivatives of
the line profiles; their endpoint derivatives give the observed predictor. -/
theorem prefix_test_error (n : ℕ) (f len cost pred h : ℕ → ℝ)
    (F φ d : ℕ → ℝ → ℝ) (L ρ R H : ℝ) (hL : 0 < L) (hρ : 0 ≤ ρ) (hR : 0 ≤ R)
    (hcost : ∀ i < n, 0 ≤ cost i) (hH : ∀ i < n, h i ≤ H)
    (hstep : ∀ i < n, L^2 * (len i)^2 = h i * cost i) (hlen : ∀ i < n, len i ≤ R)
    (hF : ∀ i < n, ∀ t, HasDerivAt (F i) (φ i t) t)
    (hφ : ∀ i < n, ∀ t, HasDerivAt (φ i) (d i t) t)
    (hd : ∀ i < n, ∀ t : ℝ, |d i t - d i (1/2)| ≤ (ρ * (len i)^3) * |t-1/2|)
    (hstart : ∀ i < n, F i 0 = f i) (hend : ∀ i < n, F i 1 = f (i+1))
    (hpred : ∀ i < n, pred i = -L * ((φ i 0 + φ i 1)/2)) :
    |(∑ i in Finset.range n, pred i) - (L*f 0 - L*f n)| ≤
      ρ*R/(12*L)*H * (∑ i in Finset.range n, cost i) := by
  rw [Finset.mul_sum]
  apply prefix_trapezoid (fun i => L*f i) pred
  intro i hi
  have herr := segment_trapezoid (F i) (φ i) (d i) (ρ * (len i)^3)
    (hF i hi) (hφ i hi) (hd i hi)
  have hcub : (len i)^3 ≤ R * (len i)^2 := by
    nlinarith only [mul_le_mul_of_nonneg_right (hlen i hi) (sq_nonneg (len i))]
  have hsq : L^2 * (len i)^2 ≤ H * cost i := by
    rw [hstep i hi]
    exact mul_le_mul_of_nonneg_right (hH i hi) (hcost i hi)
  calc
    _ = |-L * (((φ i 0 + φ i 1)/2) - (F i 1 - F i 0))| := by
      rw [hpred i hi, hstart i hi, hend i hi]
      congr 1 <;> ring
    _ = L * |((φ i 0 + φ i 1)/2) - (F i 1 - F i 0)| := by
      rw [abs_mul, abs_neg, abs_of_nonneg hL.le]
    _ ≤ L * ((ρ * (len i)^3)/12) := mul_le_mul_of_nonneg_left herr hL.le
    _ ≤ L * ((ρ * (R * (len i)^2))/12) := by
      nlinarith only [mul_le_mul_of_nonneg_left hcub (mul_nonneg hL.le hρ)]
    _ = (ρ*R/(12*L)) * (L^2 * (len i)^2) := by field_simp [ne_of_gt hL] <;> ring
    _ ≤ (ρ*R/(12*L)) * (H * cost i) := mul_le_mul_of_nonneg_left hsq (by positivity)
    _ = _ := by ring

/-- The observable epoch test for a prefix of actual gradient updates.
Here R bounds the individual displacements and b bounds their coefficients. -/
theorem gd_prefix_test_error {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
    [CompleteSpace V] (f : V → ℝ) (g : V → V) (H : V → V →L[ℝ] V)
    (hg : ∀ x, HasGradientAt f (g x) x) (hH : ∀ x, HasFDerivAt g (H x) x)
    (L ρ : ℝ) (hL : 0 < L) (hρ : 0 ≤ ρ)
    (hlip : ∀ u v, ‖H u-H v‖ ≤ ρ*‖u-v‖) (n : ℕ) (x : ℕ → V) (h : ℕ → ℝ)
    (hnn : ∀ i < n, 0 ≤ h i) (hgd : ∀ i < n, x (i+1) = x i - (h i/L) • g (x i))
    (R b : ℝ) (hR : 0 ≤ R) (hmax : ∀ i < n, h i ≤ b)
    (hrad : ∀ i < n, ‖x (i+1) - x i‖ ≤ R) :
    |((∑ i in Finset.range n, h i * ‖g (x i)‖^2) +
      (∑ i in Finset.range n, h i * ⟪g (x i), g (x (i+1))⟫_ℝ))/2 -
        L*(f (x 0) - f (x n))| ≤
      ρ*R/(12*L)*b * (∑ i in Finset.range n, h i * ‖g (x i)‖^2) := by
  let s : ℕ → V := fun i => -((h i/L) • g (x i))
  let line : ℕ → ℝ → V := fun i t => x i + t • s i
  let φ : ℕ → ℝ → ℝ := fun i t => ⟪g (line i t), s i⟫_ℝ
  let d : ℕ → ℝ → ℝ := fun i t => ⟪H (line i t) (s i), s i⟫_ℝ
  let cost : ℕ → ℝ := fun i => h i * ‖g (x i)‖^2
  let corr : ℕ → ℝ := fun i => h i * ⟪g (x i), g (x (i+1))⟫_ℝ
  let pred : ℕ → ℝ := fun i => (cost i + corr i)/2
  have hstart (i : ℕ) : line i 0 = x i := by simp [line]
  have hend (i : ℕ) (hi : i < n) : line i 1 = x (i+1) := by simp [line, s, hgd i hi, sub_eq_add_neg]
  have hs (i : ℕ) (hi : i < n) : s i = x (i+1) - x i := by rw [hgd i hi]; dsimp [s]; abel
  have hline (i : ℕ) (t : ℝ) : HasDerivAt (line i) (s i) t := by
    simpa [line] using ((hasDerivAt_const t (x i)).add ((hasDerivAt_id t).smul_const (s i)))
  have h₁ (i : ℕ) (t : ℝ) : HasDerivAt (fun u => f (line i u)) (φ i t) t :=
    (hg (line i t)).hasFDerivAt.comp_hasDerivAt t (hline i t)
  have h₂ (i : ℕ) (t : ℝ) : HasDerivAt (φ i) (d i t) t := by
    have he := (hH (line i t)).comp_hasDerivAt t (hline i t)
    simpa [φ, d, Function.comp_def] using he.inner ℝ (hasDerivAt_const t (s i))
  have h₃ (i : ℕ) (t u : ℝ) : |d i t - d i u| ≤ (ρ * ‖s i‖^3) * |t-u| := by
    let B := H (line i t) - H (line i u)
    have he : line i t - line i u = (t-u) • s i := by dsimp [line]; rw [sub_smul]; abel
    have hop : ‖B‖ ≤ ρ * (|t-u| * ‖s i‖) := by
      simpa only [B, he, norm_smul, Real.norm_eq_abs] using hlip (line i t) (line i u)
    calc
      _ = |⟪B (s i), s i⟫_ℝ| := by simp [B, d, inner_sub_left]
      _ ≤ ‖B (s i)‖ * ‖s i‖ := abs_real_inner_le_norm _ _
      _ ≤ (‖B‖ * ‖s i‖) * ‖s i‖ := mul_le_mul_of_nonneg_right (B.le_opNorm _) (norm_nonneg _)
      _ ≤ ((ρ * (|t-u| * ‖s i‖)) * ‖s i‖) * ‖s i‖ :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hop (norm_nonneg _)) (norm_nonneg _)
      _ = _ := by ring
  have hp (i : ℕ) (hi : i < n) : pred i = -L * ((φ i 0 + φ i 1)/2) := by
    dsimp [pred, cost, corr, φ]
    rw [hstart, hend i hi]
    dsimp [s]
    rw [inner_neg_right, inner_neg_right, real_inner_smul_right, real_inner_smul_right,
      real_inner_self_eq_norm_sq, real_inner_comm (g (x (i+1))) (g (x i))]
    field_simp [ne_of_gt hL] <;> ring
  have hlen (i : ℕ) (hi : i < n) : L^2 * ‖s i‖^2 = h i * cost i := by
    simp only [s, norm_neg, norm_smul_of_nonneg (div_nonneg (hnn i hi) hL.le), cost]
    field_simp [ne_of_gt hL] <;> ring
  have hh := prefix_test_error n (fun i => f (x i)) (fun i => ‖s i‖) cost pred h
    (fun i u => f (line i u)) φ d L ρ R b hL hρ hR
    (fun i hi => mul_nonneg (hnn i hi) (sq_nonneg _)) hmax hlen
    (fun i hi => by change ‖s i‖ ≤ R; rw [hs i hi]; exact hrad i hi)
    (fun i _ => h₁ i) (fun i _ => h₂ i) (fun i _ t => h₃ i t (1/2))
    (fun i _ => congrArg f (hstart i)) (fun i hi => congrArg f (hend i hi)) hp
  simpa only [pred, cost, corr, ← Finset.sum_div, Finset.sum_add_distrib, mul_sub] using hh

/-- The square-root path budget follows from the executed gradient updates,
including a shortened final step. No smoothness hypothesis is required. -/
theorem gd_prefix_path_length {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (L : ℝ) (hL : 0 < L) (n : ℕ) (x g : ℕ → V) (h : ℕ → ℝ)
    (hnn : ∀ i < n, 0 ≤ h i) (hgd : ∀ i < n, x (i+1) = x i - (h i/L) • g i) :
    (∑ i in Finset.range n, ‖x (i+1) - x i‖) ≤
      Real.sqrt ((∑ i in Finset.range n, h i) * (∑ i in Finset.range n, h i * ‖g i‖^2)) / L :=
  GDProof.Geometry.path_length x g h n hL hnn hgd le_rfl le_rfl

/-- Equation (B.1), with `A` an upper bound on the coefficient mass and
`b` an upper bound on the largest executed coefficient. -/
theorem gd_prefix_observable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
    [CompleteSpace V] (f : V → ℝ) (g : V → V) (H : V → V →L[ℝ] V)
    (hg : ∀ x, HasGradientAt f (g x) x) (hH : ∀ x, HasFDerivAt g (H x) x)
    (L ρ : ℝ) (hL : 0 < L) (hρ : 0 ≤ ρ)
    (hlip : ∀ u v, ‖H u-H v‖ ≤ ρ*‖u-v‖) (n : ℕ) (x : ℕ → V) (h : ℕ → ℝ)
    (hnn : ∀ i < n, 0 ≤ h i) (hgd : ∀ i < n, x (i+1) = x i - (h i/L) • g (x i))
    (A b : ℝ) (hA : (∑ i in Finset.range n, h i) ≤ A) (hmax : ∀ i < n, h i ≤ b) :
    let S := ∑ i in Finset.range n, h i * ‖g (x i)‖^2
    let C := ∑ i in Finset.range n, h i * ⟪g (x i), g (x (i+1))⟫_ℝ
    let R := Real.sqrt (A*S) / L
    |(S+C)/2 - L*(f (x 0)-f (x n))| ≤ ρ*R/(12*L)*b*S := by
  intro S C R
  have hS : 0 ≤ S := Finset.sum_nonneg (fun i hi => mul_nonneg (hnn i
    (Finset.mem_range.mp hi)) (sq_nonneg _))
  apply gd_prefix_test_error f g H hg hH L ρ hL hρ hlip n x h hnn hgd R b (by dsimp [R]; positivity) hmax
  intro i hi
  calc
    _ ≤ ∑ j in Finset.range n, ‖x (j+1)-x j‖ :=
      Finset.single_le_sum (fun j _ => norm_nonneg (x (j+1)-x j)) (Finset.mem_range.mpr hi)
    _ ≤ _ := (gd_prefix_path_length L hL n x (fun j => g (x j)) h hnn hgd).trans
      (div_le_div_of_nonneg_right (Real.sqrt_le_sqrt (mul_le_mul_of_nonneg_right hA hS)) hL.le)

/-- For a frozen positive eigenvalue, square the scalar GD recurrence and telescope. -/
theorem frozen_telescoping (h p : ℕ → ℝ) (z : ℝ) (n : ℕ)
    (hp : ∀ i, p (i+1) = (1 - h i * z) * p i) :
    z^2 * (∑ i in Finset.range n, (h i)^2 * (p i)^2) =
    2*z * (∑ i in Finset.range n, h i * (p i)^2) + (p n)^2 - (p 0)^2 := by
  induction n with
  | zero => simp
  | succ n ih =>
    simp only [Finset.sum_range_succ]
    rw [show p (n+1) = _ from hp n]
    nlinarith only [ih]

/-- A weighted positive-prefix certificate implies that the quadratic Hessian
term at this eigenvalue is bounded by its gradient-energy term. -/
theorem frozen_quadratic_bound (h p : ℕ → ℝ) (z : ℝ) (n : ℕ) (hz : 0 < z)
    (hp₀ : p 0 = 1) (hp : ∀ i, p (i+1) = (1 - h i * z) * p i)
    (hcert : z * (∑ i in Finset.range n, h i * (p i)^2) + (p n)^2 ≤ 1) :
    z * (∑ i in Finset.range n, (h i)^2 * (p i)^2) ≤
       ∑ i in Finset.range n, h i * (p i)^2 := by
  have ht := frozen_telescoping h p z n hp
  rw [hp₀] at ht
  by_contra! hgt
  have hpos := mul_pos hz (sub_pos.mpr hgt)
  nlinarith only [ht, hcert, hpos]

/-- The propagated error is used twice: first in the curvature-weighted
norm and then in the ordinary gradient-energy norm. -/
theorem transfer_frozen_comparison {U V : Type*}
    [NormedAddCommGroup U] [NormedAddCommGroup V]
    (w wFrozen : U) (g gFrozen : V) (η e : ℝ) (hw : ‖w-wFrozen‖ ≤ η)
    (hg : ‖gFrozen-g‖ ≤ η) (hfrozen : ‖wFrozen‖ ≤ ‖gFrozen‖) (he : ‖g‖ ≤ e) :
    ‖w‖ ≤ e + 2*η := by
  have h₁ : ‖w‖ ≤ ‖w-wFrozen‖ + ‖wFrozen‖ := by simpa using norm_add_le (w-wFrozen) wFrozen
  have h₂ : ‖gFrozen‖ ≤ ‖gFrozen-g‖ + ‖g‖ := by simpa using norm_add_le (gFrozen-g) g
  linarith

/-- A unit normalized GD step passes the gradient-alignment test whenever
gradient Lipschitzness implies ‖g₁−g₀‖ ≤ ‖g₀‖. -/
theorem unit_step_alignment {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]
    (g k : V) (h : ‖k-g‖ ≤ ‖g‖) : 0 ≤ ⟪g, k⟫_ℝ := by
  have hb := abs_real_inner_le_norm g (k-g)
  rw [inner_sub_right, real_inner_self_eq_norm_sq] at hb
  have hc := mul_le_mul_of_nonneg_left h (norm_nonneg g)
  nlinarith only [(abs_le.mp hb).1, hc]

/-- In the paper's normalization the tested decrease is (S+C)/2 and the
true decrease is D = L(f(start)-f(end)). -/
theorem passing_epoch_drop {S C D : ℝ} (hpass : -(S/2) ≤ C)
    (herr : |(S+C)/2-D| ≤ S/16) : 3*S/16 ≤ D := by
  linarith [(abs_le.mp herr).2]

/-- Conversely, a true decrease of 3S/8 forces the alignment test to pass. -/
theorem sufficient_drop_passes {S C D : ℝ} (hS : 0 ≤ S) (hdrop : 3*S/8 ≤ D)
    (herr : |(S+C)/2-D| ≤ S/16) : -(S/2) ≤ C := by
  linarith [(abs_le.mp herr).1]

/-- The uniform radius estimate δ ≤ 3/4 makes the Sδ/12 trapezoid error
at most S/16. -/
theorem uniform_epoch_error {S δ C D : ℝ} (hS : 0 ≤ S) (hδ : δ ≤ 3/4)
    (herr : |(S+C)/2-D| ≤ S*δ/12) : |(S+C)/2-D| ≤ S/16 := by
  have hh := mul_le_mul_of_nonneg_left hδ hS
  linarith

/-- Closing the nonlinear descent estimate with explicit sufficient constants. -/
theorem small_radius_decrease {S D α δ : ℝ} (hS : 0 ≤ S) (hα₀ : 0 ≤ α)
    (hα : α ≤ 1/32) (hδ : δ ≤ 1/32)
    (hmodel : -D ≤ S * (-1 + (1+α)^2/2 + δ/2)) : 3*S/8 ≤ D := by
  have hsq := mul_nonneg (show 0 ≤ 1/32-α by linarith) (show 0 ≤ 1/32+α by linarith)
  have hb : -1 + (1+α)^2/2 + δ/2 ≤ -(3/8) := by nlinarith only [hsq, hα, hδ]
  have hh := mul_le_mul_of_nonneg_left hb hS
  linarith only [hh, hmodel]

end GDProof.Descent
