import GDProof.Prefix

namespace GDProof.Quadratic

open GDProof.Prefix
open scoped BigOperators
noncomputable section

/-- Scalar quadratic divided by L in one normalized eigendirection. -/
def value (z c x : ℝ) : ℝ := (z / 2) * x * x + c * x

def grad (z c x : ℝ) : ℝ := z * x + c

theorem hasDerivAt_value (z c x : ℝ) : HasDerivAt (value z c) (grad z c x) x := by
  have h := (((hasDerivAt_const x (z / 2)).mul (hasDerivAt_id x)).mul (hasDerivAt_id x)).add
    ((hasDerivAt_const x c).mul (hasDerivAt_id x))
  convert h using 1
  simp [value, grad, id]
  ring

def run (z c : ℝ) : List ℝ → ℝ → ℝ
  | [], x => x
  | a :: t, x => run z c t (x - a * grad z c x)

def spending (z c : ℝ) : List ℝ → ℝ → ℝ
  | [], _ => 0
  | a :: t, x => a * (grad z c x) ^ 2 + spending z c t (x - a * grad z c x)

theorem spending_eq (z c : ℝ) (w : List ℝ) (x : ℝ) :
    spending z c w x = (grad z c x) ^ 2 * weighted z id w := by
  induction w generalizing x with
  | nil => simp [spending, weighted]
  | cons a t ih =>
    rw [spending, ih, weighted]
    simp only [id_eq, grad]
    ring

theorem decrease_eq (z c : ℝ) (w : List ℝ) (x : ℝ) :
    value z c x - value z c (run z c w x) =
    (grad z c x) ^ 2 * (weighted z id w - (z / 2) * weighted z (fun h => h ^ 2) w) := by
  induction w generalizing x with
  | nil => simp [weighted, run]
  | cons a t ih =>
    let y := x - a * grad z c x
    calc
      value z c x - value z c (run z c (a :: t) x) =
          value z c x - value z c y + (value z c y - value z c (run z c t y)) := by
        change value z c x - value z c (run z c t y) = _
        ring
      _ = _ := by
        rw [ih y]
        simp only [weighted, id_eq]
        dsimp [y, grad, value]
        ring

private theorem weighted_nonneg (z : ℝ) (f : ℝ → ℝ) (w : List ℝ) (hf : ∀ a ∈ w, 0 ≤ f a) :
    0 ≤ weighted z f w := by
  induction w with
  | nil => simp [weighted]
  | cons a t ih =>
    exact add_nonneg (hf a (by simp)) (mul_nonneg (sq_nonneg _)
      (ih (fun b hb => hf b (by simp [hb]))))

/-- Exact, dimension-independent constant in the descent bound for a single coordinate. -/
theorem decrease (z c : ℝ) (w : List ℝ) (x : ℝ) (hn : Nonnegative w)
    (hs : 0 < z → Stable z w) :
    spending z c w x ≤ 2 * (value z c x - value z c (run z c w x)) := by
  have hc : z * weighted z (fun h => h ^ 2) w ≤ weighted z id w := by
    by_cases hz : 0 < z
    · exact frozen_curvature hz (hs hz)
    · exact le_trans (mul_nonpos_of_nonpos_of_nonneg (le_of_not_gt hz)
        (weighted_nonneg z _ w (fun a _ => sq_nonneg a))) (weighted_nonneg z id w hn)
  rw [spending_eq, decrease_eq]
  nlinarith only [mul_nonneg (sq_nonneg (grad z c x)) (sub_nonneg.mpr hc)]

/-- Summing over an orthonormal eigenbasis for a quadratic given in diagonal coordinates. -/
theorem diagonal_decrease {ι : Type*} [Fintype ι] (z c x : ι → ℝ) (w : List ℝ)
    (hn : Nonnegative w) (hs : ∀ i, 0 < z i → Stable (z i) w) :
    (∑ i, spending (z i) (c i) w (x i)) ≤
    2 * ((∑ i, value (z i) (c i) (x i)) -
      ∑ i, value (z i) (c i) (run (z i) (c i) w (x i))) := by
  calc
    _ ≤ ∑ i, 2 * (value (z i) (c i) (x i) -
        value (z i) (c i) (run (z i) (c i) w (x i))) :=
      Finset.sum_le_sum (fun i _ => decrease (z i) (c i) w (x i) hn (hs i))
    _ = _ := by rw [← Finset.mul_sum, Finset.sum_sub_distrib]

end
end GDProof.Quadratic
