import Mathlib

/-! The two finite storage tables in Appendix D.1. Each theorem checks the tabulated
rational endpoints in the kernel and proves the storage inequality on the full
rectangle of real curvatures and coefficients. -/
namespace GDProof.FiniteStorage

abbrev Interval := ℚ × ℚ

structure Row (n : ℕ) where
  curvature : Interval
  storage : Fin (n + 1) → ℚ

def coeff4 : Fin 5 → Interval :=
  ![(1,1), (2,2), (7/6,6/5), (1,1), (13/10,4/3)]

def coeff8 : Fin 10 → Interval :=
  ![(1,1), (2,2), (117/100,118/100), (682/100,683/100),
    (144/100,145/100), (323/100,324/100), (103/100,104/100),
    (1,1), (2,2), (477/100,478/100)]

def rows4 : Fin 4 → Row 5 :=
  ![⟨(0,1/2),     ![0,0,0,0,0,0]⟩,
    ⟨(1/2,3/4),   ![0,1,0,0,0,0]⟩,
    ⟨(3/4,7/8),   ![0,7/5,0,0,1/5,0]⟩,
    ⟨(7/8,1),     ![0,9/4,1/5,0,2/5,0]⟩]

def rows8 : Fin 9 → Row 10 :=
  ![⟨(0,1/8),     ![0,0,0,0,0,0,0,0,0,0,0]⟩,
    ⟨(1/8,1/4),   ![0,1,3,5,0,0,0,0,0,1,0]⟩,
    ⟨(1/4,3/8),   ![0,1,5,11,0,1,0,0,1,4,0]⟩,
    ⟨(3/8,1/2),   ![0,1,5,17,0,2,0,0,1,7,0]⟩,
    ⟨(1/2,5/8),   ![0,1,6,33,1,4,0,1,2,10,0]⟩,
    ⟨(5/8,3/4),   ![0,2,4,45,1,5,0,1,5,13,0]⟩,
    ⟨(3/4,7/8),   ![0,2,1,59,1,6,0,1,10,15,0]⟩,
    ⟨(7/8,15/16), ![0,4,2,96,2,7,0,1,15,17,0]⟩,
    ⟨(15/16,1),   ![0,7,5,142,3,8,0,1,21,18,0]⟩]

/-- The rational inequalities printed before the two tables. -/
def Satisfies (τ l r u v A B : ℚ) : Prop :=
  0 < τ ∧ 0 ≤ l ∧ 0 ≤ u ∧ 0 ≤ A ∧ 0 ≤ B ∧ v * B < τ ∧
  max (r*u^2-21/20*u) (r*v^2-21/20*v) +
    B * max ((1-l*u)^2) ((1-r*v)^2) / (1 - v*B/τ) ≤ A

def Valid {n k : ℕ} (τ : ℚ) (coeff : Fin n → Interval) (rows : Fin k → Row n) : Prop :=
  ∀ j i, Satisfies τ (rows j).curvature.1 (rows j).curvature.2
    (coeff i).1 (coeff i).2 ((rows j).storage i.castSucc) ((rows j).storage i.succ)

set_option maxRecDepth 60000 in
set_option maxHeartbeats 10000000 in
theorem valid4 : Valid (4^4) coeff4 rows4 := by
  intro j i
  fin_cases j <;> fin_cases i <;> norm_num [Satisfies, coeff4, rows4, Fin.succ_mk, Fin.castSucc_mk, Matrix.cons_val_succ, max_def]

set_option maxRecDepth 60000 in
set_option maxHeartbeats 30000000 in
theorem valid8 : Valid (8^4) coeff8 rows8 := by
  intro j i
  fin_cases j <;> fin_cases i <;> norm_num [Satisfies, coeff8, rows8, Fin.succ_mk, Fin.castSucc_mk, Matrix.cons_val_succ, max_def]

private theorem quadratic_le_endpoints (r β u h v : ℝ) (hr : 0 ≤ r)
    (hu : u ≤ h) (hv : h ≤ v) :
    r*h^2 - β*h ≤ max (r*u^2 - β*u) (r*v^2 - β*v) := by
  by_cases hder : r*(u+h) ≤ β
  · apply le_trans _ (le_max_left _ _)
    nlinarith [mul_nonpos_of_nonneg_of_nonpos (sub_nonneg.mpr hu) (sub_nonpos.mpr hder)]
  · apply le_trans _ (le_max_right _ _)
    have hs : 0 ≤ r*(h+v)-β := by
      nlinarith [mul_nonneg hr (sub_nonneg.mpr (hu.trans hv))]
    nlinarith [mul_nonneg (sub_nonneg.mpr hv) hs]

/-- The rational rectangle check implies both the positive denominator and the
one-step Riccati inequality at every real point in that rectangle. -/
theorem rectangle {τ l r u v A B : ℚ} (cert : Satisfies τ l r u v A B)
    {z h : ℝ} (hz : (l:ℝ) ≤ z) (hz' : z ≤ (r:ℝ)) (hh : (u:ℝ) ≤ h)
    (hh' : h ≤ (v:ℝ)) :
    h * (B:ℝ) < (τ:ℝ) ∧
    z*h^2 - 21/20*h + (1-z*h)^2 * B / (1-h*B/τ) ≤ (A:ℝ) := by
  rcases cert with ⟨hτ,hl,hu,_,hB,hvB,hrect⟩
  have τpos : 0 < (τ:ℝ) := by exact_mod_cast hτ
  have lpos : 0 ≤ (l:ℝ) := by exact_mod_cast hl
  have upos : 0 ≤ (u:ℝ) := by exact_mod_cast hu
  have Bpos : 0 ≤ (B:ℝ) := by exact_mod_cast hB
  have vB : (v:ℝ)*B < τ := by exact_mod_cast hvB
  have endpoint : max ((r:ℝ)*u^2-21/20*u) ((r:ℝ)*v^2-21/20*v) +
      (B:ℝ) * max ((1-(l:ℝ)*u)^2) ((1-(r:ℝ)*v)^2) / (1-(v:ℝ)*B/τ) ≤ A := by
    have casted : (↑(max (r*u^2-21/20*u) (r*v^2-21/20*v) +
      B * max ((1-l*u)^2) ((1-r*v)^2) / (1-v*B/τ)) : ℝ) ≤ (A:ℝ) := by exact_mod_cast hrect
    push_cast at casted
    exact casted
  have hb : h*B ≤ (v:ℝ)*B := mul_le_mul_of_nonneg_right hh' Bpos
  refine ⟨hb.trans_lt vB, ?_⟩
  have low : (l:ℝ)*u ≤ z*h := mul_le_mul hz hh upos (lpos.trans hz)
  have high : z*h ≤ (r:ℝ)*v := mul_le_mul hz' hh' (upos.trans hh) ((lpos.trans hz).trans hz')
  have sq : (1-z*h)^2 ≤ max ((1-(l:ℝ)*u)^2) ((1-(r:ℝ)*v)^2) := by
    have q := quadratic_le_endpoints 1 0 (1-(r:ℝ)*v) (1-z*h) (1-(l:ℝ)*u)
      (by norm_num) (by linarith) (by linarith)
    simpa only [one_mul, zero_mul, sub_zero, max_comm] using q
  have first : z*h^2-21/20*h ≤ max ((r:ℝ)*u^2-21/20*u) ((r:ℝ)*v^2-21/20*v) :=
    le_trans (sub_le_sub_right (mul_le_mul_of_nonneg_right hz' (sq_nonneg h)) _)
      (quadratic_le_endpoints _ _ _ _ _ ((lpos.trans hz).trans hz') hh hh')
  have denominator : 0 < 1 - (v:ℝ)*B/τ := by
    apply sub_pos.mpr
    simpa only [one_mul] using (div_lt_iff τpos).2 (by simpa using vB)
  have hden : 1 - (v:ℝ)*B/τ ≤ 1-h*B/τ :=
    sub_le_sub_left (div_le_div_of_nonneg_right hb τpos.le) _
  refine le_trans (add_le_add first ?_) endpoint
  rw [mul_comm ((1-z*h)^2)]
  exact div_le_div (mul_nonneg Bpos ((sq_nonneg _).trans (le_max_left _ _))) (mul_le_mul_of_nonneg_left sq Bpos)
    denominator hden

/-- All rows, including the two endpoint storages. -/
theorem endpoints4 : ∀ j, (rows4 j).storage 0 = 0 ∧ (rows4 j).storage (Fin.last 5) = 0 := by
  intro j
  fin_cases j <;> decide
theorem endpoints8 : ∀ j, (rows8 j).storage 0 = 0 ∧ (rows8 j).storage (Fin.last 10) = 0 := by
  intro j
  fin_cases j <;> decide


/-- A nonnegative storage row that works for every coefficient in its box at the given curvature. -/
def Stores {n : ℕ} (τ z : ℝ) (coeff : Fin n → Interval) (R : Fin (n+1) → ℚ) : Prop :=
  R 0 = 0 ∧ R (Fin.last n) = 0 ∧
  ∀ i : Fin n, 0 ≤ R i.castSucc ∧ 0 ≤ R i.succ ∧
    ∀ h : ℝ, (coeff i).1 ≤ h → h ≤ (coeff i).2 →
    h * (R i.succ : ℝ) < τ ∧ z*h^2 - 21/20*h +
      (1-z*h)^2 * (R i.succ : ℝ) / (1-h*(R i.succ : ℝ)/τ) ≤ (R i.castSucc : ℝ)

private theorem stores_of_valid {k n : ℕ} {τ : ℚ} {coeff : Fin n → Interval}
    {rows : Fin k → Row n} (good : Valid τ coeff rows)
    (ends : ∀ j, (rows j).storage 0 = 0 ∧ (rows j).storage (Fin.last n) = 0)
    {z : ℝ} (j : Fin k)
    (in_bin : (rows j).curvature.1 ≤ z ∧ z ≤ (rows j).curvature.2) :
    Stores τ z coeff (rows j).storage := by
  refine ⟨(ends j).1, (ends j).2, ?_⟩
  intro i
  have verified := good j i
  exact ⟨verified.2.2.2.1, verified.2.2.2.2.1, fun h hu hv =>
    rectangle verified in_bin.1 in_bin.2 hu hv⟩

private theorem cover4 (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) :
    ∃ j : Fin 4, (rows4 j).curvature.1 ≤ z ∧ z ≤ (rows4 j).curvature.2 := by
  by_cases h0 : z ≤ 4/8
  · refine ⟨0, ?_⟩
    change (↑((0) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1/2):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h1 : z ≤ 6/8
  · refine ⟨1, ?_⟩
    change (↑((1/2) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((3/4):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h2 : z ≤ 7/8
  · refine ⟨2, ?_⟩
    change (↑((3/4) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((7/8):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  refine ⟨3, ?_⟩
  change (↑((7/8) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1):ℚ) : ℝ)
  push_cast
  constructor <;> linarith

/-- For every curvature in the closed unit interval the printed degree-4 table
supplies a single storage sequence valid for all its steps. -/
theorem stores4 (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) :
    ∃ j, Stores ((4^4 : ℚ) : ℝ) z coeff4 (rows4 j).storage := by
  obtain ⟨j, hj⟩ := cover4 z hz hz'
  exact ⟨j, stores_of_valid valid4 endpoints4 j hj⟩

private theorem cover8 (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) :
    ∃ j : Fin 9, (rows8 j).curvature.1 ≤ z ∧ z ≤ (rows8 j).curvature.2 := by
  by_cases h0 : z ≤ 2/16
  · refine ⟨0, ?_⟩
    change (↑((0) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1/8):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h1 : z ≤ 4/16
  · refine ⟨1, ?_⟩
    change (↑((1/8) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1/4):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h2 : z ≤ 6/16
  · refine ⟨2, ?_⟩
    change (↑((1/4) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((3/8):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h3 : z ≤ 8/16
  · refine ⟨3, ?_⟩
    change (↑((3/8) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1/2):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h4 : z ≤ 10/16
  · refine ⟨4, ?_⟩
    change (↑((1/2) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((5/8):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h5 : z ≤ 12/16
  · refine ⟨5, ?_⟩
    change (↑((5/8) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((3/4):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h6 : z ≤ 14/16
  · refine ⟨6, ?_⟩
    change (↑((3/4) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((7/8):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  by_cases h7 : z ≤ 15/16
  · refine ⟨7, ?_⟩
    change (↑((7/8) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((15/16):ℚ) : ℝ)
    push_cast
    constructor <;> linarith
  refine ⟨8, ?_⟩
  change (↑((15/16) : ℚ) : ℝ) ≤ z ∧ z ≤ (↑((1):ℚ) : ℝ)
  push_cast
  constructor <;> linarith

/-- For every curvature in the closed unit interval the printed degree-8 table
supplies a single storage sequence valid for all its steps. -/
theorem stores8 (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) :
    ∃ j, Stores ((8^4 : ℚ) : ℝ) z coeff8 (rows8 j).storage := by
  obtain ⟨j, hj⟩ := cover8 z hz hz'
  exact ⟨j, stores_of_valid valid8 endpoints8 j hj⟩

end GDProof.FiniteStorage
