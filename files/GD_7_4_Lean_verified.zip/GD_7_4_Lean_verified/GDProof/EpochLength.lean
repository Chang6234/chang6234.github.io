import GDProof.TraceData
import GDProof.Counting
import GDProof.GuardSizes

/-! A fresh epoch reaches its first stopping or restart event before exhausting
the actual guarded table. No regularity assumption on the oracle is needed. -/
namespace GDProof.EpochLength
open GDProof.Model GDProof.Schedule GDProof.TraceData Finset
noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

theorem table_first (k : ℕ) : (table k).getD 0 0 = 1 := by
  have hg : guardSize (2^k) 0 = 0 := by
    unfold guardSize
    simp only [Nat.zero_add, Nat.gcd_one_right, one_pow]
    apply Nat.div_eq_of_lt
    have hn : 0 < (2 : ℕ)^k := by positivity
    omega
  simp [table_unfold, raw, splice, hg, history_zero]

theorem table_length_pos (k : ℕ) : 0 < (table k).length := by
  have h := table_first k
  cases he : table k with
  | nil => simp [he] at h
  | cons a as => simp

private theorem sum_getD (w : List ℝ) :
    (∑ j ∈ range w.length, w.getD j 0) = w.sum := by
  induction w with
  | nil => simp
  | cons a w ih =>
    simp [sum_range_succ', ih, add_comm]

/-- The first event is positive and occurs at an actually available step.
The rows before it are precisely the uninterrupted part of this epoch. -/
theorem first_event (a : Input V) (k : ℕ) (htable : a.table = table k)
    (hε : 0 ≤ a.ε) (hactive : a.ε < ‖a.grad a.x0‖)
    (hE : a.E ≤ a.ε^2*a.table.sum/2) :
    ∃ t, 0 < t ∧ t ≤ a.table.length ∧ a.event t ∧ ∀ i < t, ¬ a.event i := by
  classical
  have hcap : 0 < a.cap := by
    have hp : 0 < ‖a.grad a.x0‖ := hε.trans_lt hactive
    exact (sq_pos_of_pos hp).trans_le (le_max_right _ _)
  have hnon : ∀ i, i < a.table.length → 0 ≤ a.table.getD i 0 := by
    intro i hi
    rw [List.getD_eq_get _ _ hi]
    have hmem := List.get_mem a.table i hi
    have hall : ∀ b ∈ a.table, (1 : ℝ) ≤ b := by rw [htable]; exact table_lower k
    exact zero_le_one.trans (hall _ hmem)
  have hex : ∃ i, i ≤ a.table.length ∧ a.event i := by
    by_cases hcapE : ‖a.grad a.x0‖^2 ≤ a.E
    · have happ : a.cap = a.E := max_eq_left hcapE
      have hcover : a.cap ≤ a.ε^2*(∑ i ∈ range a.table.length, a.table.getD i 0) := by
        rw [sum_getD, happ]
        linarith only [hE, hcapE, sq_nonneg ‖a.grad a.x0‖]
      obtain hit := GDProof.Counting.table_reaches_cap_or_stationary a.table.length
        (fun i => a.table.getD i 0) (fun i => ‖a.grad (a.row i).x‖^2)
        (fun i => (a.row i).spent) a.ε a.cap rfl hnon hcover
        (fun i _ => a.row_succ_spent i)
      rcases hit with ⟨i, hi, hs⟩ | ⟨i, hi, hs⟩
      · refine ⟨i, hi.le, Or.inl ?_⟩
        by_contra! hbad
        have hpos : 0 < ‖a.grad (a.row i).x‖ + a.ε := by linarith
        nlinarith only [hs, mul_pos (sub_pos.mpr hbad) hpos]
      · exact ⟨i, hi, Or.inr (le_antisymm (a.spent_le_cap i) hs)⟩
    · have hcg : a.E ≤ ‖a.grad a.x0‖^2 := le_of_lt (lt_of_not_ge hcapE)
      have hone : a.table.getD 0 0 = 1 := by rw [htable, table_first]
      have ht : 0 < a.table.length := htable ▸ table_length_pos k
      refine ⟨1, ht, Or.inr ?_⟩
      have hq : 0 < ‖a.grad a.x0‖^2 := sq_pos_of_pos (hε.trans_lt hactive)
      rw [a.row_succ_spent 0]
      change 0 + clip (a.table.getD 0 0) 0 a.cap (‖a.grad a.x0‖^2) * ‖a.grad a.x0‖^2 = a.cap
      rw [hone, zero_add]
      exact GDProof.Counting.first_step_spends_large_cap hcg hq
  have hstart : ¬ a.event 0 := by
    intro hh
    rcases hh with hh | hh
    · exact (not_le.mpr hactive) hh
    · exact (ne_of_gt hcap) hh.symm
  have ht := Nat.find_spec hex
  refine ⟨Nat.find hex, ?_, ht.1, ht.2, ?_⟩
  · by_contra! hz
    have he : Nat.find hex = 0 := by omega
    exact hstart (he ▸ ht.2)
  · intro i hi hhit
    exact Nat.find_min hex hi ⟨(le_of_lt hi).trans ht.1, hhit⟩

/-- From a fresh epoch the resetting algorithm executes at most one table.
The final point is stationary or the published state starts a fresh epoch
with precisely the budget selected by its observed alignment test. -/
theorem run_reaches_boundary (a : Input V) (k : ℕ) (htable : a.table = table k)
    (hε : 0 ≤ a.ε) (hactive : a.ε < ‖a.grad a.x0‖)
    (hE : a.E ≤ a.ε^2*a.table.sum/2) :
    ∃ t, 0 < t ∧ t ≤ a.table.length ∧ t ≤ 4*2^k ∧
      run a.grad a.L a.ε a.table (fresh a.x0 (a.grad a.x0) a.E) t = some (a.endpoint t) ∧
      (‖(a.endpoint t).g‖ ≤ a.ε ∨
       ((a.row t).spent = a.cap ∧
        ((-((a.row t).spent)/2 ≤ (a.row t).cross ∧
          a.endpoint t = fresh (a.row t).x (a.grad (a.row t).x) a.E) ∨
         ((a.row t).cross < -((a.row t).spent)/2 ∧
          a.endpoint t = fresh (a.row t).x (a.grad (a.row t).x) (a.E/2))))) := by
  obtain ⟨t, ht, hlen, he, hpre⟩ := first_event a k htable hε hactive hE
  have hJ : a.table.length ≤ 4*2^k := htable ▸ GDProof.GuardSizes.table_length k
  exact ⟨t, ht, hlen, hlen.trans hJ, a.run_to_endpoint t ht hlen hpre, a.endpoint_of_event t he⟩

end
end GDProof.EpochLength
