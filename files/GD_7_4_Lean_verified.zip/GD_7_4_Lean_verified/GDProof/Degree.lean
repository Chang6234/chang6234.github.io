import Mathlib

/-! The dyadic degree is the unique power of two immediately below the target
scale, including equality. Targets below one use the base table. -/

namespace GDProof.Degree

private theorem exists_exponent (R : ℝ) :
    ∃ k : ℕ, (2 : ℝ) ^ k ≤ max R 1 ∧ max R 1 < (2 : ℝ) ^ (k + 1) :=
  exists_nat_pow_near (le_max_right R 1) (by norm_num)

/-- The smallest natural exponent with the required bracketing property. -/
noncomputable def exponent (R : ℝ) : ℕ := by
  classical
  exact Nat.find (exists_exponent R)

theorem exponent_spec (R : ℝ) (hR : 1 ≤ R) :
    (2 : ℝ) ^ (exponent R) ≤ R ∧ R < (2 : ℝ) ^ (exponent R + 1) := by
  classical
  simpa only [exponent, max_eq_left hR] using Nat.find_spec (exists_exponent R)

theorem exponent_bounds (R : ℝ) (hR : 1 ≤ R) :
    (2 : ℝ) ^ (exponent R) ≤ R ∧ R ≤ 2 * (2 : ℝ) ^ (exponent R) := by
  obtain ⟨hlo, hhi⟩ := exponent_spec R hR
  refine ⟨hlo, le_of_lt ?_⟩
  simpa only [pow_succ, mul_comm] using hhi

end GDProof.Degree
