import GDProof.Model
import GDProof.Schedule
import GDProof.Degree

namespace GDProof

noncomputable section

abbrev Space (d : ℕ) := EuclideanSpace ℝ (Fin d)

/-- The gradient and its Fréchet derivative, with the inequalities from the paper. -/
structure Problem (d : ℕ) where
  f : Space d → ℝ
  grad : Space d → Space d
  hess : Space d → (Space d →L[ℝ] Space d)
  L : ℝ
  ρ : ℝ
  L_pos : 0 < L
  ρ_pos : 0 < ρ
  bounded : BddBelow (Set.range f)
  gradientAt : ∀ x, HasGradientAt f (grad x) x
  hessianAt : ∀ x, HasFDerivAt grad (hess x) x
  lipGrad : ∀ x y, ‖grad x - grad y‖ ≤ L * ‖x - y‖
  lipHess : ∀ x y, ‖hess x - hess y‖ ≤ ρ * ‖x - y‖

def degreeScale (L ρ ε : ℝ) : ℝ := (L ^ 2 / (ρ * ε)) ^ (1 / 4 : ℝ)

def chosenTable (L ρ ε : ℝ) : List ℝ :=
  Schedule.table (Degree.exponent (max 1 (degreeScale L ρ ε)))

def gradientBound (L ρ ε Δ : ℝ) : ℝ :=
  1 + degreeScale L ρ ε + Δ * Real.sqrt L * ρ ^ (1 / 4 : ℝ) * ε ^ (-(7 / 4 : ℝ))

/-- The unconditional target from the manuscript. No proof of this proposition
is asserted by this declaration. An exhausted table cannot yield a witness.
The natural number k counts updates and k+1 counts exact gradient calls. -/
def MainGuarantee : Prop :=
  ∃ C : ℝ, 0 < C ∧ ∀ (d : ℕ) (P : Problem d) (ε : ℝ), 0 < ε →
    ∀ x₀ : Space d,
      let T := chosenTable P.L P.ρ ε
      ∃ (k : ℕ) (s : Model.State (Space d)),
        Model.run P.grad P.L ε T (Model.initial P.grad x₀ T ε) k = some s ∧
        ‖P.grad s.x‖ ≤ ε ∧
        ((k + 1 : ℕ) : ℝ) ≤ C * gradientBound P.L P.ρ ε (P.f x₀ - sInf (Set.range P.f))

/-- The return test certifies stationarity for the objective's true gradient. -/
theorem terminal_gradient {d : ℕ} (P : Problem d) {x₀ : Space d} {ε : ℝ}
    {T : List ℝ} {k : ℕ} {s : Model.State (Space d)}
    (trace : Model.run P.grad P.L ε T (Model.initial P.grad x₀ T ε) k = some s)
    (stop : ‖s.g‖ ≤ ε) : ‖P.grad s.x‖ ≤ ε := by
  simpa only [Model.cached_run trace] using stop

end
end GDProof
