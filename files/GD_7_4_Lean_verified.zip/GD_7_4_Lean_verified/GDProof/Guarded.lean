import GDProof.RawPrefix
import GDProof.Quadratic

namespace GDProof.Guarded

open GDProof.Schedule GDProof.Prefix
open scoped BigOperators

private theorem good_nil (z : ℝ) : Stable z [] ∧ Nonnegative [] := by
  constructor
  · intro p s h
    cases p with
    | nil => norm_num [potential, energy, prod]
    | cons a p => cases h
  · intro a ha
    cases ha

private theorem splice_nonneg (previous : ℕ → List ℝ) (n : ℕ)
    (hprev : ∀ i, Nonnegative (previous i)) (j : ℕ) (w : List ℝ) (hw : Nonnegative w) :
    Nonnegative (splice previous n j w) := by
  induction w generalizing j with
  | nil => exact (good_nil 0).2
  | cons a t ih =>
    have ha : 0 ≤ a := hw a (by simp)
    have ht : Nonnegative t := fun h hh => hw h (by simp [hh])
    intro h hh
    simp only [splice, List.mem_append, List.mem_cons] at hh
    rcases hh with hq | rfl | hq | hs
    · exact hprev _ h hq
    · exact ha
    · exact hprev _ h hq
    · exact ih (j + 1) ht h hs

/-- Insert the two guards around each remaining raw step. The prefix p contains
the previously processed steps and stays in the inductive statement. -/
private theorem splice_stable {z : ℝ} (hz : 0 ≤ z) (previous : ℕ → List ℝ) (n : ℕ)
    (hprev : ∀ i, Stable z (previous i) ∧ Nonnegative (previous i))
    (j : ℕ) (w p : List ℝ) (hw : Stable z (p ++ w)) :
    Stable z (p ++ splice previous n j w) := by
  induction w generalizing p j with
  | nil => exact hw
  | cons a t ih =>
    let q := previous (guardSize n j)
    let s := splice previous n (j + 1) t
    have hq : Stable z q ∧ Nonnegative q := hprev _
    have hps : Stable z ((p ++ [a]) ++ s) := by
      apply ih (j := j + 1) (p := p ++ [a])
      simpa [List.append_assoc] using hw
    have hright := stable_insert (p ++ [a]) q s hz hq.2 hps hq.1
    have hright' : Stable z (p ++ (a :: (q ++ s))) := by
      simpa [List.append_assoc] using hright
    exact stable_insert p q (a :: (q ++ s)) hz hq.2 hright' hq.1

/-- All the cached tables, including unused keys, satisfy the prefix inequality. -/
theorem history_stable (k i : ℕ) (z : ℝ) (hz₀ : 0 ≤ z) (hz₁ : z ≤ 1) :
    Stable z (history k i) ∧ Nonnegative (history k i) := by
  induction k generalizing i with
  | zero => exact good_nil z
  | succ k ih =>
    by_cases he : i = 2 ^ k
    · subst i
      simp only [history, if_pos rfl]
      constructor
      · have h := RawPrefix.raw_stable k z hz₀ hz₁
        exact splice_stable hz₀ (history k) (2 ^ k) ih 0 (raw k) [] h
      · apply splice_nonneg (history k) (2 ^ k) (fun j => (ih j).2)
        intro a ha
        exact le_trans zero_le_one (raw_lower k a ha)
    · simpa [history, he] using ih i

/-- Manuscript equation (prefix) for the recursively guarded schedule. -/
theorem table_stable (k : ℕ) (z : ℝ) (hz₀ : 0 ≤ z) (hz₁ : z ≤ 1) : Stable z (table k) :=
  (history_stable (k + 1) (2 ^ k) z hz₀ hz₁).1

theorem table_nonnegative (k : ℕ) : Nonnegative (table k) :=
  (history_stable (k + 1) (2 ^ k) 0 (le_refl _) zero_le_one).2

/-- Any executed prefix of F_n may shorten its final coefficient to any value in [0,a]. -/
theorem executed_prefix (k : ℕ) (z : ℝ) (hz₀ : 0 ≤ z) (hz₁ : z ≤ 1)
    (p s : List ℝ) (a b : ℝ) (hcut : table k = (p ++ [a]) ++ s) (hb : 0 ≤ b) (hba : b ≤ a) :
    Stable z (p ++ [b]) := by
  have hw := table_stable k z hz₀ hz₁
  rw [hcut] at hw
  exact stable_shorten (stable_left hw) hb hba

theorem executed_nonnegative (k : ℕ) (p s : List ℝ) (a b : ℝ)
    (hcut : table k = (p ++ [a]) ++ s) (hb : 0 ≤ b) : Nonnegative (p ++ [b]) := by
  intro u hu
  rcases List.mem_append.mp hu with hu | hu
  · apply table_nonnegative k u
    rw [hcut]
    simp [hu]
  · simp only [List.mem_singleton] at hu
    simpa [hu] using hb

/-- Weighted descent for the actual clipped GD trajectory of a diagonal quadratic,
with only a curvature upper bound on the quadratic data. The normalization is f/L. -/
theorem executed_quadratic_decrease {ι : Type*} [Fintype ι] (k : ℕ)
    (z c x : ι → ℝ) (hz : ∀ i, z i ≤ 1) (p s : List ℝ) (a b : ℝ)
    (hcut : table k = (p ++ [a]) ++ s) (hb : 0 ≤ b) (hba : b ≤ a) :
    (∑ i, Quadratic.spending (z i) (c i) (p ++ [b]) (x i)) ≤
    2 * ((∑ i, Quadratic.value (z i) (c i) (x i)) -
      ∑ i, Quadratic.value (z i) (c i) (Quadratic.run (z i) (c i) (p ++ [b]) (x i))) := by
  apply Quadratic.diagonal_decrease z c x _ (executed_nonnegative k p s a b hcut hb)
  intro i hi
  exact executed_prefix k (z i) hi.le (hz i) p s a b hcut hb hba

end GDProof.Guarded
