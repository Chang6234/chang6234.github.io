import GDProof.Model

namespace GDProof.TraceCount

noncomputable section
open GDProof.Model

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- Following two pieces of the same trace gives their concatenation. -/
theorem run_add (g : V → V) (L ε : ℝ) (T : List ℝ) (s u : State V)
    (k l : ℕ) (h : run g L ε T s k = some u) :
    run g L ε T s (k+l) = run g L ε T u l := by
  induction l with
  | zero => simpa [run] using h
  | succ l ih =>
    rw [Nat.add_succ, run, run, ih]

/-- One epoch from an admissible starting state costs at most J updates. It
either reaches a small gradient or produces the next admissible epoch state
with potential reduced by drop. Both outcomes are actual algorithm traces. -/
def EpochProgress (g : V → V) (L ε : ℝ) (T : List ℝ) (J : ℕ)
    (admissible : State V → Prop) (potential : State V → ℝ) (drop : ℝ) : Prop :=
  ∀ s, admissible s → ε < ‖s.g‖ → ∃ (j : ℕ) (u : State V),
    0 < j ∧ j ≤ J ∧ run g L ε T s j = some u ∧
    (‖u.g‖ ≤ ε ∨ (admissible u ∧ potential u + drop ≤ potential s))

/-- Eliminates the abstract count of epochs. The witness is an actual
algorithm iterate evaluated by Model.run. -/
theorem terminal_from_progress (g : V → V) (L ε : ℝ) (T : List ℝ) (J : ℕ)
    (admissible : State V → Prop) (potential : State V → ℝ) (drop : ℝ)
    (lower : ∀ s, admissible s → 0 ≤ potential s)
    (hp : EpochProgress g L ε T J admissible potential drop)
    (N : ℕ) (s : State V) (hs : admissible s) (hN : potential s < (N : ℝ) * drop) :
    ∃ (k : ℕ) (v : State V), k ≤ J*N ∧ run g L ε T s k = some v ∧ ‖v.g‖ ≤ ε := by
  induction N generalizing s with
  | zero =>
    exfalso
    exact (not_lt.mpr (lower s hs)) (by simpa using hN)
  | succ n ih =>
    by_cases hactive : ε < ‖s.g‖
    · obtain ⟨j,u,_,hj,hu,hstop | ⟨hadm,hdec⟩⟩ := hp s hs hactive
      · exact ⟨j,u, by rw [Nat.mul_succ]; exact hj.trans (Nat.le_add_left _ _), hu, hstop⟩
      · have hn : potential u < (n : ℝ) * drop := by
          rw [Nat.cast_succ] at hN
          linarith only [hdec, hN, add_mul (n : ℝ) 1 drop, one_mul drop]
        obtain ⟨k,v,hk,hr,hv⟩ := ih u hadm hn
        refine ⟨j+k, v, ?_, (run_add g L ε T s u j k hu).trans hr, hv⟩
        rw [Nat.mul_succ, Nat.add_comm (J*n) J]
        exact Nat.add_le_add hj hk
    · exact ⟨0,s,Nat.zero_le _,rfl,le_of_not_gt hactive⟩

end
end GDProof.TraceCount
