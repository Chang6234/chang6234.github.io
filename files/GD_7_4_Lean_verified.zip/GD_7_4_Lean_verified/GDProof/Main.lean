import GDProof.PairReduction
import GDProof.RegularPairs
import GDProof.SameSite

namespace GDProof

/-- The manuscript's dimension-independent complexity theorem for the actual
adaptive scalar gradient descent iteration and the stated regularity class. -/
theorem main_guarantee : MainGuarantee := by
  obtain ⟨A, hA, reg⟩ := RegularPairs.bound
  obtain ⟨B, hB, same⟩ := SameSite.same_site
  apply PairReduction.main_of_pair_estimates hA.le hB.le
  · intro k z hz h1 i l hi hl hne
    have hy : i+1+l < 3*2^k := by omega
    simpa only [PairTotal.blocks, PairTotal.weightAt, PairTotal.q, Real.sq_sqrt hz.le]
      using reg k z hz h1 i l hy hne
  · exact same

end GDProof
