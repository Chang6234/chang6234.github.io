import GDProof.Model

/-! Finite trajectories of one clipped epoch and their correspondence with the
executable, resetting model. -/
namespace GDProof.TraceData
open GDProof.Model
open scoped BigOperators
noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

structure Input (V : Type*) where
  grad : V → V
  L : ℝ
  ε : ℝ
  table : List ℝ
  x0 : V
  E : ℝ

structure Row (V : Type*) where
  x : V
  spent : ℝ
  cross : ℝ

namespace Input

def cap (a : Input V) : ℝ := max a.E (‖a.grad a.x0‖^2)

def row (a : Input V) : ℕ → Row V
  | 0 => ⟨a.x0, 0, 0⟩
  | i+1 =>
    let r := row a i
    let b := a.table.getD i 0
    let h := clip b r.spent a.cap (‖a.grad r.x‖^2)
    let x' := r.x - (h/a.L) • a.grad r.x
    ⟨x', r.spent + h * ‖a.grad r.x‖^2, r.cross + h * ⟪a.grad r.x, a.grad x'⟫_ℝ⟩

def coef (a : Input V) (i : ℕ) : ℝ :=
  clip (a.table.getD i 0) (a.row i).spent a.cap (‖a.grad (a.row i).x‖^2)

def event (a : Input V) (n : ℕ) : Prop :=
  ‖a.grad (a.row n).x‖ ≤ a.ε ∨ (a.row n).spent = a.cap

def state (a : Input V) (n : ℕ) : State V :=
  ⟨(a.row n).x, a.grad (a.row n).x, n, (a.row n).spent, (a.row n).cross, a.E, a.cap⟩

theorem row_succ_x (a : Input V) (i : ℕ) :
    (a.row (i+1)).x = (a.row i).x - (a.coef i/a.L) • a.grad (a.row i).x := rfl

theorem row_succ_spent (a : Input V) (i : ℕ) :
    (a.row (i+1)).spent = (a.row i).spent + a.coef i * ‖a.grad (a.row i).x‖^2 := rfl

theorem row_succ_cross (a : Input V) (i : ℕ) :
    (a.row (i+1)).cross = (a.row i).cross +
      a.coef i * ⟪a.grad (a.row i).x, a.grad (a.row (i+1)).x⟫_ℝ := rfl

theorem spent_sum (a : Input V) (n : ℕ) :
    (a.row n).spent = ∑ i in Finset.range n, a.coef i * ‖a.grad (a.row i).x‖^2 := by
  induction n with
  | zero => simp [row]
  | succ n ih => rw [row_succ_spent, ih, Finset.sum_range_succ]

theorem cross_sum (a : Input V) (n : ℕ) :
    (a.row n).cross = ∑ i in Finset.range n,
      a.coef i * ⟪a.grad (a.row i).x, a.grad (a.row (i+1)).x⟫_ℝ := by
  induction n with
  | zero => simp [row]
  | succ n ih => rw [row_succ_cross, ih, Finset.sum_range_succ]

/-- State published by the last update of the epoch. The row retains the
alignment logs even when the executable state resets them. -/
def endpoint (a : Input V) (n : ℕ) : State V :=
  let r := a.row n
  if r.spent = a.cap ∧ a.ε < ‖a.grad r.x‖ then
    fresh r.x (a.grad r.x) (if r.cross < -r.spent/2 then a.E/2 else a.E)
  else a.state n

theorem run_step (a : Input V) (i : ℕ) (hi : i < a.table.length)
    (hg : a.ε < ‖a.grad (a.row i).x‖) :
    step a.grad a.L a.ε a.table (a.state i) = some (a.endpoint (i+1)) := by
  have hget : a.table.get? i = some (a.table.getD i 0) := by
    rw [List.get?_eq_get hi, List.getD_eq_get _ _ hi]
  change (if a.ε < ‖a.grad (a.row i).x‖ then (a.table.get? i).map
    (fun b => advance a.grad a.L a.ε b (a.state i)) else none) = _
  rw [if_pos hg, hget]
  rfl

/-- Before the first event the global run follows the fixed-cap row exactly. -/
theorem run_before_event (a : Input V) (n : ℕ) (hn : n ≤ a.table.length)
    (hbefore : ∀ i ≤ n, ¬ a.event i) :
    run a.grad a.L a.ε a.table (fresh a.x0 (a.grad a.x0) a.E) n = some (a.state n) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    have hp := ih (by omega) (fun i hi => hbefore i (Nat.le_succ_of_le hi))
    have hgrad : a.ε < ‖a.grad (a.row n).x‖ := lt_of_not_ge
      (fun h => hbefore n (Nat.le_succ n) (Or.inl h))
    have hcap : ¬ (a.row (n+1)).spent = a.cap :=
      fun h => hbefore (n+1) le_rfl (Or.inr h)
    rw [run, hp, Option.some_bind, a.run_step n (by omega) hgrad]
    simp [endpoint, hcap]

/-- The executable run reaches the row's endpoint on the first terminal or
cap step. All preceding rows are states of the same executable run. -/
theorem run_to_endpoint (a : Input V) (n : ℕ) (hn₀ : 0 < n) (hn : n ≤ a.table.length)
    (hbefore : ∀ i < n, ¬ a.event i) :
    run a.grad a.L a.ε a.table (fresh a.x0 (a.grad a.x0) a.E) n = some (a.endpoint n) := by
  obtain ⟨i, rfl⟩ := Nat.exists_eq_succ_of_ne_zero hn₀.ne'
  have hp := a.run_before_event i (by omega) (fun j hj => hbefore j (by omega))
  have hgrad : a.ε < ‖a.grad (a.row i).x‖ := lt_of_not_ge
    (fun h => hbefore i (Nat.lt_succ_self i) (Or.inl h))
  rw [run, hp, Option.some_bind, a.run_step i (by omega) hgrad]

theorem endpoint_x (a : Input V) (n : ℕ) : (a.endpoint n).x = (a.row n).x := by
  unfold endpoint
  dsimp only
  split <;> rfl

theorem endpoint_g (a : Input V) (n : ℕ) : (a.endpoint n).g = a.grad (a.row n).x := by
  unfold endpoint
  dsimp only
  split <;> rfl

theorem endpoint_of_event (a : Input V) (n : ℕ) (he : a.event n) :
    ‖(a.endpoint n).g‖ ≤ a.ε ∨
      ((a.row n).spent = a.cap ∧
        ((-((a.row n).spent)/2 ≤ (a.row n).cross ∧
           a.endpoint n = fresh (a.row n).x (a.grad (a.row n).x) a.E) ∨
         ((a.row n).cross < -((a.row n).spent)/2 ∧
           a.endpoint n = fresh (a.row n).x (a.grad (a.row n).x) (a.E/2)))) := by
  by_cases hstop : ‖a.grad (a.row n).x‖ ≤ a.ε
  · exact Or.inl (by simpa only [endpoint_g] using hstop)
  · have hcap := he.resolve_left hstop
    have hactive := lt_of_not_ge hstop
    right
    refine ⟨hcap, ?_⟩
    by_cases hfail : (a.row n).cross < -((a.row n).spent)/2
    · exact Or.inr ⟨hfail, by simp [endpoint, hcap, hactive, hfail, hcap ▸ hfail]⟩
    · exact Or.inl ⟨le_of_not_gt hfail, by simp [endpoint, hcap, hactive, hfail, hcap ▸ hfail]⟩

/-- A guarded update never overspends its fixed cap, even if the gradient
vanishes. This concerns the auxiliary rows; the executable stops at zero. -/
theorem spent_le_cap (a : Input V) (n : ℕ) : (a.row n).spent ≤ a.cap := by
  induction n with
  | zero => exact (sq_nonneg _).trans (le_max_right _ _)
  | succ i ih =>
    rw [row_succ_spent]
    by_cases hq : ‖a.grad (a.row i).x‖^2 = 0
    · simpa [hq] using ih
    · have h := mul_le_mul_of_nonneg_right
        (min_le_right (a.table.getD i 0) ((a.cap-(a.row i).spent) / ‖a.grad (a.row i).x‖^2))
        (sq_nonneg ‖a.grad (a.row i).x‖)
      rw [div_mul_cancel₀ _ hq] at h
      change (a.row i).spent + min _ _ * _ ≤ a.cap
      linarith only [h]

theorem coef_nonnegative (a : Input V) (i : ℕ) (hi : i < a.table.length)
    (ht : ∀ b ∈ a.table, 0 ≤ b) : 0 ≤ a.coef i := by
  apply le_min
  · rw [List.getD_eq_get _ _ hi]
    exact ht _ (List.get_mem _ _ _)
  · exact div_nonneg (sub_nonneg.mpr (a.spent_le_cap i)) (sq_nonneg _)

theorem coef_le_table (a : Input V) (i : ℕ) : a.coef i ≤ a.table.getD i 0 := min_le_left _ _

/-- Every earlier coefficient in a first-event prefix is unchanged. -/
theorem coef_eq_table (a : Input V) (i : ℕ) (hε : 0 ≤ a.ε)
    (hactive : ¬ a.event i) (hnext : ¬ a.event (i+1)) : a.coef i = a.table.getD i 0 := by
  apply le_antisymm (a.coef_le_table i)
  by_contra! hshort
  have hg : a.ε < ‖a.grad (a.row i).x‖ := lt_of_not_ge (fun h => hactive (Or.inl h))
  have hq := sq_pos_of_pos (lt_of_le_of_lt hε hg)
  apply hnext
  right
  rw [row_succ_spent]
  exact shortened_spends_cap hq hshort

def executed (a : Input V) (n : ℕ) : List ℝ := (List.range n).map a.coef

theorem executed_succ (a : Input V) (i : ℕ) :
    a.executed (i+1) = a.executed i ++ [a.coef i] := by
  simp [executed, List.range_succ]

theorem executed_full_prefix (a : Input V) (n : ℕ) (hn : n ≤ a.table.length) (hε : 0 ≤ a.ε)
    (he : ∀ i ≤ n, ¬ a.event i) : a.executed n = a.table.take n := by
  induction n with
  | zero => simp [executed]
  | succ i ih =>
    have hi : i < a.table.length := by omega
    rw [executed_succ, ih (by omega) (fun j hj => he j (by omega)), List.take_succ,
      a.coef_eq_table i hε (he i (by omega)) (he (i+1) le_rfl),
      List.get?_eq_get hi, List.getD_eq_get _ _ hi]
    rfl

/-- The actual executed list is a full prefix followed by a single, possibly
shortened, table coefficient. The decomposition is directly usable with the
spectral prefix and kernel estimates. -/
theorem last_coefficient_cut (a : Input V) (i : ℕ) (hi : i < a.table.length) (hε : 0 ≤ a.ε)
    (ht : ∀ b ∈ a.table, 0 ≤ b) (he : ∀ j < i+1, ¬ a.event j) :
    a.table = ((a.table.take i) ++ [a.table.getD i 0]) ++ a.table.drop (i+1) ∧
    a.executed (i+1) = (a.table.take i) ++ [a.coef i] ∧
    0 ≤ a.coef i ∧ a.coef i ≤ a.table.getD i 0 := by
  refine ⟨?_, ?_, a.coef_nonnegative i hi ht, a.coef_le_table i⟩
  · have hx := List.take_append_drop (i+1) a.table
    rw [List.take_succ, List.get?_eq_get hi] at hx
    rw [List.getD_eq_get _ _ hi]
    exact hx.symm
  · rw [executed_succ, a.executed_full_prefix i hi.le hε (fun j hj => he j (by omega))]

theorem sum_table_prefix (a : Input V) (n : ℕ) (hn : n ≤ a.table.length) :
    (∑ i in Finset.range n, a.table.getD i 0) = (a.table.take n).sum := by
  induction n with
  | zero => simp
  | succ i ih =>
    have hi : i < a.table.length := by omega
    rw [Finset.sum_range_succ, ih hi.le, List.take_succ, List.get?_eq_get hi,
      List.getD_eq_get _ _ hi]
    simp

theorem sum_coef_le_table (a : Input V) (n : ℕ) (hn : n ≤ a.table.length)
    (ht : ∀ b ∈ a.table, 0 ≤ b) :
    (∑ i in Finset.range n, a.coef i) ≤ a.table.sum := by
  have hdrop : 0 ≤ (a.table.drop n).sum := by
    apply List.sum_nonneg
    intro b hb
    apply ht b
    rw [← List.take_append_drop n a.table]
    exact List.mem_append.mpr (Or.inr hb)
  calc
    _ ≤ ∑ i in Finset.range n, a.table.getD i 0 := Finset.sum_le_sum (fun i _ => a.coef_le_table i)
    _ = _ := a.sum_table_prefix n hn
    _ ≤ a.table.sum := by
      have hh := congrArg List.sum (List.take_append_drop n a.table)
      rw [List.sum_append] at hh
      linarith

end Input
end
end GDProof.TraceData
