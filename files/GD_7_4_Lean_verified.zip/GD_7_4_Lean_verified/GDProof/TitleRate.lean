import GDProof.Main

/-! A single-power version of the main theorem for a fixed objective
and starting point. The same constant works for every tolerance in (0, 1]. -/

namespace GDProof

theorem title_rate {d : ℕ} (P : Problem d) (x₀ : Space d) :
    ∃ D : ℝ, 0 < D ∧ ∀ ε : ℝ, 0 < ε → ε ≤ 1 →
      ∃ (k : ℕ) (s : Model.State (Space d)),
        Model.run P.grad P.L ε (chosenTable P.L P.ρ ε)
          (Model.initial P.grad x₀ (chosenTable P.L P.ρ ε) ε) k = some s ∧
        ‖P.grad s.x‖ ≤ ε ∧
        ((k + 1 : ℕ) : ℝ) ≤ D * ε ^ (-(7/4 : ℝ)) := by
  obtain ⟨C, hC, guarantee⟩ := main_guarantee
  let A : ℝ := (P.L ^ 2 / P.ρ) ^ (1/4 : ℝ)
  let B : ℝ := (P.f x₀ - sInf (Set.range P.f)) * Real.sqrt P.L * P.ρ ^ (1/4 : ℝ)
  have hA : 0 ≤ A := Real.rpow_nonneg (div_nonneg (sq_nonneg _) P.ρ_pos.le) _
  have hgap : 0 ≤ P.f x₀ - sInf (Set.range P.f) :=
    sub_nonneg.mpr (csInf_le P.bounded ⟨x₀, rfl⟩)
  have hB : 0 ≤ B := mul_nonneg (mul_nonneg hgap (Real.sqrt_nonneg _))
    (Real.rpow_nonneg P.ρ_pos.le _)
  refine ⟨C * (1 + A + B), mul_pos hC (by linarith), ?_⟩
  intro ε hε hε₁
  obtain ⟨k, s, hrun, hstop, hcount⟩ := guarantee d P ε hε x₀
  refine ⟨k, s, hrun, hstop, hcount.trans ?_⟩
  have hscale : degreeScale P.L P.ρ ε = A * ε ^ (-(1/4 : ℝ)) := by
    dsimp only [degreeScale, A]
    rw [← div_div, Real.div_rpow (div_nonneg (sq_nonneg _) P.ρ_pos.le) hε.le,
      Real.rpow_neg hε.le, div_eq_mul_inv]
  have hone : 1 ≤ ε ^ (-(7/4 : ℝ)) :=
    Real.one_le_rpow_of_pos_of_le_one_of_nonpos hε hε₁ (by norm_num)
  have hquarter : ε ^ (-(1/4 : ℝ)) ≤ ε ^ (-(7/4 : ℝ)) :=
    Real.rpow_le_rpow_of_exponent_ge hε hε₁ (by norm_num)
  rw [mul_assoc]
  apply mul_le_mul_of_nonneg_left _ hC.le
  unfold gradientBound
  rw [hscale]
  change 1 + A * ε ^ (-(1/4 : ℝ)) + B * ε ^ (-(7/4 : ℝ)) ≤ _
  rw [add_mul, add_mul, one_mul]
  exact add_le_add_right (add_le_add hone (mul_le_mul_of_nonneg_left hquarter hA)) _

end GDProof
