import GDProof.RawPrefix

namespace GDProof.RawProduct

open GDProof.Schedule GDProof.Prefix GDProof.RawPrefix

/-- Doubling replaces z by y = 4z(1-z) and supplies the additional factor 1-2z.
The identity y(1-y) = 4z(1-z)(1-2z)^2 propagates the weighted bound directly. -/
theorem rawTail_product_sq (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    (4:ℝ)^(k+1)*z*(1-z)*(prod z (rawTail k))^2 ≤ 1 := by
  induction k generalizing z with
  | zero =>
    simp only [rawTail, prod, one_pow, mul_one]
    norm_num at *
    nlinarith [sq_nonneg (1-2*z)]
  | succ k ih =>
    have hy₀ : 0 ≤ 4*z*(1-z) := mul_nonneg (mul_nonneg (by norm_num) hz) (sub_nonneg.mpr h₁)
    have hy₁ : 4*z*(1-z) ≤ 1 := by nlinarith [sq_nonneg (1-2*z)]
    have hb := ih (4*z*(1-z)) hy₀ hy₁
    simp only [rawTail, prod, children_prod z (rawTail k) (rawTail_lower k)]
    calc
      _ = (4:ℝ)^(k+1)*(4*z*(1-z))*(1-4*z*(1-z))
          *(prod (4*z*(1-z)) (rawTail k))^2 := by
        rw [pow_succ (4:ℝ) (k+1)]
        ring
      _ ≤ 1 := hb

theorem raw_product_sq (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    (4:ℝ)^(k+1)*z*(prod z (raw k))^2 ≤ 1-z := by
  calc
    _ = (1-z)*((4:ℝ)^(k+1)*z*(1-z)*(prod z (rawTail k))^2) := by
      simp only [raw, prod, mul_one]
      ring
    _ ≤ (1-z)*1 := mul_le_mul_of_nonneg_left (rawTail_product_sq k z hz h₁) (sub_nonneg.mpr h₁)
    _ = _ := mul_one _

/-- Sharp raw complete-product bound used in the recursive damping argument. -/
theorem raw_product_decay (k : ℕ) (z : ℝ) (hz : 0 < z) (h₁ : z ≤ 1) :
    |prod z (raw k)| ≤ 1/(2*(2:ℝ)^k*Real.sqrt z) := by
  have hd : 0 < 2*(2:ℝ)^k*Real.sqrt z := by positivity
  apply (le_div_iff hd).2
  have hp : ((2:ℝ)^k)^2 = (4:ℝ)^k := by rw [pow_two, ← mul_pow]; norm_num
  have he : (|prod z (raw k)| * (2*(2:ℝ)^k*Real.sqrt z))^2
      = (4:ℝ)^(k+1)*z*(prod z (raw k))^2 := by
    simp only [mul_pow, sq_abs, Real.sq_sqrt hz.le, hp, pow_succ (4:ℝ) k]
    ring
  have hb := raw_product_sq k z hz.le h₁
  nlinarith only [he, hb, hz.le, sq_nonneg (|prod z (raw k)| * (2*(2:ℝ)^k*Real.sqrt z)-1)]

end GDProof.RawProduct
