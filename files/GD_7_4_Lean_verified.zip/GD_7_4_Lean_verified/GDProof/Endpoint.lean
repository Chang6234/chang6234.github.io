import GDProof.Suffix

namespace GDProof.Endpoint

open GDProof.Schedule GDProof.Guarded GDProof.GuardDecay GDProof.GuardSizes GDProof.Suffix
open GDProof.Prefix GDProof.Kernel
noncomputable section

theorem product_eq (z : ℝ) (w : List ℝ) : product z w = (prod z w)^2 := by
  induction w with
  | nil => simp [product,prod]
  | cons a t ih => simp [product,prod,ih,factor,mul_pow]

private theorem reverse_bound (z M H : ℝ) (hz : 0 ≤ z) (hm : 0 ≤ M) (w : List ℝ)
    (hw : Nonnegative w) (hH : ∀ a ∈ w, a ≤ H) (hs : Bounded z M w) :
    reverseResponse z (weight z) w ≤ M^2 * (1+z*H) * w.sum := by
  induction w with
  | nil => simp [reverseResponse]
  | cons a t ih =>
    have ha := hw a (by simp)
    have hcap := hH a (by simp)
    have hp := hs [a] t rfl
    have htail : Bounded z M t := fun l s he => hs (a::l) s (by simp [he])
    have h := ih (fun b hb => hw b (by simp [hb])) (fun b hb => hH b (by simp [hb])) htail
    have hps : (prod z t)^2 ≤ M^2 := by
      rw [← sq_abs]
      exact pow_le_pow_left (abs_nonneg _) hp _
    have hm' : 0 ≤ 1+z*H := by linarith [mul_nonneg hz (le_trans ha hcap)]
    have hwt : weight z a ≤ a*(1+z*H) := by
      unfold weight
      exact mul_le_mul_of_nonneg_left (add_le_add_left (mul_le_mul_of_nonneg_left hcap hz) _) ha
    rw [reverseResponse, product_eq,List.sum_cons]
    calc
      _ ≤ (a*(1+z*H))*M^2 + M^2*(1+z*H)*t.sum :=
        add_le_add (mul_le_mul hwt hps (sq_nonneg _) (mul_nonneg ha hm')) h
      _ = _ := by ring

private theorem table_hist (M : ℝ) (hM : 1 ≤ M)
    (hb : ∀ k z, 0 ≤ z → z ≤ 1 → Bounded z M (table k))
    (d i : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) : Bounded z M (history d i) := by
  induction d with
  | zero =>
    intro l s he
    obtain ⟨_,rfl⟩ := List.append_eq_nil.mp he.symm
    simpa [prod] using hM
  | succ d ih =>
    by_cases he : i = 2^d
    · subst i; exact hb _ _ hz h₁
    · simpa [history,he] using ih

private theorem mass_and_cap (k : ℕ) (q t : List ℝ) (he : table k = q ++ t) :
    q.sum ≤ 2*(4:ℝ)^k ∧ Nonnegative q ∧ ∀ a ∈ q, a ≤ 2*(4:ℝ)^k := by
  have hp := table_nonnegative k
  rw [he] at hp
  have hm := table_mass k
  rw [he,List.sum_append] at hm
  have hn : 0 ≤ t.sum := List.sum_nonneg (fun b hb => hp b (by simp [hb]))
  have hpow : ((2:ℝ)^k)^2 = (4:ℝ)^k := by rw [pow_two,←mul_pow];norm_num
  rw [hpow] at hm
  have hql : q.sum ≤ 2*(4:ℝ)^k := by linarith
  have hq : Nonnegative q := fun b hb => hp b (by simp [hb])
  refine ⟨hql,hq,?_⟩
  intro a ha
  have hlocal : ∀ w : List ℝ, Nonnegative w → a ∈ w → a ≤ w.sum := by
    intro w hw ha
    induction w with
    | nil => cases ha
    | cons b w ih =>
      have hn' : Nonnegative w := fun c hc => hw c (by simp [hc])
      simp only [List.sum_cons]
      rcases List.mem_cons.mp ha with rfl | ha
      · linarith [List.sum_nonneg hn']
      · linarith [ih hn' ha,hw b (by simp)]
  exact (hlocal q hq ha).trans hql

private theorem cap_bound (k : ℕ) (q t : List ℝ) (he : table k = q ++ t) (z M : ℝ)
    (hz : 0 ≤ z) (hm : 0 ≤ M) (hs : Bounded z M q) :
    reverseResponse z (weight z) q ≤ 4 * M^2 * scale k z * (4:ℝ)^k := by
  obtain ⟨hmass,hn,hcap⟩ := mass_and_cap k q t he
  have hb := reverse_bound _ _ _ hz hm _ hn hcap hs
  have hX : 0 ≤ scale k z := (scale_pos _ _ hz).le
  have hcap' : 1+z*(2*(4:ℝ)^k) ≤ 2*scale k z := by unfold scale; linarith
  calc
    _ ≤ _ := hb
    _ ≤ (M^2*(2*scale k z))*(2*(4:ℝ)^k) :=
      mul_le_mul (mul_le_mul_of_nonneg_left hcap' (sq_nonneg _)) hmass
        (List.sum_nonneg hn) (mul_nonneg (sq_nonneg _) (by linarith))
    _ = _ := by ring

private theorem increment (M C : ℝ) (hM : 1 ≤ M) (hC : 0 < C)
    (hb : ∀ k z, 0 ≤ z → z ≤ 1 → Bounded z M (table k))
    (hc : ∀ k z, 0 ≤ z → z ≤ 1 → (scale (k+2) z)^7 * (prod z (table k))^2 ≤ C)
    (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    reverseResponse z (weight z) (table (k+2)) ≤ reverseResponse z (weight z) (table k) +
      (4*M^2*C) * (4:ℝ)^(k+2) / (scale (k+2) z)^2 := by
  obtain ⟨q,he,hs⟩ := remove_final k z M hM hz h₁ (fun i => table_hist M hM hb _ i z hz h₁)
  let X := scale (k+2) z
  let N := (4:ℝ)^(k+2)
  have hX : 1 ≤ X := by
    change 1 ≤ 1+z*N
    have : 0 ≤ z*N := mul_nonneg hz (by dsimp [N]; positivity)
    linarith
  have hpos : 0 < X := by linarith
  have hN : 0 ≤ N := by dsimp [N]; positivity
  have hm : 0 ≤ M := by linarith
  have hq := cap_bound (k+2) q (table k) he z (M*X) hz (mul_nonneg hm hpos.le) hs
  change reverseResponse z (weight z) q ≤ 4*(M*X)^2*X*N at hq
  have hprod := hc k z hz h₁
  have hpx : X^5 * (prod z (table k))^2 ≤ C :=
    (mul_le_mul_of_nonneg_right (pow_le_pow_right hX (by decide : 5 ≤ 7)) (sq_nonneg _)).trans hprod
  rw [he,reverseResponse_append,product_eq,add_comm]
  apply add_le_add_left
  apply (le_div_iff (show 0 < X^2 by positivity)).2
  calc
    _ ≤ (4*(M*X)^2*X*N)*(prod z (table k))^2*X^2 :=
      mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hq (sq_nonneg _)) (sq_nonneg _)
    _ = (4*M^2*N)*(X^5*(prod z (table k))^2) := by ring
    _ ≤ (4*M^2*N)*C := mul_le_mul_of_nonneg_left hpx (by positivity)
    _ = _ := by change _ = (4*M^2*C)*N;ring

private theorem scale_increment (k : ℕ) (z : ℝ) (hz : 0 ≤ z) :
    (4:ℝ)^(k+2)/(scale (k+2) z)^2 ≤
      2*((4:ℝ)^(k+2)/scale (k+2) z - (4:ℝ)^k/scale k z) := by
  let P := (4:ℝ)^k
  let X := 1+z*(16*P)
  let Y := 1+z*P
  have hP : 0 < P := by dsimp [P]; positivity
  have hX : 0 < X := by dsimp [X]; positivity
  have hY : 0 < Y := by dsimp [Y]; positivity
  have hN : (4:ℝ)^(k+2) = 16*P := by dsimp [P];rw [pow_add];ring
  have hs : scale (k+2) z = X := by simp only [scale,hN,X]
  rw [hN,hs]
  change 16*P/X^2 ≤ 2*(16*P/X-P/Y)
  have heq : 2*(16*P/X-P/Y) = 30*P/(X*Y) := by
    field_simp [hX.ne',hY.ne']
    dsimp only [X,Y]
    ring
  rw [heq,div_le_div_iff (sq_pos_of_pos hX) (mul_pos hX hY)]
  have hXY : 16*Y ≤ 30*X := by dsimp [X,Y]; nlinarith only [mul_nonneg hz hP.le]
  nlinarith only [mul_le_mul_of_nonneg_left hXY (mul_pos hP hX).le]

/-- Suffix-weighted endpoint energy with a dimension-free constant. The rational
bound implies both O(n²) and O(1/z). Its proof telescopes across final guards. -/
theorem reverse_endpoint :
    ∃ A : ℝ, 0 < A ∧ ∀ k z, 0 ≤ z → z ≤ 1 →
      reverseResponse z (weight z) (table k) ≤ A*(4:ℝ)^k/scale k z := by
  obtain ⟨M,hM,hb⟩ := uniform_suffix
  obtain ⟨C,hC,hc⟩ := last_decay
  let A := max (100*M^2) (8*M^2*C)
  have hmp : 0 < M := by linarith
  have hA : 0 < A := lt_of_lt_of_le (by positivity : 0 < 100*M^2) (le_max_left _ _)
  refine ⟨A,hA,?_⟩
  intro k
  induction k using Nat.strong_induction_on with
  | h k ih =>
    intro z hz h₁
    by_cases hk : k < 2
    · have he : table k = table k ++ [] := by simp
      have hq := cap_bound k (table k) [] he z M hz hmp.le (hb k z hz h₁)
      have hX : scale k z ≤ 5 := by interval_cases k <;> norm_num [scale] <;> linarith
      have hsq := pow_le_pow_left (scale_pos _ _ hz).le hX 2
      apply (le_div_iff (scale_pos k z hz)).2
      calc
        _ ≤ (4*M^2 * scale k z * (4:ℝ)^k) * scale k z :=
          mul_le_mul_of_nonneg_right hq (scale_pos _ _ hz).le
        _ = (4*M^2*(4:ℝ)^k)*(scale k z)^2 := by ring
        _ ≤ (4*M^2*(4:ℝ)^k)*5^2 := mul_le_mul_of_nonneg_left hsq (by positivity)
        _ = 100*M^2*(4:ℝ)^k := by ring
        _ ≤ _ := mul_le_mul_of_nonneg_right (le_max_left _ _) (by positivity)
    · obtain ⟨j,rfl⟩ : ∃ j, k=j+2 := ⟨k-2,by omega⟩
      have hj := ih j (by omega) z hz h₁
      have he := increment M C hM hC hb hc j z hz h₁
      let X := scale (j+2) z
      let Y := scale j z
      let N := (4:ℝ)^(j+2)
      let P := (4:ℝ)^j
      change _ ≤ A*P/Y at hj
      change _ ≤ _ + (4*M^2*C)*N/X^2 at he
      have hdiff := scale_increment j z hz
      change N/X^2 ≤ 2*(N/X - P/Y) at hdiff
      have h0 : 0 ≤ N/X^2 := by dsimp [N,X]; positivity
      have hdiff0 : 0 ≤ N/X - P/Y := by linarith
      have hA' : 8*M^2*C ≤ A := le_max_right _ _
      have hpart : (4*M^2*C)*(N/X^2) ≤ A*(N/X - P/Y) := by
        calc
          _ ≤ (4*M^2*C)*(2*(N/X - P/Y)) := mul_le_mul_of_nonneg_left hdiff (by positivity)
          _ = (8*M^2*C)*(N/X - P/Y) := by ring
          _ ≤ _ := mul_le_mul_of_nonneg_right hA' hdiff0
      change _ ≤ A*N/X
      have h := he.trans (add_le_add_right hj _)
      calc
        _ ≤ A*P/Y + (4*M^2*C)*(N/X^2) := by simpa only [mul_div_assoc] using h
        _ ≤ A*P/Y + A*(N/X-P/Y) := add_le_add_left hpart _
        _ = _ := by ring


private theorem response_eq (z : ℝ) (w : List ℝ) :
    response z (weight z) w = weighted z (fun a => a*(1+z*a)) w := by
  induction w with
  | nil => rfl
  | cons a t ih => simp only [response,weighted,factor,weight,ih]

/-- Both endpoint responses are simultaneously capped at the table mass scale
and the reciprocal curvature, with one universal positive constant. -/
theorem both_endpoints : ∃ A : ℝ, 0 < A ∧ ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 →
    reverseResponse z (weight z) (table k) ≤ A*min (((2:ℝ)^k)^2) z⁻¹ ∧
    response z (weight z) (table k) ≤ A*min (((2:ℝ)^k)^2) z⁻¹ := by
  obtain ⟨B,hB,hr⟩ := reverse_endpoint
  let A := max B 4
  have hBA : B ≤ A := le_max_left _ _
  have h4 : 4 ≤ A := le_max_right _ _
  refine ⟨A,hB.trans_le hBA,?_⟩
  intro k z hz h₁
  let N := ((2:ℝ)^k)^2
  have hN : 0 ≤ N := sq_nonneg _
  have hpow : (4:ℝ)^k = N := by
    change (4:ℝ)^k = ((2:ℝ)^k)^2
    rw [pow_two, ←mul_pow]
    norm_num
  have hs : scale k z = 1+z*N := by simp only [scale,hpow]
  have hinv : 0 ≤ z⁻¹ := inv_nonneg.mpr hz.le
  have hden : 0 < 1+z*N := by positivity
  have hcap : N/(1+z*N) ≤ min N z⁻¹ := by
    apply le_min
    · apply (div_le_iff hden).2
      nlinarith only [mul_nonneg hz.le (sq_nonneg N)]
    · rw [inv_eq_one_div,div_le_div_iff hden hz]
      linarith only
  constructor
  · have h := hr k z hz.le h₁
    rw [hpow,hs,mul_div_assoc] at h
    exact (h.trans (mul_le_mul_of_nonneg_left hcap hB.le)).trans
      (mul_le_mul_of_nonneg_right hBA (le_min hN hinv))
  · by_cases h : N ≤ z⁻¹
    · change _ ≤ A*min N z⁻¹
      rw [min_eq_left h]
      have hzn : z*N ≤ 1 := by
        have hh := mul_le_mul_of_nonneg_left h hz.le
        simpa [hz.ne'] using hh
      have hsmall := response_small hz.le (table k) (by
        intro b hb
        have hlo := table_nonnegative k b hb
        have hc : b ≤ N := by
          cases k with
          | zero =>
            have h1 : b = 1 := by simpa [table_one] using hb
            simp [N,h1]
          | succ k =>
            have hh := table_step_upper k hb
            change b ≤ ((2:ℝ)^(k+1))^2
            nlinarith only [hh, sq_nonneg ((2:ℝ)^(k+1))]
        exact ⟨hlo, (mul_le_mul_of_nonneg_left hc hz.le).trans hzn⟩)
      have hm := table_mass k
      change (table k).sum ≤ 2*N at hm
      have h4N := mul_le_mul_of_nonneg_right h4 hN
      linarith only [hm, hsmall, h4N]
    · change _ ≤ A*min N z⁻¹
      rw [min_eq_right (le_of_not_ge h)]
      have he := endpoint_forward (table_stable k z hz.le h₁)
      rw [←response_eq] at he
      have hi : response z (weight z) (table k) ≤ 2/z :=
        (le_div_iff hz).2 (by simpa only [mul_comm z] using he)
      rw [div_eq_mul_inv] at hi
      exact hi.trans (mul_le_mul_of_nonneg_right (by linarith only [h4]) hinv)

theorem guard_degree_le (k j : ℕ) :
    guardSize (2^k) j ≤ Nat.gcd (2^k) (j+1) := by
  let q := Nat.gcd (2^k) (j+1)
  have hq : q ≤ 2^k := Nat.le_of_dvd (by positivity) (Nat.gcd_dvd_left _ _)
  have h := Nat.mul_le_mul_right q hq
  unfold guardSize
  apply Nat.div_le_of_le_mul
  change q^2 ≤ _ * _
  nlinarith

/-- Endpoint responses for each physical inserted guard, including empty
guards, use the same site weight as the raw coefficient. -/
theorem guard_endpoints : ∃ A : ℝ, 0 < A ∧ ∀ (k j : ℕ) (z : ℝ), 0 < z → z ≤ 1 →
    let q : ℝ := Nat.gcd (2^k) (j+1)
    let g := history k (guardSize (2^k) j)
    reverseResponse z (weight z) g ≤ A*min (q^2) z⁻¹ ∧
    response z (weight z) g ≤ A*min (q^2) z⁻¹ := by
  obtain ⟨A,hA,ht⟩ := both_endpoints
  refine ⟨A,hA,?_⟩
  intro k j z hz h₁
  dsimp only
  rcases guard_cases k j with ⟨he,_⟩ | ⟨e,_,hr,_,hguard⟩
  · rw [he, history_zero]
    simp only [reverseResponse,response]
    exact ⟨by positivity, by positivity⟩
  · rw [hguard]
    have hdeg := guard_degree_le k j
    rw [hr] at hdeg
    have hq : (2:ℝ)^e ≤ (Nat.gcd (2^k) (j+1) : ℝ) := by exact_mod_cast hdeg
    have hm := min_le_min_right z⁻¹ (pow_le_pow_left (by positivity) hq 2)
    have h := mul_le_mul_of_nonneg_left hm hA.le
    exact ⟨(ht e z hz h₁).1.trans h,(ht e z hz h₁).2.trans h⟩

private theorem mem_join {bs : List (List ℝ)} {i : ℕ} {a : ℝ}
    (h : a ∈ bs.getD i []) : a ∈ joinBlocks bs := by
  induction bs generalizing i with
  | nil => simp at h
  | cons b bs ih =>
    cases i with
    | zero => exact List.mem_append.mpr (Or.inl h)
    | succ i => exact List.mem_append.mpr (Or.inr (ih h))

/-- Every physical block is part of the nonnegative guarded table. -/
theorem block_nonnegative (k i : ℕ) :
    Nonnegative ((guardBlocks (history k) (2^k) 0 (raw k)).getD i []) := by
  intro a ha
  have hm := mem_join ha
  rw [join_guardBlocks, ←table_unfold] at hm
  exact table_nonnegative k a hm

end
end GDProof.Endpoint
