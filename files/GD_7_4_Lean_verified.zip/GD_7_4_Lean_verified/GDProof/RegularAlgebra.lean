import Mathlib

namespace GDProof.RegularAlgebra

/-- Turn a bound on a signed interval product and two endpoint-sum bounds
into the pointwise estimate for an ordered pair of distinct blocks. -/
theorem regular_pair {V U Ws We C b A B R G : ℝ}
    (hU : 0 ≤ U) (hWs : 0 ≤ Ws) (hWe : 0 ≤ We) (hC : 0 ≤ C)
    (hVb : V ≤ C*Ws*(2+|A|)^2) (hUb : U ≤ C*We*(2+|B|)^2)
    (hp : (2+|A|)*|R| *(2+|B|)*|G| ≤ 18*b) :
    V*((R*G)^2*U) ≤ (18*C)^2*b^2*Ws*We := by
  have hr := sq_nonneg (R*G)
  have hleft : 0 ≤ C*Ws*(2+|A|)^2 := by positivity
  have h := mul_le_mul hVb (mul_le_mul_of_nonneg_left hUb hr)
    (mul_nonneg hr hU) hleft
  have hs := pow_le_pow_left (show 0 ≤ (2+|A|)*|R| *(2+|B|)*|G| by positivity) hp 2
  calc
    _ ≤ _ := h
    _ = (C^2*Ws*We)*((2+|A|)*|R| *(2+|B|)*|G|)^2 := by
      simp only [mul_pow, sq_abs]
      ring
    _ ≤ (C^2*Ws*We)*(18*b)^2 := mul_le_mul_of_nonneg_left hs (by positivity)
    _ = _ := by ring

end GDProof.RegularAlgebra
