import GDProof.PairTotal
import GDProof.Accelerated

namespace GDProof.PairReduction
open PairTotal Kernel

def RegularEstimate (A : ℝ) : Prop :=
  ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 → ∀ i l : ℕ,
    i < 3*2^k → l < 3*2^k-(i+1) → i/3 ≠ (i+1+l)/3 →
    blockPair z (blocks k) i l ≤ (A*(1+4*(2:ℝ)^k*Real.sqrt z)^2)*
      weightAt k (Real.sqrt z) (i/3)*weightAt k (Real.sqrt z) ((i+1+l)/3)

def SameEstimate (B : ℝ) : Prop :=
  ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 → ∀ i l : ℕ,
    i < 3*2^k → l < 3*2^k-(i+1) → i/3 = (i+1+l)/3 →
    blockPair z (blocks k) i l ≤ B*q k (i/3)^4

theorem main_of_pair_estimates {A B : ℝ} (hA : 0 ≤ A) (hB : 0 ≤ B)
    (regular : RegularEstimate A) (same : SameEstimate B) : MainGuarantee := by
  let K := max A B
  have hAK : A ≤ K := le_max_left _ _
  have hBK : B ≤ K := le_max_right _ _
  have hK := hA.trans hAK
  apply Accelerated.main_of_table_kernel (C:=2*(8118*K)) (by positivity)
  intro k z hz hz'
  apply Kernel.table_D_of_across (c:=8118*K) (by positivity)
  intro n
  apply cross_bound n (Real.sqrt_pos.mpr hz) hK
  intro i l hi hl
  have nonnegW (j : ℕ) : 0 ≤ weightAt n (Real.sqrt z) j :=
    le_min (sq_nonneg _) (by positivity)
  have hF : 0 ≤ (1+4*(2:ℝ)^n*Real.sqrt z)^2 := sq_nonneg _
  by_cases he : i/3 = (i+1+l)/3
  · rw [if_pos he]
    have hb' := (same n z hz hz' i l hi hl he).trans
      (mul_le_mul_of_nonneg_right hBK (pow_nonneg (Nat.cast_nonneg _) 4))
    have hterm := mul_nonneg (mul_nonneg (mul_nonneg hK hF) (nonnegW (i/3)))
      (nonnegW ((i+1+l)/3))
    exact le_add_of_nonneg_of_le hterm hb'
  · rw [if_neg he, add_zero]
    apply (regular n z hz hz' i l hi hl he).trans
    exact mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right
      (mul_le_mul_of_nonneg_right hAK hF) (nonnegW (i/3))) (nonnegW ((i+1+l)/3))

end GDProof.PairReduction
