import GDProof.RadicalBounds

/-! Rational evaluation of the decrease, passage, and final-prefix charging
constants for the two small degrees in Appendix D.1. -/
namespace GDProof.DegreeCharges

open GDProof.Schedule GDProof.RadicalBounds
noncomputable section

def descent (m a h : ℝ) : ℝ := 19/40 - a^2/(8*m^4) - a*h/(4*m^4)

theorem degree_four {h : ℝ} (hh : h ≤ 2) :
    18091/40960 ≤ descent 4 (13/2) h ∧
    43/100 < descent 4 (13/2) h - (13/2)*h/(12*4^4) ∧
    5 < (1742/1000) * ((13/2)*descent 4 (13/2) h) := by
  unfold descent
  refine ⟨?_,?_,?_⟩ <;> norm_num <;> linarith

theorem degree_eight {h : ℝ} (hh : h ≤ 683/100) :
    365747/819200 ≤ descent 8 (49/2) h ∧
    43/100 < descent 8 (49/2) h - (49/2)*h/(12*8^4) ∧
    10 < (915/1000) * ((49/2)*descent 8 (49/2) h) := by
  unfold descent
  refine ⟨?_,?_,?_⟩ <;> norm_num <;> linarith

theorem actual_max_four (i : Fin 5) : four i ≤ 2 := by
  apply (four_enclosed i).2.trans
  fin_cases i <;> norm_num [coeff4, Matrix.cons_val_succ]

theorem actual_max_eight (i : Fin 10) : eight i ≤ 683/100 := by
  apply (eight_enclosed i).2.trans
  fin_cases i <;> norm_num [coeff8, Matrix.cons_val_succ]

/-- Lower estimate in units of ε²/L for a strict terminal prefix.
A unit step uses the ordinary GD descent estimate. -/
def terminalAmount (d : ℝ) (word : List ℝ) (t : ℕ) : ℝ :=
  if t = 1 then 1/2 else d * (word.take t).sum

theorem terminal_four (t : Fin 5) :
    (t.val : ℝ) ≤ (1742/1000)*terminalAmount (18091/40960) (cutAtHalf 2 4) t.val + 129/1000 := by
  rw [cut_four]
  obtain ⟨h2,_⟩ := a2_bounds
  fin_cases t <;> norm_num [terminalAmount, List.take] <;> linarith

theorem terminal_eight (t : Fin 10) :
    (t.val : ℝ) ≤ (915/1000)*terminalAmount (365747/819200) (cutAtHalf 3 9) t.val + 130/100 := by
  rw [cut_eight]
  obtain ⟨h2,_⟩ := a2_bounds
  obtain ⟨h4,_⟩ := a4_bounds
  obtain ⟨h6,_⟩ := a6_bounds
  have h3 := pair_add (2:ℝ)
  have h5 := pair_add (small 2)
  fin_cases t <;> norm_num [terminalAmount, List.take] <;> linarith

end
end GDProof.DegreeCharges
