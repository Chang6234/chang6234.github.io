import GDProof.Descent
import GDProof.Counting

namespace GDProof.Epoch

noncomputable section

/-- Dimensionless estimates at the end of a budget-capped epoch. D denotes
L times the actual decrease. A bounds the frozen-Hessian error coefficient. -/
structure Estimates (A E E₀ C D : ℝ) : Prop where
  smallBudget : E ≤ E₀
  bounds : ∃ α δ : ℝ, 0 ≤ α ∧ α ≤ A * Real.sqrt (E / E₀) ∧
    δ ≤ (3 / 4) * Real.sqrt (E / E₀) ∧
    |(E + C) / 2 - D| ≤ E * δ / 12 ∧
    -D ≤ E * (-1 + (1 + α) ^ 2 / 2 + δ / 2)

def threshold (A E₀ : ℝ) := E₀ / (32 * (1+A)) ^ 2

theorem threshold_pos {A E₀ : ℝ} (hA : 0 ≤ A) (hE : 0 < E₀) :
    0 < threshold A E₀ := by unfold threshold; positivity

theorem threshold_le {A E₀ : ℝ} (hA : 0 ≤ A) (hE : 0 ≤ E₀) :
    threshold A E₀ ≤ E₀ := by
  have hsq : 1 ≤ (32 * (1+A))^2 := by nlinarith [sq_nonneg (32*(1+A)-1)]
  calc
    threshold A E₀ ≤ E₀ / 1 := by
      unfold threshold
      exact div_le_div_of_nonneg_left hE (by norm_num) hsq
    _ = E₀ := div_one _

/-- The three conclusions needed by the counting argument, uniformly in the
budget and the dimension. Only the two analytic estimates enter here. -/
theorem budget_case {A E E₀ C D : ℝ} (hA : 0 ≤ A) (hE : 0 ≤ E)
    (hE₀ : 0 < E₀) (est : Estimates A E E₀ C D) :
    (-(E/2) ≤ C → 3 * E / 16 ≤ D) ∧
    -D ≤ (1 + A)^2 * E ∧
    (E ≤ threshold A E₀ → -(E/2) ≤ C) := by
  obtain ⟨α, δ, hα₀, hα, hδ, herr, hmodel⟩ := est.bounds
  have hrat : 0 ≤ E / E₀ := div_nonneg hE hE₀.le
  have hsquare := Real.sq_sqrt hrat
  have hratio : E / E₀ ≤ 1 := by
    exact (div_le_iff hE₀).2 (by simpa using est.smallBudget)
  have hr := Real.sqrt_le_one.mpr hratio
  have hδ' : δ ≤ 3/4 := by linarith only [hδ, hr]
  have he := Descent.uniform_epoch_error hE hδ' herr
  have hα' : α ≤ A := hα.trans (by simpa using mul_le_mul_of_nonneg_left hr hA)
  have hs : (1 + α)^2 ≤ (1 + A)^2 := by
    exact pow_le_pow_left (by linarith only [hα₀]) (add_le_add_left hα' 1) 2
  have hg : -1 + (1+α)^2/2 + δ/2 ≤ (1+A)^2 := by nlinarith only [hs, hδ', sq_nonneg (1+A)]
  refine ⟨fun hp => Descent.passing_epoch_drop hp he, ?_, ?_⟩
  · calc
      -D ≤ _ := hmodel
      _ ≤ E * (1 + A)^2 := mul_le_mul_of_nonneg_left hg hE
      _ = _ := by ring
  · intro hsmall
    let B := 32 * (1+A)
    let r := Real.sqrt (E/E₀)
    have hB : 0 < B := by dsimp [B]; positivity
    have hr₀ : 0 ≤ r := Real.sqrt_nonneg _
    have hsmall' : E * B^2 ≤ E₀ := by
      change E ≤ E₀ / B^2 at hsmall
      exact (le_div_iff (sq_pos_of_pos hB)).1 hsmall
    have hsq' : (r * B)^2 ≤ 1 := by
      calc
        (r * B)^2 = E * B^2 / E₀ := by
          rw [mul_pow]
          dsimp [r]
          rw [hsquare]
          ring
        _ ≤ 1 := by
          exact (div_le_iff hE₀).2 (by simpa using hsmall')
    have hprod : r * B ≤ 1 := by nlinarith only [hsq', sq_nonneg (r*B-1)]
    change r * (32 * (1 + A)) ≤ 1 at hprod
    change α ≤ A * r at hα
    change δ ≤ 3/4 * r at hδ
    have hsmallα : α ≤ 1/32 := by nlinarith only [hα, hprod, hr₀]
    have hsmallδ : δ ≤ 1/32 := by nlinarith only [hδ, hprod, hr₀, mul_nonneg hr₀ hA]
    exact Descent.sufficient_drop_passes hE
      (Descent.small_radius_decrease hE hα₀ hsmallα hsmallδ hmodel) he

end
end GDProof.Epoch
