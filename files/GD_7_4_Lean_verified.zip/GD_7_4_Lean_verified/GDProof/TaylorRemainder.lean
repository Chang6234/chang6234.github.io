import GDProof.FiveRows

/-! Taylor approximation of sine and cosine with an explicit uniform bound
on the derivative in the Lagrange remainder. -/
namespace GDProof.TaylorRemainder

open scoped BigOperators
open Set

private theorem phase_derivative {s : Set ℝ} (hs : UniqueDiffOn ℝ s) (a : ℝ)
    (n : ℕ) {y : ℝ} (hy : y ∈ s) :
    iteratedDerivWithin n (fun t => Real.sin (t+a)) s y =
      Real.sin (y+a+(n:ℝ)*Real.pi/2) := by
  induction n generalizing y with
  | zero => simp
  | succ n ih =>
    rw [iteratedDerivWithin_succ (hs y hy),
      derivWithin_congr (fun t ht => ih ht) (ih hy)]
    have hd : HasDerivAt (fun t : ℝ => Real.sin (t+a+(n:ℝ)*Real.pi/2))
        (Real.cos (y+a+(n:ℝ)*Real.pi/2)) y := by
      simpa using (((hasDerivAt_id y).add_const a).add_const ((n:ℝ)*Real.pi/2)).sin
    rw [hd.hasDerivWithinAt.derivWithin (hs y hy), ← Real.sin_add_pi_div_two]
    congr 1
    push_cast
    ring

private theorem sum_pairs (f : ℕ → ℝ) (n : ℕ) :
    ∑ i in Finset.range (2*n), f i =
      ∑ k in Finset.range n, (f (2*k)+f (2*k+1)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show 2*(n+1)=2*n+1+1 by omega, Finset.sum_range_succ, Finset.sum_range_succ,
      ih, Finset.sum_range_succ]
    ring

private theorem phase_polynomial {x : ℝ} (hx : 0 < x) (a : ℝ) :
    taylorWithinEval (fun t => Real.sin (t+a)) 41 (Icc 0 x) 0 x =
    ∑ k in Finset.range 21, ((-1:ℝ)^k*x^(2*k)/(Nat.factorial (2*k) : ℝ)*Real.sin a +
      (-1:ℝ)^k*x^(2*k+1)/(Nat.factorial (2*k+1):ℝ)*Real.cos a) := by
  rw [taylor_within_apply]
  simp only [sub_zero, smul_eq_mul, phase_derivative (uniqueDiffOn_Icc hx) a _
    (left_mem_Icc.mpr hx.le), zero_add]
  change (∑ i in Finset.range (2*21),
    ((Nat.factorial i:ℝ)⁻¹*x^i)*Real.sin (a+(i:ℝ)*Real.pi/2)) = _
  rw [sum_pairs]
  apply Finset.sum_congr rfl
  intro k _
  push_cast
  rw [show a+2*(k:ℝ)*Real.pi/2=a+k*Real.pi by ring,
    show a+(2*(k:ℝ)+1)*Real.pi/2=(a+Real.pi/2)+k*Real.pi by ring,
    Real.sin_add_nat_mul_pi, Real.sin_add_nat_mul_pi, Real.sin_add_pi_div_two]
  ring

private theorem phase_remainder {x : ℝ} (hx : 0 < x) (a : ℝ) :
    |Real.sin (x+a) - taylorWithinEval (fun t => Real.sin (t+a)) 41 (Icc 0 x) 0 x|
      ≤ x^42/(Nat.factorial 42 : ℝ) := by
  let f := fun t : ℝ => Real.sin (t+a)
  have hcont : ContDiff ℝ ⊤ f := Real.contDiff_sin.comp (contDiff_id.add contDiff_const)
  have hc : ContDiffOn ℝ 41 f (Icc 0 x) := (hcont.of_le le_top).contDiffOn
  have hc' : ContDiffOn ℝ ⊤ f (Icc 0 x) := hcont.contDiffOn
  have hd := hc'.differentiableOn_iteratedDerivWithin (show ((41:ℕ):ℕ∞) < ⊤ from WithTop.coe_lt_top _)
    (uniqueDiffOn_Icc hx)
  obtain ⟨y,hy,heq⟩ := taylor_mean_remainder_lagrange (n:=41) hx hc (hd.mono Ioo_subset_Icc_self)
  change |f x - _| ≤ _
  rw [heq, sub_zero, phase_derivative (uniqueDiffOn_Icc hx) a _ (Ioo_subset_Icc_self hy),
    abs_div, abs_mul, abs_of_nonneg (pow_nonneg hx.le _), abs_of_nonneg (by positivity : (0:ℝ) ≤ (42:ℕ).factorial)]
  apply div_le_div_of_nonneg_right _ (by positivity)
  exact mul_le_of_le_one_left (pow_nonneg hx.le _) (abs_le.mpr ⟨Real.neg_one_le_sin _,Real.sin_le_one _⟩)

/-- The printed degree-41 sine polynomial. -/
theorem sin_remainder {x : ℝ} (hx : 0 < x) :
    |Real.sin x - ∑ k in Finset.range 21, (-1:ℝ)^k*x^(2*k+1)/(Nat.factorial (2*k+1):ℝ)|
      ≤ x^42/(Nat.factorial 42:ℝ) := by
  have h := phase_remainder hx 0
  rw [phase_polynomial hx] at h
  simpa only [add_zero, Real.sin_zero, Real.cos_zero, mul_zero, mul_one, zero_add] using h

/-- The printed cosine polynomial, with zero coefficient on every odd power. -/
theorem cos_remainder {x : ℝ} (hx : 0 < x) :
    |Real.cos x - ∑ k in Finset.range 21, (-1:ℝ)^k*x^(2*k)/(Nat.factorial (2*k):ℝ)|
      ≤ x^42/(Nat.factorial 42:ℝ) := by
  have h := phase_remainder hx (Real.pi/2)
  rw [phase_polynomial hx] at h
  simpa only [Real.sin_pi_div_two, Real.cos_pi_div_two, Real.sin_add_pi_div_two, mul_one, mul_zero, add_zero] using h

private theorem range_list_sum (n : ℕ) (f : ℕ → ℚ) :
    ((List.range n).map f).sum = ∑ k in Finset.range n, f k := by
  induction n with
  | zero => simp
  | succ n ih => rw [List.sum_range_succ, Finset.sum_range_succ, ih]

/-- The real remainder for the exact rational polynomial used to produce the five rows. -/
theorem rational_remainder (x : ℚ) (hx : 0 < x) (odd : Bool) :
    |(if odd then Real.sin (x:ℝ) else Real.cos (x:ℝ)) - (FiveRows.taylor x odd : ℝ)| ≤
      ((x^42/(Nat.factorial 42:ℚ):ℚ):ℝ) := by
  have hx' : 0 < (x:ℝ) := by exact_mod_cast hx
  unfold FiveRows.taylor
  rw [range_list_sum, Rat.cast_sum]
  cases odd
  · simpa only [Bool.false_eq_true, if_false, add_zero, Rat.cast_pow, Rat.cast_mul,
      Rat.cast_neg, Rat.cast_one, Rat.cast_div, Rat.cast_natCast] using cos_remainder hx'
  · simpa only [if_true, Rat.cast_pow, Rat.cast_mul, Rat.cast_neg, Rat.cast_one, Rat.cast_div,
      Rat.cast_natCast] using sin_remainder hx'

/-- Outward rounding preserves the analytic enclosure at every positive rational argument. -/
theorem trigInterval_contains (x : ℚ) (hx : 0 < x) (odd : Bool) :
    FiveRows.Contains (FiveRows.trigInterval x odd)
      (if odd then Real.sin (x:ℝ) else Real.cos (x:ℝ)) := by
  let y := FiveRows.taylor x odd
  let e := x^42/(Nat.factorial 42:ℚ)
  let sc : ℚ := 1000000000000
  let v := if odd then Real.sin (x:ℝ) else Real.cos (x:ℝ)
  have hsc : 0 < sc := by norm_num [sc]
  have hlq : (⌊sc*(y-e)⌋:ℚ)/sc ≤ y-e := by
    apply (div_le_iff hsc).mpr
    simpa only [mul_comm] using Int.floor_le (sc*(y-e))
  have huq : y+e ≤ (⌈sc*(y+e)⌉:ℚ)/sc := by
    apply (le_div_iff hsc).mpr
    simpa only [mul_comm] using Int.le_ceil (sc*(y+e))
  have hl : (((⌊sc*(y-e)⌋:ℚ)/sc:ℚ):ℝ) ≤ (y:ℝ)-(e:ℝ) := by exact_mod_cast hlq
  have hu : (y:ℝ)+(e:ℝ) ≤ (((⌈sc*(y+e)⌉:ℚ)/sc:ℚ):ℝ) := by exact_mod_cast huq
  have hr : |v-(y:ℝ)| ≤ (e:ℝ) := rational_remainder x hx odd
  obtain ⟨hl',hu'⟩ := abs_le.mp hr
  change (((⌊sc*(y-e)⌋:ℚ)/sc:ℚ):ℝ) ≤ v ∧ v ≤ (((⌈sc*(y+e)⌉:ℚ)/sc:ℚ):ℝ)
  exact ⟨hl.trans (by linarith only [hl']), (by linarith only [hu'] : v ≤ (y:ℝ)+(e:ℝ)).trans hu⟩

/-- The actual value and the displayed logarithmic derivative expression at one row. -/
def RowBounds (t cap : ℚ) (paired : Bool) : Prop :=
  (FiveRows.realRow t paired).1 < (cap:ℝ) ∧ |(FiveRows.realRow t paired).2| < 1/1000

/-- All five pointwise inequalities, including both paired-product rows of the paper. -/
theorem all_five_point_bounds :
    RowBounds (4132/1000) (227/100) false ∧
    RowBounds (9358/1000) (412/100) false ∧
    RowBounds (15017/1000) (225/100) false ∧
    RowBounds (10206/1000) (439/100) true ∧
    RowBounds (15144/1000) (491/100) true := by
  exact ⟨FiveRows.real_bound_of_row trigInterval_contains _ _ _ FiveRows.row_one,
    FiveRows.real_bound_of_row trigInterval_contains _ _ _ FiveRows.row_two,
    FiveRows.real_bound_of_row trigInterval_contains _ _ _ FiveRows.row_three,
    FiveRows.real_bound_of_row trigInterval_contains _ _ _ FiveRows.row_four,
    FiveRows.real_bound_of_row trigInterval_contains _ _ _ FiveRows.row_five⟩

end GDProof.TaylorRemainder
