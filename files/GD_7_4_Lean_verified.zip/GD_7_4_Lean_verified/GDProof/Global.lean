import GDProof.Reduction
import GDProof.Unit
import GDProof.Scale

namespace GDProof.Global

noncomputable section

def countConst (c g : ℝ) : ℝ := 5 + 128/(3*c) * (3+2*(g+1))

private theorem scalar_count {calls J m G ε E c g : ℝ}
    (hm : 0 < m) (hc : 0 < c) (hE : 0 < E) (hε : 0 < ε)
    (hg : 0 ≤ g) (hG : 0 ≤ G) (hJ : J ≤ 4*m) (hmass : ε^2*m^2 ≤ 3*E)
    (h : calls ≤ 1+J*(1+(G+2*(g+1)*E)/(3*c*E/32))) :
    calls ≤ countConst c g * (1+m+G/(ε^2*m)) := by
  let x := G/(ε^2*m)
  let a := 128/(3*c)
  have hx : 0 ≤ x := by dsimp [x]; positivity
  have ha : 0 ≤ a := by dsimp [a]; positivity
  have h0 : 0 ≤ 1+(G+2*(g+1)*E)/(3*c*E/32) := by positivity
  have h1 := h.trans (add_le_add_left (mul_le_mul_of_nonneg_right hJ h0) 1)
  have hmG : m*G/E ≤ 3*x := by
    apply (div_le_iff hE).mpr
    have hg' := mul_le_mul_of_nonneg_left hmass hx
    have heq : x*(ε^2*m^2) = m*G := by
      dsimp [x]
      field_simp [hε.ne', hm.ne'] <;> ring
    rw [heq] at hg'
    linarith only [hg']
  have hid : 1+4*m*(1+(G+2*(g+1)*E)/(3*c*E/32)) =
      1+4*m+a*(m*G/E+2*(g+1)*m) := by
    dsimp [a]
    field_simp [hc.ne', hE.ne'] <;> ring
  rw [hid] at h1
  have hto := mul_le_mul_of_nonneg_left (add_le_add_right hmG (2*(g+1)*m)) ha
  have hb : calls ≤ 1+4*m+a*(3*x+2*(g+1)*m) := by linarith only [hto, h1]
  let B := 1+m+x
  have b1 : 1 ≤ B := by dsimp [B]; linarith only [hm, hx]
  have bm : m ≤ B := by dsimp [B]; linarith only [hx]
  have bx : x ≤ B := by dsimp [B]; linarith only [hm]
  have hg' : 0 ≤ 2*(g+1) := by linarith only [hg]
  have hsum := add_le_add (mul_le_mul_of_nonneg_left bx (by norm_num : (0:ℝ) ≤ 3))
    (mul_le_mul_of_nonneg_left bm hg')
  have hscaled := mul_le_mul_of_nonneg_left hsum ha
  change calls ≤ (5+a*(3+2*(g+1)))*B
  nlinarith only [hb, hscaled, b1, bm]

/-- The only global input is an actual non-unit single-epoch guarantee for the
concrete table, with common constants. The unit branch is proved separately. -/
theorem main_of_local_epochs (c g : ℝ) (hc : 0 < c) (hc' : c ≤ 1) (hg : 0 ≤ g)
    (epochs : ∀ (d : ℕ) (P : Problem d) (ε : ℝ), 0 < ε →
      Degree.exponent (max 1 (degreeScale P.L P.ρ ε)) ≠ 0 →
      Reduction.LocalEpoch P ε (chosenTable P.L P.ρ ε) c g) : MainGuarantee := by
  have hK : 5 ≤ countConst c g := by
    unfold countConst
    have hn : 0 ≤ 128/(3*c) * (3+2*(g+1)) := by positivity
    linarith
  refine ⟨2*countConst c g, by linarith, ?_⟩
  intro d P ε hε x₀
  let n := Degree.exponent (max 1 (degreeScale P.L P.ρ ε))
  let m := (2:ℝ)^n
  let T := Schedule.table n
  let Δ := P.f x₀ - sInf (Set.range P.f)
  have hd : 0 ≤ Δ := sub_nonneg.mpr (csInf_le P.bounded ⟨x₀,rfl⟩)
  have hL := P.L_pos
  have hρ := P.ρ_pos
  have hm : 0 < m := by dsimp [m]; positivity
  have ht : 0 ≤ Scale.target P.L P.ρ ε := by unfold Scale.target; positivity
  have hw : 0 ≤ Scale.weightedGap P.L P.ρ ε Δ := by unfold Scale.weightedGap; positivity
  change ∃ (k : ℕ) (s : Model.State (Space d)),
    Model.run P.grad P.L ε T (Model.initial P.grad x₀ T ε) k = some s ∧
    ‖P.grad s.x‖ ≤ ε ∧ ((k+1:ℕ):ℝ) ≤ 2*countConst c g *
      (1 + Scale.target P.L P.ρ ε + Scale.weightedGap P.L P.ρ ε Δ)
  by_cases hn : n = 0
  · have hT : T = [1] := by dsimp [T]; rw [hn]; exact Schedule.table_one
    have hdg : Scale.degree P.L P.ρ ε = 1 := by change (2:ℝ)^n = 1; rw [hn,pow_zero]
    obtain ⟨k,s,hr,hs,hcalls⟩ := unit_table_bound P ε hε x₀
    refine ⟨k,s, by simpa only [hT] using hr, hs, ?_⟩
    have hu := Scale.unit_rate hL hρ hε hd hdg
    change ((k+1 : ℕ):ℝ) ≤ 2 + 2*P.L*Δ/ε^2 at hcalls
    have hB : 0 ≤ 1+Scale.target P.L P.ρ ε+Scale.weightedGap P.L P.ρ ε Δ := by linarith
    have hmK := mul_le_mul_of_nonneg_right hK hB
    let W := Scale.weightedGap P.L P.ρ ε Δ
    let B := 1 + Scale.target P.L P.ρ ε + W
    change P.L * Δ / ε ^ 2 ≤ 2 * W at hu
    calc
      ((k+1:ℕ):ℝ) ≤ 2 + 2 * P.L * Δ / ε^2 := hcalls
      _ = 2 + 2*(P.L*Δ/ε^2) := by ring
      _ ≤ 2 + 2*(2*W) := by linarith only [hu]
      _ ≤ 2*(5*B) := by
        dsimp only [B]
        change 0 ≤ W at hw
        linarith only [hw, ht]
      _ ≤ 2*(countConst c g*B) := mul_le_mul_of_nonneg_left hmK (by norm_num)
      _ = _ := by ring
  · have hJ : (T.length:ℝ) ≤ 4*m := by
      dsimp only [T,m]
      exact_mod_cast GuardSizes.table_length n
    have hmass := Schedule.table_sum_lower n
    change (2*m^2+1)/3 ≤ T.sum at hmass
    have hTpos : 0 < T.sum := by nlinarith only [hmass,sq_nonneg m]
    have hE : 0 < ε^2/2*T.sum := by positivity
    have hq := mul_le_mul_of_nonneg_left hmass (sq_nonneg ε)
    have hmass' : ε^2*m^2 ≤ 3*(ε^2/2*T.sum) := by nlinarith only [hq, sq_nonneg ε]
    obtain ⟨k,s,hr,hs,hh⟩ := Reduction.calls_from_epochs P ε x₀ T c g hc hc' hg hE (epochs d P ε hε hn)
    refine ⟨k,s,hr,hs,?_⟩
    have hi := scalar_count hm hc hE hε hg (mul_nonneg hL.le hd) hJ hmass' hh
    exact hi.trans (by
      have hz := mul_le_mul_of_nonneg_left (Scale.selected_rate hL hρ hε hd) (by linarith : 0 ≤ countConst c g)
      change countConst c g * (1+m+P.L*Δ/(ε^2*m)) ≤ _
      rw [mul_left_comm (countConst c g) 2] at hz
      simpa only [mul_assoc] using hz)

end
end GDProof.Global
