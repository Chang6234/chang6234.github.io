import GDProof.Statement
import GDProof.Geometry

/-! True gradient and objective errors incurred by freezing the Hessian at z. -/
namespace GDProof.Frozen

open scoped RealInnerProductSpace BigOperators

private theorem gradient_along {d : ℕ} (P : GDProof.Problem d) (z x s : GDProof.Space d)
    {R : ℝ} (hrad : ∀ t ∈ Set.Icc (0 : ℝ) 1, ‖x + t • s - z‖ ≤ R)
    (t : ℝ) (ht : t ∈ Set.Icc (0 : ℝ) 1) :
    ‖P.grad (x + t • s) - P.grad x - t • (P.hess z s)‖ ≤ P.ρ * R * ‖s‖ * t := by
  let line : ℝ → GDProof.Space d := fun u => x + u • s
  let rem : ℝ → GDProof.Space d := fun u => P.grad (line u) - u • (P.hess z s)
  have hl (u : ℝ) : HasDerivAt line s u := by
    simpa [line] using ((hasDerivAt_const u x).add ((hasDerivAt_id u).smul_const s))
  have hd (u : ℝ) : HasDerivAt rem ((P.hess (line u) - P.hess z) s) u := by
    simpa [rem, Function.comp_def] using
      (((P.hessianAt (line u)).comp_hasDerivAt u (hl u)).sub ((hasDerivAt_id u).smul_const (P.hess z s)))
  have bound (u : ℝ) (hu : u ∈ Set.Ico (0 : ℝ) 1) :
      ‖(P.hess (line u) - P.hess z) s‖ ≤ P.ρ * R * ‖s‖ := by
    apply ((P.hess (line u)-P.hess z).le_opNorm s).trans
    exact mul_le_mul_of_nonneg_right ((P.lipHess (line u) z).trans
      (mul_le_mul_of_nonneg_left (hrad u ⟨hu.1, hu.2.le⟩) P.ρ_pos.le)) (norm_nonneg s)
  have he := norm_image_sub_le_of_norm_deriv_le_segment'
    (fun u _ => (hd u).hasDerivWithinAt) bound t ht
  simpa [rem, line, sub_right_comm] using he

/-- The Hessian-Lipschitz assumption bounds the actual one-step gradient defect. -/
theorem gradient_remainder {d : ℕ} (P : GDProof.Problem d) (z x s : GDProof.Space d)
    {R : ℝ} (hrad : ∀ t ∈ Set.Icc (0 : ℝ) 1, ‖x + t • s - z‖ ≤ R) :
    ‖P.grad (x+s) - P.grad x - P.hess z s‖ ≤ P.ρ * R * ‖s‖ := by
  simpa using gradient_along P z x s hrad 1 ⟨by norm_num, le_rfl⟩

/-- Taylor upper bound with the epoch's fixed Hessian, from the true derivatives. -/
theorem objective_upper {d : ℕ} (P : GDProof.Problem d) (z x s : GDProof.Space d)
    {R : ℝ} (hrad : ∀ t ∈ Set.Icc (0 : ℝ) 1, ‖x + t • s - z‖ ≤ R) :
    P.f (x+s) - P.f x ≤ ⟪P.grad x, s⟫_ℝ +
      (⟪P.hess z s, s⟫_ℝ + P.ρ * R * ‖s‖^2)/2 := by
  let line : ℝ → GDProof.Space d := fun t => x + t • s
  let a := ⟪P.grad x, s⟫_ℝ
  let b := ⟪P.hess z s, s⟫_ℝ + P.ρ * R * ‖s‖^2
  let F : ℝ → ℝ := fun t => P.f (line t) - (t*a + t^2*(b/2))
  have hl (t : ℝ) : HasDerivAt line s t := by
    simpa [line] using ((hasDerivAt_const t x).add ((hasDerivAt_id t).smul_const s))
  have hg (t : ℝ) : HasDerivAt (fun u => P.f (line u)) ⟪P.grad (line t), s⟫_ℝ t :=
    (P.gradientAt (line t)).hasFDerivAt.comp_hasDerivAt t (hl t)
  have hd (t : ℝ) : HasDerivAt F (⟪P.grad (line t), s⟫_ℝ - a - t*b) t := by
    convert (hg t).sub (((hasDerivAt_id t).mul_const a).add (((hasDerivAt_id t).pow 2).mul_const (b/2))) using 1
    simp only [id_eq]
    ring
  have hm : AntitoneOn F (Set.Icc (0 : ℝ) 1) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc 0 1)
      (fun t _ => (hd t).continuousAt.continuousWithinAt)
      (fun t _ => (hd t).differentiableAt.differentiableWithinAt)
    intro t ht
    have hv := gradient_along P z x s hrad t (interior_subset ht)
    have hi := real_inner_le_norm (P.grad (line t) - P.grad x - t • (P.hess z s)) s
    rw [inner_sub_left, inner_sub_left, real_inner_smul_left] at hi
    rw [(hd t).deriv]
    dsimp only [a, b]
    change ‖P.grad (line t) - P.grad x - t • (P.hess z s)‖ ≤ _ at hv
    nlinarith only [hi, mul_le_mul_of_nonneg_right hv (norm_nonneg s)]
  have he := hm (show (0 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num)
    (show (1 : ℝ) ∈ Set.Icc 0 1 by constructor <;> norm_num) (by norm_num)
  simp only [F, line, a, b, one_smul, zero_smul, add_zero, one_mul, zero_mul, one_pow,
    zero_pow (by decide : 2 ≠ 0), zero_add, sub_zero] at he
  linarith only [he]

/-- Every point of each edge lies in the ball around the initial iterate
whose radius is the total path length. -/
theorem segment_radius {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (x : ℕ → V) (n : ℕ) {R : ℝ} (hlen : (∑ j in Finset.range n, ‖x (j+1)-x j‖) ≤ R)
    {i : ℕ} (hi : i < n) {t : ℝ} (ht : t ∈ Set.Icc (0 : ℝ) 1) :
    ‖x i + t • (x (i+1)-x i) - x 0‖ ≤ R := by
  have hinit : ‖x i - x 0‖ ≤ ∑ j in Finset.range i, ‖x (j+1)-x j‖ := by
    simpa only [dist_eq_norm'] using dist_le_range_sum_dist x i
  calc
    _ = ‖(x i - x 0) + t • (x (i+1)-x i)‖ := by congr 1; abel
    _ ≤ ‖x i - x 0‖ + ‖t • (x (i+1)-x i)‖ := norm_add_le _ _
    _ ≤ (∑ j in Finset.range i, ‖x (j+1)-x j‖) + ‖x (i+1)-x i‖ := by
      rw [norm_smul_of_nonneg ht.1]
      exact add_le_add hinit (by simpa using mul_le_mul_of_nonneg_right ht.2 (norm_nonneg _))
    _ = ∑ j in Finset.range (i+1), ‖x (j+1)-x j‖ := (Finset.sum_range_succ _ i).symm
    _ ≤ ∑ j in Finset.range n, ‖x (j+1)-x j‖ :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.range_mono hi) (fun _ _ _ => norm_nonneg _)
    _ ≤ R := hlen

/-- Summed Taylor bound for a genuine finite GD trajectory, with h its
realized coefficients (including any clipping). -/
theorem gd_prefix_upper {d : ℕ} (P : GDProof.Problem d) (x : ℕ → GDProof.Space d)
    (h : ℕ → ℝ) (n : ℕ) {A E : ℝ} (hh : ∀ i < n, 0 ≤ h i)
    (hgd : ∀ i < n, x (i+1) = x i - (h i/P.L) • P.grad (x i))
    (hmass : (∑ i in Finset.range n, h i) ≤ A)
    (henergy : (∑ i in Finset.range n, h i * ‖P.grad (x i)‖^2) ≤ E) :
    let R := Real.sqrt (A*E)/P.L
    let s := fun i => x (i+1)-x i
    P.f (x n)-P.f (x 0) ≤ -(∑ i in Finset.range n, h i * ‖P.grad (x i)‖^2)/P.L +
      (∑ i in Finset.range n, (⟪P.hess (x 0) (s i), s i⟫_ℝ + P.ρ * R * ‖s i‖^2))/2 := by
  intro R s
  have hpath := Geometry.path_length x (fun i => P.grad (x i)) h n P.L_pos hh hgd hmass henergy
  have hedge (i : ℕ) (hi : i ∈ Finset.range n) :
      P.f (x (i+1)) - P.f (x i) ≤ -(h i * ‖P.grad (x i)‖^2)/P.L +
        (⟪P.hess (x 0) (s i), s i⟫_ℝ + P.ρ*R*‖s i‖^2)/2 := by
    have hu := objective_upper P (x 0) (x i) (s i)
      (fun _ ht => segment_radius x n hpath (Finset.mem_range.mp hi) ht)
    have hx : x i + s i = x (i+1) := by dsimp only [s]; abel
    have hdisp : s i = -((h i/P.L) • P.grad (x i)) := by
      dsimp only [s]
      rw [hgd i (Finset.mem_range.mp hi)]
      abel
    have hinner : ⟪P.grad (x i), s i⟫_ℝ = -(h i * ‖P.grad (x i)‖^2)/P.L := by
      rw [hdisp, inner_neg_right, real_inner_smul_right, real_inner_self_eq_norm_sq]
      ring
    rwa [hx, hinner] at hu
  have htotal := Finset.sum_le_sum hedge
  rw [Finset.sum_range_sub (fun j => P.f (x j)) n, Finset.sum_add_distrib, ← Finset.sum_div, ← Finset.sum_div,
    Finset.sum_neg_distrib] at htotal
  exact htotal

end GDProof.Frozen
