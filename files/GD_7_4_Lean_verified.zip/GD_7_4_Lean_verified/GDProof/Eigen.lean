import GDProof.Statement

/-! Spectral coordinates for the true Hessian divided by L. -/
namespace GDProof.Eigen

open scoped RealInnerProductSpace
noncomputable section

def normalized {d : ℕ} (P : Problem d) (x : Space d) : Space d →L[ℝ] Space d :=
  P.L⁻¹ • P.hess x

theorem hessian_symmetric {d : ℕ} (P : Problem d) (x : Space d) :
    (P.hess x).toLinearMap.IsSymmetric := by
  let J : Space d →L[ℝ] (Space d →L[ℝ] ℝ) := innerSL ℝ
  have hf (y : Space d) : HasFDerivAt P.f (J (P.grad y)) y := (P.gradientAt y).hasFDerivAt
  have hJ : HasFDerivAt (fun y => J (P.grad y)) (J.comp (P.hess x)) x :=
    J.hasFDerivAt.comp x (P.hessianAt x)
  intro v w
  calc
    ⟪P.hess x v, w⟫_ℝ = ⟪P.hess x w, v⟫_ℝ := second_derivative_symmetric hf hJ v w
    _ = _ := real_inner_comm _ _

theorem symmetric {d : ℕ} (P : Problem d) (x : Space d) :
    (normalized P x).toLinearMap.IsSymmetric := by
  intro v w
  change ⟪P.L⁻¹ • P.hess x v, w⟫_ℝ = ⟪v, P.L⁻¹ • P.hess x w⟫_ℝ
  rw [real_inner_smul_left, real_inner_smul_right]
  exact congrArg (fun a : ℝ => P.L⁻¹ * a) (hessian_symmetric P x v w)

theorem norm_le_one {d : ℕ} (P : Problem d) (x : Space d) : ‖normalized P x‖ ≤ 1 := by
  have h := (P.hessianAt x).le_of_lip' P.L_pos.le (Filter.eventually_of_forall (fun y => P.lipGrad y x))
  apply ContinuousLinearMap.opNorm_le_bound _ zero_le_one
  intro y
  change ‖P.L⁻¹ • P.hess x y‖ ≤ 1 * ‖y‖
  rw [norm_smul_of_nonneg (inv_nonneg.mpr P.L_pos.le)]
  calc
    _ ≤ P.L⁻¹ * (P.L * ‖y‖) := mul_le_mul_of_nonneg_left
      (((P.hess x).le_opNorm y).trans (mul_le_mul_of_nonneg_right h (norm_nonneg y)))
      (inv_nonneg.mpr P.L_pos.le)
    _ = _ := by rw [← mul_assoc, inv_mul_cancel P.L_pos.ne']

def basis {d : ℕ} (P : Problem d) (x : Space d) : OrthonormalBasis (Fin d) ℝ (Space d) :=
  (symmetric P x).eigenvectorBasis (finrank_euclideanSpace_fin (𝕜 := ℝ))

def value {d : ℕ} (P : Problem d) (x : Space d) (i : Fin d) : ℝ :=
  (symmetric P x).eigenvalues (finrank_euclideanSpace_fin (𝕜 := ℝ)) i

theorem diagonal {d : ℕ} (P : Problem d) (x v : Space d) (i : Fin d) :
    (basis P x).repr (normalized P x v) i = value P x i * (basis P x).repr v i :=
  (symmetric P x).eigenvectorBasis_apply_self_apply (finrank_euclideanSpace_fin (𝕜 := ℝ)) v i

theorem value_mem {d : ℕ} (P : Problem d) (x : Space d) (i : Fin d) :
    value P x i ∈ Set.Icc (-1) 1 := by
  have he : normalized P x (basis P x i) = value P x i • basis P x i :=
    (symmetric P x).apply_eigenvectorBasis (finrank_euclideanSpace_fin (𝕜 := ℝ)) i
  have h := (normalized P x).le_opNorm (basis P x i)
  rw [he, norm_smul, Real.norm_eq_abs, (basis P x).orthonormal.1 i, mul_one, mul_one] at h
  exact abs_le.mp (h.trans (norm_le_one P x))

theorem inner_expansion {d : ℕ} (P : Problem d) (x v w : Space d) :
    ⟪v,w⟫_ℝ = ∑ j, (basis P x).repr v j * (basis P x).repr w j := by
  rw [← (basis P x).sum_inner_mul_inner v w]
  apply Finset.sum_congr rfl
  intro j _
  rw [OrthonormalBasis.repr_apply_apply, OrthonormalBasis.repr_apply_apply, real_inner_comm v]

theorem positive_quadratic_form {d : ℕ} (P : Problem d) (x v : Space d) :
    ⟪normalized P x v,v⟫_ℝ ≤
      ∑ j : {j : Fin d // 0 < value P x j}, value P x j * ((basis P x).repr v j)^2 := by
  classical
  have he := inner_expansion P x (normalized P x v) v
  simp_rw [diagonal, mul_assoc, ← pow_two] at he
  rw [he, ← Fintype.sum_subtype_add_sum_subtype (fun j => 0 < value P x j)]
  exact add_le_of_nonpos_right (Finset.sum_nonpos (fun j _ =>
    mul_nonpos_of_nonpos_of_nonneg (le_of_not_gt j.2) (sq_nonneg _)))

theorem projected_energy {d : ℕ} (P : Problem d) (x v : Space d) :
    (∑ j : {j : Fin d // 0 < value P x j}, ((basis P x).repr v j)^2) ≤ ‖v‖^2 := by
  classical
  have he := inner_expansion P x v v
  rw [real_inner_self_eq_norm_sq] at he
  simp_rw [← pow_two] at he
  rw [he, ← Fintype.sum_subtype_add_sum_subtype (fun j => 0 < value P x j)]
  exact le_add_of_nonneg_right (Finset.sum_nonneg (fun _ _ => sq_nonneg _))

end
end GDProof.Eigen
