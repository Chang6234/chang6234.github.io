import GDProof.Local
import GDProof.Global
import GDProof.Change
import GDProof.Guarded

namespace GDProof.Accelerated

open Schedule TraceData Spectral
open scoped BigOperators
noncomputable section

/-- An executed first-event prefix inherits the scalar certificates of the full table.
The last coefficient is allowed to be shortened by the observed gradient. -/
private theorem executed_bounds {d : ℕ} (P : Problem d) (ε : ℝ) (k : ℕ) (x : Space d)
    (E : ℝ) {n : ℕ} {C : ℝ} (hε : 0 < ε)
    (ht : 0 < n) (hlen : n ≤ (table (k+1)).length)
    (hpre : ∀ i < n, ¬ (Local.epochInput P ε k x E).event i)
    (hD : ∀ (z : ℝ), 0 < z → z ≤ 1 → Kernel.D z (table (k+1)) ≤ C*((2:ℝ)^(k+1))^4) :
    let a := Local.epochInput P ε k x E
    ∀ (z : ℝ), 0 < z → z ≤ 1 →
      Prefix.Stable z (steps a.coef n) ∧ Kernel.D z (steps a.coef n) ≤ C*((2:ℝ)^(k+1))^4 := by
  intro a z hz hz₁
  cases n with
  | zero => omega
  | succ i =>
    have hall : ∀ v ∈ a.table, 0 ≤ v := fun v hv => zero_le_one.trans (table_lower (k+1) v hv)
    have hi : i < a.table.length := by exact hlen
    obtain ⟨hc,he,hb,hba⟩ := a.last_coefficient_cut i hi hε.le hall hpre
    change Prefix.Stable z (a.executed (i+1)) ∧ Kernel.D z (a.executed (i+1)) ≤ _
    rw [he]
    refine ⟨Guarded.executed_prefix (k+1) z hz.le hz₁ _ _ _ _ hc hb hba, ?_⟩
    have hp : ∀ v ∈ a.table.take i, 0 ≤ v := by
      intro v hv
      apply hall
      rw [hc]
      simp [hv]
    have hf : ∀ v ∈ (a.table.take i ++ [a.table.getD i 0]), 0 ≤ v := by
      intro v hv
      apply hall
      rw [hc]
      exact List.mem_append.mpr (Or.inl hv)
    have hr : ∀ v ∈ a.table.drop (i+1), 0 ≤ v := by
      intro v hv
      apply hall
      rw [hc]
      exact List.mem_append.mpr (Or.inr hv)
    calc
      _ ≤ _ := Kernel.clippedLast_le hz.le hb hba _ hp
      _ ≤ _ := Kernel.D_prefix_le hz.le _ _ hf hr
      _ = Kernel.D z a.table := congrArg (Kernel.D z) hc.symm
      _ ≤ _ := hD z hz hz₁

/-- Applying the nonlinear perturbation theorem on the actual clipped rows
turns a scalar table bound into the budget-limited epoch decrease (B.2). -/
theorem budget_change_of_table_kernel {d : ℕ} (P : Problem d) (ε : ℝ) (k : ℕ)
    {C : ℝ} (hC : 0 ≤ C) (hε : 0 < ε)
    (hD : ∀ (z : ℝ), 0 < z → z ≤ 1 → Kernel.D z (table (k+1)) ≤ C*((2:ℝ)^(k+1))^4) :
    Local.BudgetChange P ε k (2*Real.sqrt C) := by
  intro x E n a m R _ _ _ hn hlen hpre hspent
  have hall : ∀ v ∈ a.table, 0 ≤ v := fun v hv => zero_le_one.trans (table_lower (k+1) v hv)
  have hprefix := executed_bounds P ε k x E hε hn hlen hpre hD
  have hmax (i : ℕ) (hi : i < n) : a.coef i ≤ m^2/2 := by
    have hilt := hi.trans_le hlen
    refine (a.coef_le_table i).trans ?_
    rw [List.getD_eq_get _ _ hilt]
    exact GuardSizes.table_step_upper k (List.get_mem _ _ _)
  let B := Real.sqrt C * m^2
  have hB : 0 ≤ B := mul_nonneg (Real.sqrt_nonneg _) (sq_nonneg _)
  have hBsq : B^2 = C*m^4 := by
    dsimp only [B]
    rw [mul_pow, Real.sq_sqrt hC]
    ring
  have h := Nonlinear.gd_change P (fun i => (a.row i).x) a.coef n hB
    (fun i hi => a.coef_nonnegative i (hi.trans_le hlen) hall) (fun i _ => a.row_succ_x i)
    (a.sum_coef_le_table n hlen hall) hmax
    (fun z hz hz₁ => (hprefix z hz hz₁).1)
    (fun z hz hz₁ => hBsq.symm ▸ (hprefix z hz hz₁).2)
  have hsum : (∑ i ∈ Finset.range n, a.coef i*‖P.grad (a.row i).x‖^2) = E :=
    (a.spent_sum n).symm.trans hspent
  dsimp only at h
  rw [hsum] at h
  change P.f (a.row n).x - P.f x ≤ E/P.L *
    (-1+(1+2*B*(P.ρ*R/P.L))^2/2+(P.ρ*R/P.L)*(m^2/2)/2) at h
  calc
    -(P.L*(P.f x-P.f (a.row n).x)) = P.L*(P.f (a.row n).x-P.f x) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_left h P.L_pos.le
    _ = _ := by
      have hcancel : E/P.L*P.L = E := by field_simp [P.L_pos.ne']
      rw [← mul_assoc, mul_comm P.L (E/P.L), hcancel]
      rw [show 2*B*(P.ρ*R/P.L) = (2*Real.sqrt C)*(m^2*(P.ρ*R/P.L)) by
        dsimp only [B]; ring]

/-- End-to-end reduction from the full-table squared gain, uniformly in the
size and the normalized curvature, to the exact main theorem. -/
theorem main_of_table_kernel {C : ℝ} (hC : 0 ≤ C)
    (hD : ∀ (k : ℕ) (z : ℝ), 0 < z → z ≤ 1 → Kernel.D z (table k) ≤ C*((2:ℝ)^k)^4) :
    MainGuarantee := by
  let K := 2*Real.sqrt C
  have hK : 0 ≤ K := by dsimp [K]; positivity
  have hA : 0 ≤ K*Real.sqrt 2 := mul_nonneg hK (Real.sqrt_nonneg _)
  apply Global.main_of_local_epochs (Epoch.threshold (K*Real.sqrt 2) 1) ((1+K*Real.sqrt 2)^2)
    (Epoch.threshold_pos hA zero_lt_one) (Epoch.threshold_le hA zero_le_one) (sq_nonneg _)
  intro d P ε hε hn
  cases he : Degree.exponent (max 1 (degreeScale P.L P.ρ ε)) with
  | zero => exact (hn he).elim
  | succ k =>
    have hdeg : Scale.degree P.L P.ρ ε = (2:ℝ)^(k+1) := by
      change (2:ℝ)^Degree.exponent (max 1 (degreeScale P.L P.ρ ε)) = _
      rw [he]
    have hm : 2 ≤ Scale.degree P.L P.ρ ε := by
      rw [hdeg,pow_succ]
      have hlow := one_le_pow_of_one_le (by norm_num : (1:ℝ) ≤ 2) k
      linarith only [hlow]
    have hs := Geometry.selected_stability P.L_pos P.ρ_pos hε hm
    rw [hdeg] at hs
    rw [chosenTable, he]
    exact Local.localEpoch_of_change P ε k K hε hK hs
      (budget_change_of_table_kernel P ε k hC hε (hD (k+1)))

end
end GDProof.Accelerated
