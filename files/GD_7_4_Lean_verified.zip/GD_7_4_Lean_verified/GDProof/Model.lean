import Mathlib

namespace GDProof.Model

noncomputable section

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

/-- The paper's persistent variables, including the cached exact gradient. -/
structure State (V : Type*) where
  x : V
  g : V
  index : ℕ
  spent : ℝ
  cross : ℝ
  budget : ℝ
  cap : ℝ

def fresh (x g : V) (E : ℝ) : State V :=
  ⟨x, g, 0, 0, 0, E, max E (‖g‖ ^ 2)⟩

def initial (g : V → V) (x : V) (table : List ℝ) (ε : ℝ) : State V :=
  fresh x (g x) ((ε ^ 2 / 2) * table.sum)

def clip (b spent cap q : ℝ) : ℝ := min b ((cap - spent) / q)

def nextPoint (L h : ℝ) (s : State V) : V := s.x - (h / L) • s.g

/-- Exactly one new gradient is evaluated here. Resetting the epoch uses that value. -/
def advance (oracle : V → V) (L ε b : ℝ) (s : State V) : State V :=
  let h := clip b s.spent s.cap (‖s.g‖ ^ 2)
  let x' := nextPoint L h s
  let g' := oracle x'
  let S := s.spent + h * ‖s.g‖ ^ 2
  let C := s.cross + h * inner s.g g'
  if S = s.cap ∧ ε < ‖g'‖ then
    fresh x' g' (if C < -S / 2 then s.budget / 2 else s.budget)
  else
    ⟨x', g', s.index + 1, S, C, s.budget, s.cap⟩

/-- One *executed* update. A halted state or an invalid table index has no successor. -/
def step (oracle : V → V) (L ε : ℝ) (table : List ℝ) (s : State V) :
    Option (State V) :=
  if ε < ‖s.g‖ then (table.get? s.index).map (fun b => advance oracle L ε b s)
  else none

/-- If this returns a state at k, exactly k updates have been executed. -/
def run (oracle : V → V) (L ε : ℝ) (table : List ℝ) (start : State V) :
    ℕ → Option (State V)
  | 0 => some start
  | k + 1 => (run oracle L ε table start k).bind (step oracle L ε table)

theorem cached_advance (oracle : V → V) (L ε b : ℝ) (s : State V) :
    (advance oracle L ε b s).g = oracle (advance oracle L ε b s).x := by
  unfold advance
  dsimp only
  split <;> rfl

theorem cached_step {oracle : V → V} {L ε : ℝ} {table : List ℝ} {s t : State V}
    (h : step oracle L ε table s = some t) : t.g = oracle t.x := by
  unfold step at h
  split at h
  · cases hb : table.get? s.index with
    | none => simp [hb] at h
    | some b =>
      have he : advance oracle L ε b s = t := by simpa [hb] using h
      rw [← he]
      exact cached_advance oracle L ε b s
  · contradiction

theorem cached_run {oracle : V → V} {L ε : ℝ} {table : List ℝ} {x : V}
    {k : ℕ} {t : State V}
    (h : run oracle L ε table (initial oracle x table ε) k = some t) :
    t.g = oracle t.x := by
  cases k with
  | zero =>
    have he : initial oracle x table ε = t := by simpa [run] using h
    rw [← he]
    rfl
  | succ j =>
    cases hj : run oracle L ε table (initial oracle x table ε) j with
    | none => simp [run, hj] at h
    | some u =>
      exact cached_step (by simpa [run, hj] using h : step oracle L ε table u = some t)

theorem clip_spec {b S T q : ℝ} (hb : 0 < b) (hS : S < T) (hq : 0 < q) :
    0 < clip b S T q ∧ clip b S T q ≤ b ∧ S + clip b S T q * q ≤ T := by
  have hprod : (T - S) / q * q = T - S := by field_simp
  have ha := mul_le_mul_of_nonneg_right (min_le_right b ((T - S) / q)) hq.le
  exact ⟨lt_min hb (div_pos (sub_pos.mpr hS) hq), min_le_left _ _, by
    unfold clip
    linarith⟩

theorem shortened_spends_cap {b S T q : ℝ} (hq : 0 < q)
    (h : clip b S T q < b) : S + clip b S T q * q = T := by
  by_cases hle : b ≤ (T - S) / q
  · simp [clip, min_eq_left hle] at h
  · rw [clip, min_eq_right (le_of_not_ge hle)]
    have hh : (T - S) / q * q = T - S := by field_simp
    linarith

end
end GDProof.Model
