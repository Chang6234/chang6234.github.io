import GDProof.RawProduct

namespace GDProof.RawInterval

open GDProof.Schedule GDProof.Prefix

noncomputable section

/-- One block of the binary split tree rooted at a. -/
def descendants : ℕ → ℝ → List ℝ
  | 0, a => [a]
  | k+1, a => descendants k (small a) ++ descendants k (large a)

def folded : ℕ → ℝ → ℝ
  | 0, z => z
  | k+1, z => 4*folded k z*(1-folded k z)

theorem folded_bounds (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    0 ≤ folded k z ∧ folded k z ≤ 1 ∧ folded k z ≤ (4:ℝ)^k*z := by
  induction k with
  | zero => simpa [folded] using And.intro hz (And.intro h₁ (le_rfl : z ≤ z))
  | succ k ih =>
    obtain ⟨h₀,h₂,h₃⟩ := ih
    simp only [folded, pow_succ]
    refine ⟨mul_nonneg (mul_nonneg (by norm_num) h₀) (sub_nonneg.mpr h₂), ?_, ?_⟩
    · nlinarith [sq_nonneg (1-2*folded k z)]
    · nlinarith [sq_nonneg (folded k z)]

theorem descendants_prod (k : ℕ) {a : ℝ} (ha : 1 ≤ a) (z : ℝ) :
    prod z (descendants k a) = 1-a*folded k z := by
  induction k generalizing a with
  | zero => simp [descendants, prod, folded, mul_comm]
  | succ k ih =>
    rw [descendants, prod_append, ih (small_bounds ha).1, ih (by linarith [large_lower ha]),
      pair_product ha, folded]
    ring

theorem cut {α : Type*} (u v p s : List α) (h : u ++ v = p ++ s) :
    (∃ t, u = p ++ t ∧ t ++ v = s) ∨ (∃ t, p = u ++ t ∧ v = t ++ s) := by
  rcases splitCut u v p s h with ⟨t,ht⟩ | ⟨t,ht,hs⟩
  · right
    refine ⟨t,ht,?_⟩
    apply List.append_cancel_left (as := u)
    simpa [ht,List.append_assoc] using h
  · exact Or.inl ⟨t,ht,hs⟩

theorem full_small (k : ℕ) {a z : ℝ} (ha : 1 ≤ a) (ha' : a ≤ 2)
    (hz : 0 ≤ z) (h₁ : z ≤ 1) : |prod z (descendants k a)| ≤ 1 := by
  rw [descendants_prod k ha, abs_le]
  obtain ⟨h₀,h₂,_⟩ := folded_bounds k z hz h₁
  have ha₀ : 0 ≤ a := by linarith
  have ht := mul_le_mul ha' h₂ h₀ (by norm_num : 0 ≤ (2:ℝ))
  constructor <;> nlinarith [mul_nonneg ha₀ h₀]

theorem descendants_proper_prefix (k : ℕ) {a z : ℝ} (ha : 1 ≤ a)
    (hz : 0 ≤ z) (h₁ : z ≤ 1) (p s : List ℝ) (hs : s ≠ [])
    (h : descendants k a = p ++ s) : |prod z p| ≤ 1 := by
  induction k generalizing a p s with
  | zero =>
    cases p with
    | nil => simp [prod]
    | cons b p =>
      have ht := (List.cons.inj h).2
      exact (hs (List.append_eq_nil.mp ht.symm).2).elim
  | succ k ih =>
    obtain ⟨hb,hb'⟩ := small_bounds ha
    rcases cut _ _ _ _ h with ⟨t,ht,_⟩ | ⟨t,ht,hv⟩
    · by_cases hnil : t = []
      · subst t
        simp only [List.append_nil] at ht
        rw [← ht]
        exact full_small k hb hb' hz h₁
      · exact ih hb p t hnil ht
    · rw [ht, prod_append, abs_mul]
      have hl := full_small k hb hb' hz h₁
      have hr := ih (show 1 ≤ large a by linarith [large_lower ha]) t s hs hv
      simpa using mul_le_mul hl hr (abs_nonneg _) (zero_le_one : (0:ℝ) ≤ 1)

private theorem full_large (k : ℕ) {a z : ℝ} (ha : 2 ≤ a) (hz : 0 ≤ z) (h₁ : z ≤ 1) :
    |prod z (descendants k a)| ≤ a-1 := by
  rw [descendants_prod k (by linarith), abs_le]
  obtain ⟨h₀,h₂,_⟩ := folded_bounds k z hz h₁
  have ha₀ : 0 ≤ a := by linarith
  have ht := mul_le_mul_of_nonneg_left h₂ ha₀
  constructor <;> nlinarith [mul_nonneg ha₀ h₀]

private theorem factor_bound {a z : ℝ} (ha : 0 ≤ a) (hz : 0 ≤ z) :
    |1-z*a| ≤ max 1 (a*z) := by
  rw [abs_le]
  have h1 := le_max_left (1:ℝ) (a*z)
  have h2 := le_max_right (1:ℝ) (a*z)
  constructor <;> nlinarith [mul_nonneg ha hz]

/-- Every consecutive subword in a block of 2^k descendants has the indicated
bound, including crossings from a suffix of the left half into its right half. -/
theorem descendants_interval (k : ℕ) {a z : ℝ} (ha : 1 ≤ a)
    (hz : 0 ≤ z) (h₁ : z ≤ 1) (l x r : List ℝ)
    (h : descendants k a = l ++ (x ++ r)) :
    |prod z x| ≤ max 1 (a*(4:ℝ)^k*z) := by
  induction k generalizing a l x r with
  | zero =>
    simp only [descendants] at h
    simp only [pow_zero,mul_one]
    cases x with
    | nil => simp [prod]
    | cons b x =>
      cases l with
      | nil =>
        obtain ⟨he,ht⟩ := List.cons.inj h
        subst b
        have hx := (List.append_eq_nil.mp ht.symm).1
        subst x
        simpa [prod] using factor_bound (show 0 ≤ a by linarith) hz
      | cons b l =>
        have ht := (List.cons.inj h).2
        have hr := (List.append_eq_nil.mp ht.symm).2
        cases hr
  | succ k ih =>
    obtain ⟨hb₀,hb₂⟩ := small_bounds ha
    have hc₂ := large_lower ha
    have hc₀ : 1 ≤ large a := by linarith
    have hb4 : small a ≤ 4*a := by linarith
    have hc4 : large a ≤ 4*a := by linarith [pair_add a]
    have h4 : 0 ≤ (4:ℝ)^k := by positivity
    have subbound : ∀ d : ℝ, d ≤ 4*a → max 1 (d*4^k*z) ≤ max 1 (a*4^(k+1)*z) := by
      intro d hd
      apply max_le_max_left
      rw [pow_succ]
      have hmul := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_right hd h4) hz
      nlinarith only [hmul]
    rcases cut _ _ _ _ h with ⟨u,hA,hu⟩ | ⟨u,_,hB⟩
    · rcases cut _ _ _ _ hu with ⟨v,hux,_⟩ | ⟨v,hxv,hB⟩
      · have hleft := ih hb₀ l x v (by rw [hA, hux])
        exact hleft.trans (subbound _ hb4)
      · have hleft := ih hb₀ l u [] (by simpa using hA)
        have hright := ih hc₀ [] v r (by simpa using hB)
        rw [hxv,prod_append,abs_mul]
        by_cases hr : r = []
        · subst r
          simp only [List.append_nil] at hB
          by_cases ht : small a*4^k*z ≤ 1
          · rw [max_eq_left ht] at hleft
            simpa using mul_le_mul hleft (hright.trans (subbound _ hc4)) (abs_nonneg _)
              (zero_le_one : (0:ℝ) ≤ 1)
          · rw [max_eq_right (le_of_not_ge ht)] at hleft
            have hright' : |prod z v| ≤ large a-1 := hB ▸ full_large k hc₂ hz h₁
            have hbc : small a*(large a-1) = large a := by
              nlinarith only [pair_add a, pair_mul ha]
            calc
              _ ≤ (small a*4^k*z)*(large a-1) := mul_le_mul hleft hright' (abs_nonneg _)
                (le_trans (abs_nonneg _) hleft)
              _ = large a*4^k*z := by linear_combination (4^k*z)*hbc
              _ ≤ _ := (le_max_right 1 _).trans (subbound _ hc4)
        · have hright' := descendants_proper_prefix k hc₀ hz h₁ v r hr hB
          simpa using mul_le_mul (hleft.trans (subbound _ hb4)) hright' (abs_nonneg _)
            ((zero_le_one : (0:ℝ) ≤ 1).trans (le_max_left _ _))
    · exact (ih hc₀ u x r hB).trans (subbound _ hc4)

theorem children_append (x y : List ℝ) : children (x ++ y) = children x ++ children y := by
  induction x with
  | nil => rfl
  | cons a x ih => simp [children, ih]

theorem children_descendants (k : ℕ) (a : ℝ) :
    children (descendants k a) = descendants (k+1) a := by
  induction k generalizing a with
  | zero => rfl
  | succ k ih =>
    change children (descendants k (small a) ++ descendants k (large a)) = _
    rw [children_append, ih, ih]
    rfl

theorem rawTail_snoc (k : ℕ) : rawTail (k+1) = rawTail k ++ descendants k 2 := by
  induction k with
  | zero => rfl
  | succ k ih =>
    change 2 :: children (rawTail (k+1)) = (2 :: children (rawTail k)) ++ descendants (k+1) 2
    rw [ih, children_append, children_descendants]
    rfl

theorem raw_snoc (k : ℕ) : raw (k+1) = raw k ++ descendants k 2 := by
  unfold raw
  rw [rawTail_snoc]
  rfl

/-- Entire raw-table bound with the global dyadic scale. -/
theorem raw_interval (k : ℕ) (z : ℝ) (hz : 0 ≤ z) (h₁ : z ≤ 1)
    (l x r : List ℝ) (h : raw k = l ++ (x ++ r)) :
    |prod z x| ≤ max 1 ((4:ℝ)^k / 2 * z) := by
  induction k generalizing l x r with
  | zero =>
    have hb := descendants_interval 0 (show (1:ℝ) ≤ 1 by norm_num) hz h₁ l x r h
    have hh : |prod z x| ≤ 1 := by simpa [max_eq_left h₁] using hb
    exact hh.trans (le_max_left _ _)
  | succ k ih =>
    have h4 : 0 ≤ (4:ℝ)^k := by positivity
    have hg : (4:ℝ)^(k+1)/2*z = 2*4^k*z := by rw [pow_succ]; ring
    have hs : max 1 (4^k/2*z) ≤ max 1 (2*4^k*z) := by
      apply max_le_max_left
      nlinarith only [mul_nonneg h4 hz]
    rw [hg]
    rw [raw_snoc] at h
    rcases cut _ _ _ _ h with ⟨u,hA,hu⟩ | ⟨u,_,hB⟩
    · rcases cut _ _ _ _ hu with ⟨v,hux,_⟩ | ⟨v,hxv,hB⟩
      · exact (ih l x v (by rw [hA,hux])).trans hs
      · have hl := (ih l u [] (by simpa using hA)).trans hs
        have hr : |prod z v| ≤ 1 := by
          by_cases hr : r = []
          · subst r
            simp only [List.append_nil] at hB
            rw [← hB]
            exact full_small k (by norm_num) (by norm_num) hz h₁
          · exact descendants_proper_prefix k (by norm_num) hz h₁ _ _ hr hB
        rw [hxv,prod_append,abs_mul]
        simpa using mul_le_mul hl hr (abs_nonneg _) (le_trans (abs_nonneg _) hl)
    · exact descendants_interval k (by norm_num) hz h₁ u x r hB

end

end GDProof.RawInterval
