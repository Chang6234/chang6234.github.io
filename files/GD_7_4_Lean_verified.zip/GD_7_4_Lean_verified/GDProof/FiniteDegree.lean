import GDProof.FiniteStorage
import GDProof.RadicalBounds
import GDProof.Riccati

/-! The scalar storage inequality for every executed prefix of the actual
degree-four and degree-eight half-mass words, including a shortened last step. -/
namespace GDProof.FiniteDegree

open FiniteStorage

noncomputable section

private theorem fullStep {τ z h A B g w : ℝ} (hτ : 0 < τ) (hh : 0 ≤ h)
    (hs : h*B < τ)
    (hc : z*h^2-21/20*h + (1-z*h)^2 * B / (1-h*B/τ) ≤ A) :
    (z*h^2-21/20*h)*g^2 + B*((1-z*h)*g+Real.sqrt h*w)^2 ≤ A*g^2 + τ*w^2 := by
  apply Riccati.step
  · rw [Real.sq_sqrt hh]
    linarith
  · rw [Real.sq_sqrt hh]
    have normalize : 1 - h*B/τ = (τ-B*h)/τ := by
      field_simp [hτ.ne']
      ring
    rw [normalize, div_div_eq_mul_div] at hc
    convert hc using 1
    ring

/-- The source index is zero based. All nonfinal coefficients agree with
the word and the final one may lie between zero and the nominal coefficient. -/
def Executed {n : ℕ} (word : Fin n → ℝ) (t : ℕ) (h : ℕ → ℝ) : Prop :=
  t ≤ n ∧ ∀ (i : Fin n), i.val < t → (0 ≤ h i.val ∧ h i.val ≤ word i) ∧
    (i.val + 1 < t → h i.val = word i)

private theorem clippedPrefix {n : ℕ} {τ z : ℝ} {coeff : Fin n → Interval}
    {word : Fin n → ℝ} {R : Fin (n+1) → ℚ}
    (hτ : 0 < τ) (hz : 0 ≤ z) (stored : Stores τ z coeff R)
    (box : ∀ i, (coeff i).1 ≤ word i ∧ word i ≤ (coeff i).2)
    (t : ℕ) (h g w : ℕ → ℝ) (executed : Executed word t h)
    (update : ∀ i < t, g (i+1) = (1-z*h i)*g i + Real.sqrt (h i)*w i) :
    ∑ i in Finset.range t, (z*(h i)^2-21/20*h i)*(g i)^2 ≤
      ∑ i in Finset.range t, τ*(w i)^2 := by
  obtain ⟨ht, hcut⟩ := executed
  obtain ⟨hzero, _, hstore⟩ := stored
  let E (i : ℕ) : ℝ := if hi : i ≤ n then (R ⟨i, Nat.lt_succ_of_le hi⟩ : ℝ) else 0
  have before : ∀ s < t,
      (∑ i in Finset.range s, (z*(h i)^2-21/20*h i)*(g i)^2) + E s*(g s)^2 ≤
        ∑ i in Finset.range s, τ*(w i)^2 := by
    intro s
    induction s with
    | zero =>
      intro _
      simp [E, hzero]
    | succ i ih =>
      intro hs
      let j : Fin n := ⟨i, by omega⟩
      have eqn : h i = word j := (hcut j (by dsimp [j]; omega)).2 hs
      have sh := (hstore j).2.2 (word j) (box j).1 (box j).2
      rw [← eqn] at sh
      have hh : 0 ≤ h i := (hcut j (by dsimp [j]; omega)).1.1
      have next := fullStep (g := g i) (w := w i) hτ hh sh.1 sh.2
      rw [← update i (by omega)] at next
      have hi := ih (by omega)
      have e0 : E i = (R j.castSucc : ℝ) := by simp [E, show i ≤ n by omega, j]
      have e1 : E (i+1) = (R j.succ : ℝ) := by simp [E, show i+1 ≤ n by omega, j]
      rw [← e0, ← e1] at next
      simp only [Finset.sum_range_succ]
      linarith
  cases t with
  | zero => simp
  | succ i =>
    let j : Fin n := ⟨i, by omega⟩
    have cur := before i (Nat.lt_succ_self _)
    have nonneg : 0 ≤ (R j.castSucc : ℝ) := by exact_mod_cast (hstore j).1
    have rb : 0 ≤ (R j.succ : ℝ) := by exact_mod_cast (hstore j).2.1
    have hc := hcut j (Nat.lt_succ_self _)
    have stored := (hstore j).2.2 (word j) (box j).1 (box j).2
    have hden : 0 ≤ 1 - word j * (R j.succ : ℝ) / τ := by
      exact sub_nonneg.mpr ((div_le_one hτ).2 stored.1.le)
    have frac := div_nonneg (mul_nonneg (sq_nonneg (1-z*word j)) rb) hden
    have card : z*(word j)^2-21/20*word j ≤ (R j.castSucc : ℝ) := by linarith [stored.2]
    have cost := (Riccati.shortened_last z (21/20) (word j) (h i) hz hc.1.1 hc.1.2).trans
      (max_le nonneg card)
    have at_i : E i = (R j.castSucc : ℝ) := by simp [E, show i ≤ n by omega, j]
    rw [at_i] at cur
    simp only [Finset.sum_range_succ]
    linarith [mul_le_mul_of_nonneg_right cost (sq_nonneg (g i)),mul_nonneg hτ.le (sq_nonneg (w i))]

private theorem box4 (i : Fin 5) : (coeff4 i).1 ≤ RadicalBounds.four i ∧
    RadicalBounds.four i ≤ (coeff4 i).2 := by
  have enclosed := RadicalBounds.four_enclosed i
  fin_cases i <;> norm_num [coeff4,RadicalBounds.coeff4,Matrix.cons_val_succ] at enclosed ⊢ <;>
    exact enclosed

private theorem box8 (i : Fin 10) : (coeff8 i).1 ≤ RadicalBounds.eight i ∧
    RadicalBounds.eight i ≤ (coeff8 i).2 := by
  have enclosed := RadicalBounds.eight_enclosed i
  fin_cases i <;> norm_num [coeff8,RadicalBounds.coeff8,Matrix.cons_val_succ] at enclosed ⊢ <;>
    exact enclosed

/-- The degree-four quadratic supply inequality, on the actual word truncated
at mass 13/2 and with a possibly shortened final coefficient. -/
theorem storage_four (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) (t : ℕ) (h g w : ℕ → ℝ)
    (ex : Executed RadicalBounds.four t h)
    (rec : ∀ i < t, g (i+1) = (1-z*h i)*g i + Real.sqrt (h i)*w i) :
    ∑ i in Finset.range t, (z*(h i)^2-21/20*h i)*(g i)^2 ≤
      ∑ i in Finset.range t, (4:ℝ)^4*(w i)^2 := by
  obtain ⟨j, hj⟩ := stores4 z hz hz'
  norm_num at hj ⊢
  exact clippedPrefix (by norm_num) hz hj box4 t h g w ex rec

/-- The degree-eight quadratic supply inequality, on the actual word truncated
at mass 49/2 and with a possibly shortened final coefficient. -/
theorem storage_eight (z : ℝ) (hz : 0 ≤ z) (hz' : z ≤ 1) (t : ℕ) (h g w : ℕ → ℝ)
    (ex : Executed RadicalBounds.eight t h)
    (rec : ∀ i < t, g (i+1) = (1-z*h i)*g i + Real.sqrt (h i)*w i) :
    ∑ i in Finset.range t, (z*(h i)^2-21/20*h i)*(g i)^2 ≤
      ∑ i in Finset.range t, (8:ℝ)^4*(w i)^2 := by
  obtain ⟨j, hj⟩ := stores8 z hz hz'
  norm_num at hj ⊢
  exact clippedPrefix (by norm_num) hz hj box8 t h g w ex rec

end
end GDProof.FiniteDegree
