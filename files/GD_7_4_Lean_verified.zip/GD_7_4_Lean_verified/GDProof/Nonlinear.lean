import GDProof.Frozen
import GDProof.Spectral
import GDProof.Prefix

namespace GDProof.Nonlinear

open Finset GDProof.Prefix GDProof.Spectral
open scoped RealInnerProductSpace BigOperators
noncomputable section

private theorem weighted_append (z : ℝ) (f : ℝ → ℝ) (a b : List ℝ) :
    weighted z f (a ++ b) = weighted z f a + (prod z a)^2*weighted z f b := by
  induction a with
  | nil => simp [weighted,prod]
  | cons v a ih =>
    change f v + (1-z*v)^2*weighted z f (a ++ b) = _
    rw [ih]
    simp only [weighted,prod]
    ring

theorem weighted_steps (z : ℝ) (f : ℝ → ℝ) (g : ℕ → ℝ) (n : ℕ) :
    weighted z f (steps g n) = ∑ i ∈ range n, f (g i)*(prod z (steps g i))^2 := by
  induction n with
  | zero => simp [steps,weighted]
  | succ n ih =>
    rw [steps_succ,weighted_append,ih,sum_range_succ]
    simp [weighted,mul_comm]

def pred (z : ℝ) (h : ℕ → ℝ) (a : ℝ) (i : ℕ) := prod z (steps h i)*a

theorem predicted_curvature (z : ℝ) (h : ℕ → ℝ) (a : ℝ) (n : ℕ)
    (hz : 0 < z) (hs : Stable z (steps h n)) :
    (∑ i ∈ range n, (z*(h i)^2)*(pred z h a i)^2) ≤
      ∑ i ∈ range n, h i*(pred z h a i)^2 := by
  have hc := mul_le_mul_of_nonneg_right (frozen_curvature hz hs) (sq_nonneg a)
  rw [weighted_steps, weighted_steps, mul_sum, sum_mul, sum_mul] at hc
  convert hc using 1 <;> apply sum_congr rfl <;> intro i _ <;> simp only [pred,id_eq] <;> ring

/-- Weighted coordinates of an entire epoch, indexed by eigendirection and step. -/
def embed {ι : Type*} [Fintype ι] (n : ℕ) (r v : ι → ℕ → ℝ) : EuclideanSpace ℝ (ι × Fin n) :=
  fun p => √(r p.1 p.2)*(v p.1 p.2)

theorem embed_sq {ι : Type*} [Fintype ι] (n : ℕ) (r v : ι → ℕ → ℝ)
    (hr : ∀ k i, i < n → 0 ≤ r k i) :
    ‖embed n r v‖^2 = ∑ k, ∑ i ∈ range n, r k i*(v k i)^2 := by
  classical
  rw [PiLp.norm_sq_eq_of_L2, Fintype.sum_prod_type]
  apply sum_congr rfl
  intro k _
  rw [← Fin.sum_univ_eq_sum_range]
  apply sum_congr rfl
  intro i _
  simp only [embed,Real.norm_eq_abs,sq_abs,mul_pow,Real.sq_sqrt (hr k i i.isLt)]

private theorem embed_add {ι : Type*} [Fintype ι] (n : ℕ) (r u v : ι → ℕ → ℝ) :
    embed n r (fun k i => u k i + v k i) = embed n r u + embed n r v := by
  ext p
  change √(r p.1 p.2)*(u p.1 p.2+v p.1 p.2) = _
  exact mul_add _ _ _

private theorem le_of_sq {a b : ℝ} (hb : 0 ≤ b) (h : a^2 ≤ b^2) : a ≤ b :=
  (le_abs_self a).trans (by simpa only [abs_of_nonneg hb] using sq_le_sq.mp h)

/-- Triangle inequalities in the two weighted Euclidean norms with the same
error budget B. The positivity subtype is the only set of coordinates needed. -/
theorem transfer {ι : Type*} [Fintype ι] (z : ι → ℝ) (h : ℕ → ℝ)
    (g w : ι → ℕ → ℝ) (n : ℕ) {B τ S : ℝ} (hB : 0 ≤ B) (hτ : 0 ≤ τ) (hS : 0 ≤ S)
    (hz : ∀ k, 0 < z k) (hh : ∀ i < n, 0 ≤ h i) (hs : ∀ k, Stable (z k) (steps h n))
    (hD : ∀ k, GDProof.Kernel.D (z k) (steps h n) ≤ B^2)
    (hinit : ∀ k i, i < n → g k (i+1) = (1-z k*h i)*g k i+√(h i)*w k i)
    (hw : (∑ k, ∑ i ∈ range n, (w k i)^2) ≤ τ^2*S)
    (hg : (∑ k, ∑ i ∈ range n, h i*(g k i)^2) ≤ S) :
    (∑ k, ∑ i ∈ range n, (z k*(h i)^2)*(g k i)^2) ≤ (1+2*B*τ)^2*S := by
  classical
  let p := fun k => pred (z k) h (g k 0)
  let e := fun k i => g k i - p k i
  let a := fun (_ : ι) i => h i
  let b := fun k i => z k*(h i)^2
  have ha : ∀ k i, i < n → 0 ≤ a k i := fun _ i hi => hh i hi
  have hb : ∀ k i, i < n → 0 ≤ b k i := fun k i _ => mul_nonneg (hz k).le (sq_nonneg _)
  have hp (k : ι) (i : ℕ) : p k (i+1) = (1-z k*h i)*p k i := by
    dsimp only [p,pred]
    rw [steps_succ,prod_append]
    simp only [prod,mul_one]
    ring
  have h₀ : ∀ k, e k 0 = 0 := by simp [e,p,pred,steps,prod]
  have hf (k : ι) (i : ℕ) (hi : i < n) : e k (i+1) = (1-z k*h i)*e k i + √(h i)*w k i := by
    dsimp only [e]
    rw [hp,hinit k i hi]
    ring
  obtain ⟨hea,heb⟩ := spectral_transfer z h w e n (B^2) (fun k => (hz k).le) hh h₀ hf hD
  have hsq : B^2*(τ^2*S) = (B*τ*√S)^2 := by rw [mul_pow,Real.sq_sqrt hS]; ring
  have hboundary := mul_le_mul_of_nonneg_left hw (sq_nonneg B)
  rw [hsq] at hboundary
  have hnn : 0 ≤ B*τ*√S := by positivity
  have hea' : ‖embed n a e‖ ≤ B*τ*√S := by
    have ht : ‖embed n a e‖^2 ≤ (B*τ*√S)^2 := (embed_sq n a e ha) ▸ hea.trans hboundary
    exact le_of_sq hnn ht
  have heb' : ‖embed n b e‖ ≤ B*τ*√S := by
    have ht : ‖embed n b e‖^2 ≤ (B*τ*√S)^2 := (embed_sq n b e hb) ▸ heb.trans hboundary
    exact le_of_sq hnn ht
  have hpred : ‖embed n b p‖ ≤ ‖embed n a p‖ := by
    apply le_of_sq (norm_nonneg _)
    rw [embed_sq _ _ _ hb,embed_sq _ _ _ ha]
    exact sum_le_sum (fun k _ => predicted_curvature (z k) h (g k 0) n (hz k) (hs k))
  have hg' : ‖embed n a g‖ ≤ √S := by
    apply le_of_sq (Real.sqrt_nonneg _)
    rw [embed_sq _ _ _ ha,Real.sq_sqrt hS]
    exact hg
  have de (r : ι → ℕ → ℝ) : embed n r p + embed n r e = embed n r g := by
    rw [← embed_add]
    apply congrArg (embed n r)
    funext k i
    dsimp only [e]
    ring
  have hpa : ‖embed n a p‖ ≤ ‖embed n a g‖ + ‖embed n a e‖ := by
    have he : embed n a p = embed n a g - embed n a e := by rw [← de a]; abel
    rw [he]
    exact norm_sub_le _ _
  have htot : ‖embed n b g‖ ≤ (1+2*B*τ)*√S := by
    calc
      _ ≤ ‖embed n b p‖ + ‖embed n b e‖ := by rw [← de b]; exact norm_add_le _ _
      _ ≤ _ := by nlinarith only [hpred,hpa,hea',heb',hg']
  have hpow := pow_le_pow_left (norm_nonneg _) htot 2
  rw [embed_sq _ _ _ hb,mul_pow,Real.sq_sqrt hS] at hpow
  exact hpow

end
end GDProof.Nonlinear
