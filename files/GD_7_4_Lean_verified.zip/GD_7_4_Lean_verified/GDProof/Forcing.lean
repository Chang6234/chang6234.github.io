import GDProof.Frozen
import GDProof.Eigen

/-! Normalized forcing for the true gradient recurrence in the frozen eigenbasis. -/
namespace GDProof.Forcing

open scoped BigOperators

theorem gd_forcing {d : ℕ} (P : Problem d) (x : ℕ → Space d) (h : ℕ → ℝ)
    (n : ℕ) {A E : ℝ} (hh : ∀ i < n, 0 ≤ h i)
    (hgd : ∀ i < n, x (i+1) = x i - (h i/P.L) • P.grad (x i))
    (hmass : (∑ i in Finset.range n, h i) ≤ A)
    (henergy : (∑ i in Finset.range n, h i * ‖P.grad (x i)‖^2) ≤ E) :
    let R := Real.sqrt (A*E)/P.L
    let b := Eigen.basis P (x 0)
    ∃ w : ℕ → Space d, (∀ i < n, ∀ j : Fin d,
      b.repr (P.grad (x (i+1))) j = (1-Eigen.value P (x 0) j*h i)*b.repr (P.grad (x i)) j
        + Real.sqrt (h i)*b.repr (w i) j) ∧
      (∑ i in Finset.range n, ‖w i‖^2) ≤ (P.ρ*R/P.L)^2*E := by
  intro R b
  let s := fun i => x (i+1)-x i
  let D := fun i => P.grad (x (i+1))-P.grad (x i)-P.hess (x 0) (s i)
  let w : ℕ → Space d := fun i => (Real.sqrt (h i))⁻¹ • D i
  have path := Geometry.path_length x (fun i => P.grad (x i)) h n P.L_pos hh hgd hmass henergy
  have hR : 0 ≤ R := div_nonneg (Real.sqrt_nonneg _) P.L_pos.le
  have hdis (i : ℕ) (hi : i < n) : s i = -((h i/P.L) • P.grad (x i)) := by
    dsimp only [s]
    rw [hgd i hi]
    abel
  have hd (i : ℕ) (hi : i < n) : ‖D i‖ ≤ P.ρ*R*‖s i‖ := by
    have hu := Frozen.gradient_remainder P (x 0) (x i) (s i)
      (fun _ ht => Frozen.segment_radius x n path hi ht)
    have hx : x i + s i = x (i+1) := by dsimp only [s]; abel
    rwa [hx] at hu
  refine ⟨w, ?_, ?_⟩
  · intro i hi j
    have hw : Real.sqrt (h i) • w i = D i := by
      by_cases hz : h i = 0
      · have hx : x (i+1) = x i := by simpa [hz] using hgd i hi
        simp [w, D, s, hx, hz]
      · have hs := (Real.sqrt_pos.2 (lt_of_le_of_ne (hh i hi) (Ne.symm hz))).ne'
        simp [w, smul_smul, hs]
    have hM : P.hess (x 0) (s i) = -(h i • Eigen.normalized P (x 0) (P.grad (x i))) := by
      rw [hdis i hi, map_neg, map_smul]
      rw [Eigen.normalized, ContinuousLinearMap.smul_apply, smul_smul, div_eq_mul_inv]
    have hv : P.grad (x (i+1)) = P.grad (x i) - h i • Eigen.normalized P (x 0) (P.grad (x i))
        + Real.sqrt (h i) • w i := by
      rw [hw]
      dsimp only [D]
      rw [hM]
      abel
    rw [hv, map_add, map_sub, map_smul, map_smul]
    change _ - h i * ((Eigen.basis P (x 0)).repr (Eigen.normalized P (x 0) (P.grad (x i))) j)
      + Real.sqrt (h i) * _ = _
    rw [Eigen.diagonal]
    dsimp only [b]
    ring
  · calc
      _ ≤ ∑ i in Finset.range n, (P.ρ*R/P.L)^2 * (h i*‖P.grad (x i)‖^2) := by
        apply Finset.sum_le_sum
        intro i hi
        have hin := Finset.mem_range.mp hi
        have hpos := hh i hin
        by_cases hz : h i = 0
        · simp [w, hz]
        have hs := Real.sqrt_pos.2 (lt_of_le_of_ne hpos (Ne.symm hz))
        have hsq := Real.sq_sqrt hpos
        have hw : ‖w i‖ ≤ (P.ρ*R/P.L)*Real.sqrt (h i)*‖P.grad (x i)‖ := by
          dsimp only [w]
          rw [norm_smul_of_nonneg (inv_nonneg.mpr hs.le)]
          calc
            _ ≤ (Real.sqrt (h i))⁻¹*(P.ρ*R*‖s i‖) :=
              mul_le_mul_of_nonneg_left (hd i hin) (inv_nonneg.mpr hs.le)
            _ = _ := by
              rw [hdis i hin, norm_neg, norm_smul_of_nonneg (div_nonneg hpos P.L_pos.le)]
              have cancel : (Real.sqrt (h i))⁻¹ * h i = Real.sqrt (h i) := by
                calc
                  _ = (Real.sqrt (h i))⁻¹ * (Real.sqrt (h i) * Real.sqrt (h i)) :=
                    congrArg (fun t : ℝ => (Real.sqrt (h i))⁻¹ * t) (by simpa only [pow_two] using hsq.symm)
                  _ = _ := by rw [← mul_assoc, inv_mul_cancel hs.ne', one_mul]
              calc
                _ = (P.ρ*R/P.L)*((Real.sqrt (h i))⁻¹*h i)*‖P.grad (x i)‖ := by ring
                _ = _ := by rw [cancel]
        calc
          _ ≤ ((P.ρ*R/P.L)*Real.sqrt (h i)*‖P.grad (x i)‖)^2 :=
            pow_le_pow_left (norm_nonneg _) hw 2
          _ = _ := by rw [mul_pow, mul_pow, hsq]; ring
      _ = (P.ρ*R/P.L)^2 * (∑ i in Finset.range n, h i*‖P.grad (x i)‖^2) := by rw [Finset.mul_sum]
      _ ≤ _ := mul_le_mul_of_nonneg_left henergy (sq_nonneg _)

end GDProof.Forcing
