import GDProof.Schedule

/-! Concrete size estimates for the recursive guarded schedule. On a dyadic
range the sum of the squared gcds admits an exact recurrence by parity. This
gives the total inserted length without a valuation-counting lemma. -/

namespace GDProof.GuardSizes
open GDProof.Schedule Finset

private theorem split_pairs (n : ℕ) (f : ℕ → ℕ) :
    ∑ j ∈ range (2*n), f j = ∑ j ∈ range n, (f (2*j) + f (2*j+1)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show 2 * (n+1) = (2*n+1)+1 by omega, sum_range_succ, sum_range_succ, ih,
      sum_range_succ]
    omega

def gcdMass (k : ℕ) : ℕ :=
  ∑ j ∈ range (2^k), (Nat.gcd (2^k) (j+1))^2

theorem gcdMass_succ (k : ℕ) : gcdMass (k+1) = 2^k + 4*gcdMass k := by
  unfold gcdMass
  conv_lhs => rw [pow_succ', split_pairs]
  have hpair (j : ℕ) :
      (Nat.gcd (2 * 2^k) (2*j+1))^2 + (Nat.gcd (2 * 2^k) (2*j+1+1))^2 =
      1 + 4 * (Nat.gcd (2^k) (j+1))^2 := by
    have ho : Odd (2*j+1) := ⟨j, rfl⟩
    have hc := (Nat.coprime_two_left.mpr ho).pow_left (k+1)
    rw [pow_succ'] at hc
    rw [hc.gcd_eq_one, show 2*j+1+1 = 2*(j+1) by omega, Nat.gcd_mul_left]
    ring
  simp only [hpair, sum_add_distrib, ← mul_sum, sum_const, card_range, smul_eq_mul, mul_one]

/-- Exact second moment of gcd(n,j+1), for 0 ≤ j < n and n = 2^k. -/
theorem gcdMass_exact (k : ℕ) : 2*gcdMass k + 2^k = 3*(2^k)^2 := by
  induction k with
  | zero => decide
  | succ k ih =>
    rw [gcdMass_succ, pow_succ]
    nlinarith only [ih]

theorem guard_quarter {n : ℕ} (hn : 0 < n) (j : ℕ) : 4 * guardSize n j ≤ n := by
  apply Nat.le_of_mul_le_mul_right (c := n) _ hn
  calc
    4 * guardSize n j * n = guardSize n j * (4*n) := by ring
    _ ≤ (Nat.gcd n (j+1))^2 := Nat.div_mul_le_self _ _
    _ ≤ n*n := by
      rw [pow_two]
      have hg := Nat.le_of_dvd hn (Nat.gcd_dvd_left n (j+1))
      exact Nat.mul_le_mul hg hg

/-- The natural-division implementation selects exactly the manuscript's two
cases. Every positive guard refers to an earlier constructed dyadic table. -/
theorem guard_cases (k j : ℕ) :
    (guardSize (2^k) j = 0 ∧ (Nat.gcd (2^k) (j+1))^2 < 4*2^k) ∨
    ∃ e < k, guardSize (2^k) j = 2^e ∧
      (Nat.gcd (2^k) (j+1))^2 = 4*2^k*guardSize (2^k) j ∧
      history k (guardSize (2^k) j) = table e := by
  obtain ⟨l, hl, hq⟩ := (Nat.dvd_prime_pow Nat.prime_two).mp (Nat.gcd_dvd_left (2^k) (j+1))
  have hden : (4 : ℕ)*2^k = 2^(k+2) := by rw [pow_add]; ring
  have hnum : (Nat.gcd (2^k) (j+1))^2 = 2^(l*2) := by rw [hq, pow_mul]
  by_cases h : k+2 ≤ l*2
  · have he : l*2-(k+2) < k := by omega
    have hr : guardSize (2^k) j = 2^(l*2-(k+2)) := by
      rw [guardSize, hnum, hden, Nat.pow_div h Nat.two_pos]
    refine Or.inr ⟨_, he, hr, ?_, ?_⟩
    · rw [hnum, hden, hr, ← pow_add]
      congr 1
      omega
    · rw [hr, history_at he]
  · have hlt : (Nat.gcd (2^k) (j+1))^2 < 4*2^k := by
      rw [hnum, hden]
      exact pow_lt_pow_right (by decide : 1 < (2 : ℕ)) (by omega)
    exact Or.inl ⟨Nat.div_eq_of_lt hlt, hlt⟩

/-- The sum of the sizes of all single-side guard copies is at most 3n/8. -/
theorem guard_sum (k : ℕ) : 8*(∑ j ∈ range (2^k), guardSize (2^k) j) ≤ 3*2^k := by
  let n : ℕ := 2^k
  have hn : 0 < n := by dsimp [n]; positivity
  have hsum : (∑ j ∈ range n, guardSize n j) * (4*n) ≤ gcdMass k := by
    rw [sum_mul]
    apply sum_le_sum
    intro j _
    exact Nat.div_mul_le_self _ _
  have hex : 2*gcdMass k+n = 3*n^2 := gcdMass_exact k
  change 8*(∑ j ∈ range n, guardSize n j) ≤ 3*n
  apply Nat.le_of_mul_le_mul_right (c := n) _ hn
  nlinarith only [hsum, hex]

/-- Squared guard masses are controlled by the first moment and the largest
individual guard. This suffices for the table's mass bound. -/
theorem guard_sq_sum (k : ℕ) :
    32*(∑ j ∈ range (2^k), (guardSize (2^k) j)^2) ≤ 3*(2^k)^2 := by
  let n : ℕ := 2^k
  have hn : 0 < n := by dsimp [n]; positivity
  have hsq : 4*(∑ j ∈ range n, (guardSize n j)^2) ≤
      (∑ j ∈ range n, guardSize n j)*n := by
    rw [mul_sum, sum_mul]
    apply sum_le_sum
    intro j _
    have hj := Nat.mul_le_mul_left (guardSize n j) (guard_quarter hn j)
    nlinarith only [hj]
  have hsum := Nat.mul_le_mul_right n (guard_sum k)
  change 8*(∑ j ∈ range n, guardSize n j)*n ≤ 3*n*n at hsum
  change 32*(∑ j ∈ range n, (guardSize n j)^2) ≤ 3*n^2
  nlinarith only [hsq, hsum]

private theorem splice_length (previous : ℕ → List ℝ) (n : ℕ)
    (h : ∀ r, (previous r).length ≤ 4*r) (j : ℕ) (as : List ℝ) :
    (splice previous n j as).length ≤ as.length +
      8*(∑ i ∈ range as.length, guardSize n (j+i)) := by
  induction as generalizing j with
  | nil => simp [splice]
  | cons a as ih =>
    simp only [splice, List.length_append, List.length_cons, sum_range_succ', Nat.add_zero]
    have ht := ih (j+1)
    simp_rw [Nat.add_assoc, Nat.add_comm 1] at ht
    have hp := h (guardSize n j)
    omega

private theorem splice_sum (previous : ℕ → List ℝ) (n : ℕ)
    (h : ∀ r, (previous r).sum ≤ 2*(r : ℝ)^2) (j : ℕ) (as : List ℝ) :
    (splice previous n j as).sum ≤ as.sum +
      4*(∑ i ∈ range as.length, (guardSize n (j+i) : ℝ)^2) := by
  induction as generalizing j with
  | nil => simp [splice]
  | cons a as ih =>
    simp only [splice, List.sum_append, List.sum_cons, List.length_cons, sum_range_succ',
      Nat.add_zero]
    have ht := ih (j+1)
    simp_rw [Nat.add_assoc, Nat.add_comm 1] at ht
    linarith only [h (guardSize n j), ht]

/-- At every stored key the table contains at most four times its key's
number of entries and has real mass at most twice the squared key. -/
theorem history_bounds (k : ℕ) (n : ℕ) :
    (history k n).length ≤ 4*n ∧ (history k n).sum ≤ 2*(n : ℝ)^2 := by
  induction k generalizing n with
  | zero =>
    simp [history]
  | succ k ih =>
    by_cases he : n = 2^k
    · subst n
      simp only [history, if_pos rfl, if_true]
      constructor
      · have h := splice_length (history k) (2^k) (fun r => (ih r).1) 0 (raw k)
        simp only [raw_length, Nat.zero_add] at h
        have hguards := guard_sum k
        omega
      · have h := splice_sum (history k) (2^k) (fun r => (ih r).2) 0 (raw k)
        simp only [raw_length, raw_sum, Nat.zero_add] at h
        have hsq := guard_sq_sum k
        have hr : (32 : ℝ) * (∑ j ∈ range (2^k), (guardSize (2^k) j : ℝ)^2) ≤
            3*((2 : ℝ)^k)^2 := by exact_mod_cast hsq
        push_cast
        have hn : (1 : ℝ) ≤ 2^k := one_le_pow_of_one_le (by norm_num) _
        nlinarith only [h, hr, hn, sq_nonneg ((2 : ℝ)^k-1)]
    · simpa only [history, if_neg he] using ih n

theorem table_length (k : ℕ) : (table k).length ≤ 4*2^k := (history_bounds (k+1) _).1

theorem table_mass (k : ℕ) : (table k).sum ≤ 2*((2 : ℝ)^k)^2 := by
  have h := (history_bounds (k+1) (2^k)).2
  simpa only [table, Nat.cast_pow, Nat.cast_ofNat] using h

private theorem children_upper (w : List ℝ) (M : ℝ) (hM : 2 ≤ 4*M)
    (hl : ∀ a ∈ w, (1 : ℝ) ≤ a) (hu : ∀ a ∈ w, a ≤ M) :
    ∀ a ∈ children w, a ≤ 4*M := by
  induction w with
  | nil => simp [children]
  | cons a w ih =>
    intro x hx
    simp only [children, List.mem_cons] at hx
    have ha := hl a (by simp)
    have hb := hu a (by simp)
    rcases hx with rfl | rfl | hx
    · exact (small_bounds ha).2.trans hM
    · unfold large
      linarith [(small_bounds ha).1]
    · exact ih (fun b hb => hl b (by simp [hb])) (fun b hb => hu b (by simp [hb])) x hx

private theorem tail_upper (k : ℕ) : ∀ a ∈ rawTail k, a ≤ ((2 : ℝ)^k)^2/2 := by
  induction k with
  | zero => simp [rawTail]
  | succ k ih =>
    intro a ha
    have hn : (1 : ℝ) ≤ 2^k := one_le_pow_of_one_le (by norm_num) _
    have hb : (2 : ℝ) ≤ 4*(((2 : ℝ)^k)^2/2) := by nlinarith [sq_nonneg ((2 : ℝ)^k-1)]
    simp only [rawTail, List.mem_cons] at ha
    rw [pow_succ (2 : ℝ) k]
    rcases ha with rfl | ha
    · linarith
    · nlinarith only [children_upper (rawTail k) _ hb (rawTail_lower k) ih a ha]

private theorem splice_upper (previous : ℕ → List ℝ) (n j : ℕ) (w : List ℝ) (M : ℝ)
    (h : ∀ k a, a ∈ previous (guardSize n k) → a ≤ M)
    (hw : ∀ a ∈ w, a ≤ M) : ∀ a ∈ splice previous n j w, a ≤ M := by
  induction w generalizing j with
  | nil => simp [splice]
  | cons a w ih =>
    intro x hx
    simp only [splice, List.mem_append, List.mem_cons] at hx
    rcases hx with hx | rfl | hx | hx
    · exact h j _ hx
    · exact hw x (by simp)
    · exact h j _ hx
    · exact ih (j+1) (fun b hb => hw b (by simp [hb])) x hx

theorem history_step_upper (k n : ℕ) :
    ∀ a ∈ history k n, a ≤ max 1 ((n : ℝ)^2/2) := by
  induction k generalizing n with
  | zero => simp [history]
  | succ k ih =>
    by_cases he : n = 2^k
    · subst n
      simp only [history, if_pos rfl, if_true]
      apply splice_upper
      · intro j a ha
        apply (ih _ a ha).trans
        apply max_le_max_left
        have hj := guard_quarter (by positivity : 0 < (2 : ℕ)^k) j
        have hr : guardSize (2^k) j ≤ 2^k := by omega
        have hc : (guardSize (2^k) j : ℝ) ≤ ((2^k : ℕ) : ℝ) := by exact_mod_cast hr
        gcongr
      · intro a ha
        rcases List.mem_cons.mp ha with rfl | ha
        · exact le_max_left _ _
        · apply (tail_upper k a ha).trans
          push_cast
          exact le_max_right _ _
    · simpa only [history, if_neg he] using ih n

/-- Every coefficient, including inserted coefficients, obeys the maximum
step bound used in the nonlinear epoch estimate. -/
theorem table_step_upper (k : ℕ) {a : ℝ} (ha : a ∈ table (k+1)) :
    a ≤ ((2 : ℝ)^(k+1))^2/2 := by
  have hh := history_step_upper (k+2) (2^(k+1)) a ha
  push_cast at hh
  have hn : (1 : ℝ) ≤ 2^k := one_le_pow_of_one_le (by norm_num) _
  have h : (1 : ℝ) ≤ ((2 : ℝ)^(k+1))^2/2 := by rw [pow_succ (2 : ℝ) k]; nlinarith [sq_nonneg ((2 : ℝ)^k-1)]
  rwa [max_eq_right h] at hh

end GDProof.GuardSizes
