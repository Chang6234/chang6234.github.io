import GDProof.Degree

/-! Conversion from the dyadic degree bound to the real-power complexity rate. -/

namespace GDProof.Scale

noncomputable section

def target (L ρ ε : ℝ) : ℝ := (L ^ 2 / (ρ * ε)) ^ (1 / 4 : ℝ)

def degree (L ρ ε : ℝ) : ℝ :=
  (2 : ℝ) ^ Degree.exponent (max 1 (target L ρ ε))

def weightedGap (L ρ ε Δ : ℝ) : ℝ :=
  Δ * Real.sqrt L * ρ ^ (1 / 4 : ℝ) * ε ^ (-(7 / 4 : ℝ))

theorem target_eq {L ρ ε : ℝ} (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε) :
    target L ρ ε = Real.sqrt L / (ρ ^ (1 / 4 : ℝ) * ε ^ (1 / 4 : ℝ)) := by
  rw [target, Real.div_rpow (sq_nonneg L) (mul_nonneg hρ.le hε.le), Real.mul_rpow hρ.le hε.le,
    ← Real.rpow_two, ← Real.rpow_mul hL.le, Real.sqrt_eq_rpow,
    show (2 : ℝ) * (1 / 4) = 1 / 2 by norm_num]

theorem target_fourth {L ρ ε : ℝ} (hρ : 0 < ρ) (hε : 0 < ε) :
    target L ρ ε ^ 4 = L ^ 2 / (ρ * ε) := by
  rw [target, ← Real.rpow_natCast, ← Real.rpow_mul (div_nonneg (sq_nonneg L) (mul_nonneg hρ.le hε.le))]
  norm_num

theorem scale_identity {L ρ ε Δ : ℝ} (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε) :
    L * Δ / ε ^ 2 = target L ρ ε * weightedGap L ρ ε Δ := by
  have hr := (Real.rpow_pos_of_pos hρ (1 / 4)).ne'
  have he := (Real.rpow_pos_of_pos hε (1 / 4)).ne'
  have hpow : ε ^ (-(7 / 4 : ℝ)) * ε ^ 2 = ε ^ (1 / 4 : ℝ) := by
    rw [← Real.rpow_two, ← Real.rpow_add hε]
    norm_num
  apply (div_eq_iff (pow_ne_zero 2 hε.ne')).2
  rw [target_eq hL hρ hε, weightedGap]
  calc
    L * Δ = (Real.sqrt L) ^ 2 * Δ := by rw [Real.sq_sqrt hL.le]
    _ = (Real.sqrt L) ^ 2 * Δ * (ε ^ (-(7 / 4 : ℝ)) * ε ^ 2) / ε ^ (1 / 4 : ℝ) := by
      rw [hpow]
      field_simp
    _ = _ := by
      generalize Real.sqrt L = a
      field_simp [hr, he]
      ring

theorem degree_bounds (L ρ ε : ℝ) :
    degree L ρ ε ≤ max 1 (target L ρ ε) ∧ target L ρ ε ≤ 2 * degree L ρ ε := by
  obtain ⟨hlo, hhi⟩ := Degree.exponent_bounds (max 1 (target L ρ ε)) (le_max_left _ _)
  exact ⟨hlo, (le_max_right _ _).trans hhi⟩

/-- For a single-entry table the ordinary GD gap bound already has the claimed rate. -/
theorem unit_rate {L ρ ε Δ : ℝ} (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε)
    (hΔ : 0 ≤ Δ) (hm : degree L ρ ε = 1) :
    L * Δ / ε ^ 2 ≤ 2 * weightedGap L ρ ε Δ := by
  rw [scale_identity hL hρ hε]
  apply mul_le_mul_of_nonneg_right _ (by unfold weightedGap; positivity)
  simpa [hm] using (degree_bounds L ρ ε).2

/-- The two degree regimes obey one uniform estimate, with constant two. -/
theorem selected_rate {L ρ ε Δ : ℝ} (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε)
    (hΔ : 0 ≤ Δ) :
    1 + degree L ρ ε + L * Δ / (ε ^ 2 * degree L ρ ε) ≤
      2 * (1 + target L ρ ε + weightedGap L ρ ε Δ) := by
  obtain ⟨hlo, hhi⟩ := degree_bounds L ρ ε
  have hm : 0 < degree L ρ ε := by unfold degree; positivity
  have ht : 0 ≤ target L ρ ε := by unfold target; positivity
  have hw : 0 ≤ weightedGap L ρ ε Δ := by unfold weightedGap; positivity
  have hm' : degree L ρ ε ≤ 1 + target L ρ ε :=
    hlo.trans (max_le (by linarith) (by linarith))
  have hcost : L * Δ / (ε ^ 2 * degree L ρ ε) ≤ 2 * weightedGap L ρ ε Δ := by
    rw [← div_div, scale_identity hL hρ hε]
    apply (div_le_iff hm).2
    calc
      _ ≤ (2 * degree L ρ ε) * weightedGap L ρ ε Δ := mul_le_mul_of_nonneg_right hhi hw
      _ = _ := by ring
  linarith

end
end GDProof.Scale
