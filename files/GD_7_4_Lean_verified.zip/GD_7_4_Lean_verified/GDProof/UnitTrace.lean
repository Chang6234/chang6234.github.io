import GDProof.Model

namespace GDProof.UnitTrace

noncomputable section
open GDProof.Model

variable {V : Type*} [NormedAddCommGroup V] [InnerProductSpace ℝ V]

private theorem active_square {ε : ℝ} (hε : 0 < ε) {g : V} (h : ε < ‖g‖) :
    0 < ‖g‖ ^ 2 ∧ ε ^ 2 < ‖g‖ ^ 2 := by
  have hp : 0 < ‖g‖ := lt_trans hε h
  constructor
  · positivity
  · nlinarith [mul_pos (sub_pos.mpr h) (add_pos hp hε)]

/-- On a nonterminal step with a unit table the cap is the current squared
gradient norm. The next active state starts a fresh epoch with a valid budget. -/
theorem unit_step (g : V → V) (L ε E : ℝ) (x : V)
    (hε : 0 < ε) (hactive : ε < ‖g x‖) (hE : 0 ≤ E) (hE' : E ≤ ε ^ 2 / 2) :
    ∃ s : State V, step g L ε [1] (fresh x (g x) E) = some s ∧
      s.x = x - (1 / L) • g x ∧ s.g = g s.x ∧
      (ε < ‖s.g‖ → ∃ E', 0 ≤ E' ∧ E' ≤ ε ^ 2 / 2 ∧ s = fresh s.x s.g E') := by
  obtain ⟨hq, hlt⟩ := active_square hε hactive
  have hcap : max E (‖g x‖ ^ 2) = ‖g x‖ ^ 2 := max_eq_right (by linarith)
  let y := x - (1 / L) • g x
  let newBudget := if inner (g x) (g y) < -(‖g x‖ ^ 2) / 2 then E / 2 else E
  have hbudget : 0 ≤ newBudget ∧ newBudget ≤ ε ^ 2 / 2 := by
    dsimp [newBudget]
    split <;> constructor <;> linarith
  refine ⟨advance g L ε 1 (fresh x (g x) E), ?_, ?_⟩
  · simp [step, fresh, hactive]
  · by_cases hy : ε < ‖g y‖
    · have hh : advance g L ε 1 (fresh x (g x) E) = fresh y (g y) newBudget := by
        simp only [y, one_div] at hy
        simp [advance, fresh, nextPoint, y, newBudget, hcap, clip, ne_of_gt hq, hy]
      rw [hh]
      exact ⟨rfl, rfl, fun _ => ⟨newBudget, hbudget.1, hbudget.2, rfl⟩⟩
    · have hh : advance g L ε 1 (fresh x (g x) E) =
          ⟨y, g y, 1, ‖g x‖ ^ 2, inner (g x) (g y), E, ‖g x‖ ^ 2⟩ := by
        simp only [y, one_div] at hy
        simp [advance, fresh, nextPoint, y, hcap, clip, ne_of_gt hq, hy]
      rw [hh]
      exact ⟨rfl, rfl, fun ha => (hy ha).elim⟩

/-- Any budgeted number of unit-table updates either returns a stationary
iterate or pays the smooth descent cost for every update. -/
theorem stationary_or_descent (f : V → ℝ) (g : V → V) (L ε : ℝ) (x₀ : V)
    (hL : 0 < L) (hε : 0 < ε)
    (hd : ∀ x, f (x - (1 / L) • g x) ≤ f x - ‖g x‖ ^ 2 / (2 * L)) (N : ℕ) :
    (∃ (k : ℕ) (s : State V), k ≤ N ∧
      run g L ε [1] (initial g x₀ [1] ε) k = some s ∧ ‖g s.x‖ ≤ ε) ∨
    (∃ (x : V) (E : ℝ), 0 ≤ E ∧ E ≤ ε ^ 2 / 2 ∧
      run g L ε [1] (initial g x₀ [1] ε) N = some (fresh x (g x) E) ∧
      f x + (N : ℝ) * (ε ^ 2 / (2 * L)) ≤ f x₀) := by
  induction N with
  | zero =>
    right
    refine ⟨x₀, ε ^ 2 / 2, by positivity, le_rfl, ?_, ?_⟩
    · simp [run, initial]
    · simp
  | succ n ih =>
    rcases ih with ⟨k, s, hk, hr, hs⟩ | ⟨x, E, hE, hE', hr, hfx⟩
    · exact Or.inl ⟨k, s, by omega, hr, hs⟩
    · by_cases hx : ε < ‖g x‖
      · obtain ⟨s, hs, hy, hg, hfresh⟩ := unit_step g L ε E x hε hx hE hE'
        have hr' : run g L ε [1] (initial g x₀ [1] ε) (n + 1) = some s := by
          simpa [run, hr] using hs
        by_cases hnext : ε < ‖s.g‖
        · obtain ⟨E', hp, hb, hform⟩ := hfresh hnext
          right
          refine ⟨s.x, E', hp, hb, ?_, ?_⟩
          · calc
              _ = some s := hr'
              _ = some (fresh s.x (g s.x) E') := congrArg some (by simpa only [hg] using hform)
          · have hq := (active_square hε hx).2
            have hcost : ε ^ 2 / (2 * L) ≤ ‖g x‖ ^ 2 / (2 * L) :=
              div_le_div_of_nonneg_right hq.le (by positivity)
            rw [hy, Nat.cast_succ]
            nlinarith [hd x]
        · exact Or.inl ⟨n+1, s, le_rfl, hr', by simpa only [← hg] using (le_of_not_gt hnext)⟩
      · exact Or.inl ⟨n, fresh x (g x) E, by omega, hr, le_of_not_gt hx⟩

theorem unit_terminates_by (f : V → ℝ) (g : V → V) (L ε l : ℝ) (x₀ : V)
    (hL : 0 < L) (hε : 0 < ε) (lower : ∀ x, l ≤ f x)
    (hd : ∀ x, f (x - (1 / L) • g x) ≤ f x - ‖g x‖ ^ 2 / (2 * L))
    (N : ℕ) (hN : f x₀ - l < (N : ℝ) * (ε ^ 2 / (2 * L))) :
    ∃ (k : ℕ) (s : State V), k ≤ N ∧
      run g L ε [1] (initial g x₀ [1] ε) k = some s ∧ ‖g s.x‖ ≤ ε := by
  rcases stationary_or_descent f g L ε x₀ hL hε hd N with h | ⟨x, E, _, _, _, h⟩
  · exact h
  · linarith [lower x]

end
end GDProof.UnitTrace
