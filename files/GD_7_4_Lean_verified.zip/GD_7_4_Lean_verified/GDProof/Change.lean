import GDProof.Nonlinear
import GDProof.Forcing

namespace GDProof.Nonlinear

open Finset GDProof.Prefix GDProof.Spectral GDProof.Eigen
open scoped RealInnerProductSpace BigOperators
noncomputable section

/-- The nonlinear objective change (B.2) on an actual GD prefix. The uniform
scalar bound B² controls the squared perturbation gains for these exact steps. -/
theorem gd_change {d : ℕ} (P : GDProof.Problem d) (x : ℕ → GDProof.Space d) (h : ℕ → ℝ)
    (n : ℕ) {A M B : ℝ} (hB : 0 ≤ B) (hh : ∀ i < n, 0 ≤ h i)
    (hgd : ∀ i < n, x (i+1) = x i - (h i/P.L) • P.grad (x i))
    (hmass : (∑ i ∈ range n, h i) ≤ A) (hmax : ∀ i < n, h i ≤ M)
    (hs : ∀ z, 0 < z → z ≤ 1 → Stable z (steps h n))
    (hD : ∀ z, 0 < z → z ≤ 1 → GDProof.Kernel.D z (steps h n) ≤ B^2) :
    let S := ∑ i ∈ range n, h i*‖P.grad (x i)‖^2
    let R := √(A*S)/P.L
    P.f (x n)-P.f (x 0) ≤ S/P.L*(-1+(1+2*B*(P.ρ*R/P.L))^2/2 + (P.ρ*R/P.L)*M/2) := by
  classical
  intro S R
  let τ := P.ρ*R/P.L
  let g := fun i => P.grad (x i)
  let s := fun i => x (i+1)-x i
  let J := {j : Fin d // 0 < value P (x 0) j}
  let z := fun j : J => value P (x 0) j
  let coord := fun (v : GDProof.Space d) (j : J) => (basis P (x 0)).repr v j
  have hτ : 0 ≤ τ := div_nonneg (mul_nonneg P.ρ_pos.le (div_nonneg (Real.sqrt_nonneg _) P.L_pos.le)) P.L_pos.le
  have hS : 0 ≤ S := sum_nonneg (fun i hi => mul_nonneg (hh i (mem_range.mp hi)) (sq_nonneg _))
  have hpos (j : J) : 0 < z j := j.2
  have hone (j : J) : z j ≤ 1 := (value_mem P (x 0) j).2
  obtain ⟨w,hwrec,hw⟩ := GDProof.Forcing.gd_forcing P x h n hh hgd hmass (le_rfl (a := S))
  have hwe : (∑ j : J, ∑ i ∈ range n, (coord (w i) j)^2) ≤ τ^2*S := by
    rw [sum_comm]
    exact (sum_le_sum (fun i _ => projected_energy P (x 0) (w i))).trans hw
  have hge : (∑ j : J, ∑ i ∈ range n, h i*(coord (g i) j)^2) ≤ S := by
    rw [sum_comm]
    apply sum_le_sum
    intro i hi
    rw [← mul_sum]
    exact mul_le_mul_of_nonneg_left (projected_energy P (x 0) (g i)) (hh i (mem_range.mp hi))
  have hb := transfer z h (fun j i => coord (g i) j) (fun j i => coord (w i) j)
    n hB hτ hS hpos hh (fun j => hs _ (hpos j) (hone j)) (fun j => hD _ (hpos j) (hone j))
    (fun j i hi => hwrec i hi j) hwe hge
  rw [sum_comm] at hb
  have hstep (i : ℕ) (hi : i < n) : s i = (-(h i/P.L)) • g i := by
    dsimp only [s,g]
    rw [hgd i hi,neg_smul]
    abel
  have hcurv (i : ℕ) (hi : i < n) : P.L*⟪P.hess (x 0) (s i), s i⟫_ℝ ≤
      ∑ j : J, (z j*(h i)^2)*(coord (g i) j)^2 := by
    calc
      _ = (h i)^2*⟪normalized P (x 0) (g i),g i⟫_ℝ := by
        rw [hstep i hi, map_smul, real_inner_smul_left,real_inner_smul_right]
        change _ = (h i)^2*⟪P.L⁻¹ • P.hess (x 0) (g i),g i⟫_ℝ
        rw [real_inner_smul_left]
        field_simp [P.L_pos.ne']
        <;> ring
      _ ≤ (h i)^2*∑ j : J, z j*(coord (g i) j)^2 :=
        mul_le_mul_of_nonneg_left (positive_quadratic_form P (x 0) (g i)) (sq_nonneg _)
      _ = _ := by rw [mul_sum]; apply sum_congr rfl; intro j _; ring
  have hpert (i : ℕ) (hi : i < n) : P.L*(P.ρ*R*‖s i‖^2) ≤ τ*M*(h i*‖g i‖^2) := by
    calc
      _ = (τ*h i)*(h i*‖g i‖^2) := by
        rw [hstep i hi,norm_smul,Real.norm_eq_abs,mul_pow,sq_abs]
        dsimp only [τ]
        field_simp [P.L_pos.ne']
        <;> ring
      _ ≤ _ := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left (hmax i hi) hτ)
        (mul_nonneg (hh i hi) (sq_nonneg _))
  have hag : P.L*(∑ i ∈ range n, (⟪P.hess (x 0) (s i),s i⟫_ℝ + P.ρ*R*‖s i‖^2)) ≤
      (1+2*B*τ)^2*S+τ*M*S := by
    rw [mul_sum]
    calc
      _ ≤ ∑ i ∈ range n, ((∑ j : J, (z j*(h i)^2)*(coord (g i) j)^2)
          + τ*M*(h i*‖g i‖^2)) := by
        apply sum_le_sum; intro i hi
        rw [mul_add]
        exact add_le_add (hcurv i (mem_range.mp hi)) (hpert i (mem_range.mp hi))
      _ ≤ _ := by
        rw [sum_add_distrib,← mul_sum]
        exact add_le_add_right hb _
  have hd := Frozen.gd_prefix_upper P x h n hh hgd hmass (le_rfl (a := S))
  have hhess : (∑ i ∈ range n, (⟪P.hess (x 0) (s i),s i⟫_ℝ + P.ρ*R*‖s i‖^2)) ≤
      ((1+2*B*τ)^2*S+τ*M*S)/P.L := (le_div_iff P.L_pos).2 (by rwa [mul_comm])
  calc
    _ ≤ -S/P.L + (∑ i ∈ range n, (⟪P.hess (x 0) (s i),s i⟫_ℝ + P.ρ*R*‖s i‖^2))/2 := hd
    _ ≤ -S/P.L + (((1+2*B*τ)^2*S+τ*M*S)/P.L)/2 := by linarith only [hhess]
    _ = _ := by dsimp only [τ]; ring

end
end GDProof.Nonlinear
