import GDProof.Statement
import GDProof.GuardSizes
import GDProof.Scale
import GDProof.TraceCount

namespace GDProof.Reduction

noncomputable section
open GDProof.Model

/-- An epoch starts at any x with an admissible budget. The alternatives
describe actual runs, including the last step. Values D are in units of Lf. -/
def LocalEpoch {d : ℕ} (P : Problem d) (ε : ℝ) (T : List ℝ) (c growth : ℝ) : Prop :=
  let E₀ := ε^2 / 2 * T.sum
  ∀ (x : Space d) (E : ℝ), c*E₀/2 ≤ E → E ≤ E₀ → ε < ‖P.grad x‖ →
    ∃ (j : ℕ) (u : State (Space d)), 0 < j ∧ j ≤ T.length ∧
      run P.grad P.L ε T (fresh x (P.grad x) E) j = some u ∧ u.g = P.grad u.x ∧
      (‖u.g‖ ≤ ε ∨
        ((u = fresh u.x u.g E ∧ 3*E/16 ≤ P.L * (P.f x - P.f u.x)) ∨
         (u = fresh u.x u.g (E/2) ∧ c*E₀ < E ∧ P.L * (P.f u.x - P.f x) ≤ growth*E)))

/-- Genuine local estimates imply a bound on the exact GD gradient calls
for a given table. This theorem takes no global termination premise. -/
theorem calls_from_epochs {d : ℕ} (P : Problem d) (ε : ℝ) (x₀ : Space d) (T : List ℝ)
    (c growth : ℝ) (hc : 0 < c) (hc' : c ≤ 1) (hg : 0 ≤ growth)
    (hE₀ : 0 < ε^2/2*T.sum) (localEpoch : LocalEpoch P ε T c growth) :
    ∃ (k : ℕ) (s : State (Space d)),
      run P.grad P.L ε T (initial P.grad x₀ T ε) k = some s ∧ ‖P.grad s.x‖ ≤ ε ∧
      ((k + 1 : ℕ) : ℝ) ≤ 1 + (T.length : ℝ) * (1 +
        (P.L * (P.f x₀ - sInf (Set.range P.f)) + 2*(growth+1)*(ε^2/2*T.sum)) /
          (3*c*(ε^2/2*T.sum)/32)) := by
  let E₀ := ε^2/2*T.sum
  change 0 < E₀ at hE₀
  let l := sInf (Set.range P.f)
  let valid := fun s : State (Space d) => ∃ E : ℝ, c*E₀/2 ≤ E ∧ E ≤ E₀ ∧
    s = fresh s.x (P.grad s.x) E
  let V := fun s : State (Space d) => P.L * (P.f s.x - l) + 2*(growth+1)*s.budget
  let δ := 3*c*E₀/32
  have de : 0 < δ := by dsimp only [δ]; positivity
  have pre (s : State (Space d)) (hs : valid s) : 0 ≤ V s := by
    obtain ⟨E, hlo, _, hform⟩ := hs
    have hb := congrArg State.budget hform
    change s.budget = E at hb
    have hcE : 0 < c*E₀ := mul_pos hc hE₀
    have hbudget : 0 ≤ s.budget := by linarith only [hb, hlo, hcE]
    have hx : l ≤ P.f s.x := csInf_le P.bounded ⟨s.x, rfl⟩
    have hL := P.L_pos
    have hgap := sub_nonneg.mpr hx
    dsimp only [V]
    positivity
  have init : valid (initial P.grad x₀ T ε) := by
    refine ⟨E₀, ?_, le_rfl, rfl⟩
    have hb := mul_le_mul_of_nonneg_right hc' hE₀.le
    change c * E₀ / 2 ≤ E₀
    nlinarith only [hb, show 0 ≤ E₀ from hE₀.le]
  have progress : TraceCount.EpochProgress P.grad P.L ε T T.length valid V δ := by
    intro s hs hactive
    obtain ⟨E, hlo, hhi, hform⟩ := hs
    have hb := congrArg State.budget hform
    change s.budget = E at hb
    have hgrad := congrArg State.g hform
    change s.g = P.grad s.x at hgrad
    obtain ⟨j, u, hj, hJ, hrun, hu, hout⟩ :=
      localEpoch s.x E hlo hhi (by simpa only [← hgrad] using hactive)
    refine ⟨j,u,hj,hJ,?_,?_⟩
    · calc
        _ = run P.grad P.L ε T (fresh s.x (P.grad s.x) E) j := congrArg (fun t => run P.grad P.L ε T t j) hform
        _ = _ := hrun
    · rcases hout with hstop | ⟨hkeep,hdec⟩ | ⟨hhalf,hlarge,hrise⟩
      · exact Or.inl hstop
      · right
        have hub := congrArg State.budget hkeep
        change u.budget = E at hub
        refine ⟨⟨E,hlo,hhi,by simpa only [hu] using hkeep⟩,?_⟩
        dsimp only [V, δ]
        rw [hb,hub]
        nlinarith only [hdec, hlo]
      · right
        change c * E₀ < E at hlarge
        have hub := congrArg State.budget hhalf
        change u.budget = E/2 at hub
        refine ⟨⟨E/2,by linarith only [hlarge],by linarith only [hhi, show 0 < E₀ from hE₀],
          by simpa only [hu] using hhalf⟩,?_⟩
        dsimp only [V, δ]
        rw [hb,hub]
        nlinarith only [hrise, hlarge, mul_pos hc hE₀]
  let s₀ := initial P.grad x₀ T ε
  let n := ⌊V s₀ / δ⌋₊ + 1
  have hbound : V s₀ < (n : ℝ) * δ := by
    apply (div_lt_iff de).mp
    simpa only [n, Nat.cast_add, Nat.cast_one] using Nat.lt_floor_add_one (V s₀ / δ)
  obtain ⟨k,s,hk,hr,hs⟩ := TraceCount.terminal_from_progress P.grad P.L ε T T.length
    valid V δ pre progress n s₀ init hbound
  refine ⟨k,s,hr,terminal_gradient P hr hs,?_⟩
  have hf := Nat.floor_le (div_nonneg (pre s₀ init) de.le)
  have hn : (n : ℝ) ≤ 1+V s₀/δ := by
    dsimp only [n]
    rw [Nat.cast_succ]
    linarith only [hf]
  have hk' : (k : ℝ) ≤ (T.length : ℝ) * (n : ℝ) := by exact_mod_cast hk
  have hJ : 0 ≤ (T.length : ℝ) := by positivity
  have hu := hk'.trans (mul_le_mul_of_nonneg_left hn hJ)
  change ((k+1 : ℕ) : ℝ) ≤ 1+(T.length : ℝ)*(1+V s₀/δ)
  rw [Nat.cast_succ]
  linarith only [hu]

end
end GDProof.Reduction
