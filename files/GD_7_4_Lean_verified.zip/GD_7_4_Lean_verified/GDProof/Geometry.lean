import GDProof.Scale

/-! Geometry of a budget-limited GD prefix and its selected table scale. -/
namespace GDProof.Geometry

open scoped BigOperators

/-- Length along the actual GD polygon, with mass at most A and energy at most E. -/
theorem path_length {V : Type*} [NormedAddCommGroup V] [NormedSpace ℝ V]
    (x g : ℕ → V) (h : ℕ → ℝ) (n : ℕ) {L A E : ℝ} (hL : 0 < L)
    (hh : ∀ i < n, 0 ≤ h i)
    (hgd : ∀ i < n, x (i+1) = x i - (h i/L) • g i)
    (hmass : (∑ i in Finset.range n, h i) ≤ A)
    (henergy : (∑ i in Finset.range n, h i * ‖g i‖^2) ≤ E) :
    (∑ i in Finset.range n, ‖x (i+1)-x i‖) ≤ Real.sqrt (A*E)/L := by
  let I := Finset.range n
  have hpos (i : ℕ) (hi : i ∈ I) : 0 ≤ h i := hh i (Finset.mem_range.mp hi)
  have hmass₀ : 0 ≤ ∑ i in I, h i := Finset.sum_nonneg hpos
  have hcs := Real.sum_mul_le_sqrt_mul_sqrt I (fun i => Real.sqrt (h i))
    (fun i => Real.sqrt (h i) * ‖g i‖)
  have heq₁ : (∑ i in I, Real.sqrt (h i) ^ 2) = ∑ i in I, h i :=
    Finset.sum_congr rfl (fun i hi => Real.sq_sqrt (hpos i hi))
  have heq₂ : (∑ i in I, (Real.sqrt (h i) * ‖g i‖)^2) = ∑ i in I, h i * ‖g i‖^2 :=
    Finset.sum_congr rfl (fun i hi => by rw [mul_pow, Real.sq_sqrt (hpos i hi)])
  rw [heq₁, heq₂] at hcs
  apply (le_div_iff hL).2
  calc
    (∑ i in Finset.range n, ‖x (i+1)-x i‖) * L =
        ∑ i in I, Real.sqrt (h i) * (Real.sqrt (h i) * ‖g i‖) := by
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro i hi
      have hs : x (i+1)-x i = -((h i/L) • g i) := by
        rw [hgd i (Finset.mem_range.mp hi)]
        abel
      rw [hs, norm_neg, norm_smul_of_nonneg (div_nonneg (hpos i hi) hL.le),
        ← mul_assoc (Real.sqrt (h i)), ← pow_two, Real.sq_sqrt (hpos i hi)]
      field_simp
    _ ≤ _ := hcs
    _ ≤ Real.sqrt A * Real.sqrt E :=
      mul_le_mul (Real.sqrt_le_sqrt hmass) (Real.sqrt_le_sqrt henergy)
        (Real.sqrt_nonneg _) (Real.sqrt_nonneg _)
    _ = _ := (Real.sqrt_mul (hmass₀.trans hmass) E).symm

/-- A degree of two or greater satisfies the stability restriction used by the epoch. -/
theorem selected_stability {L ρ ε : ℝ} (hL : 0 < L) (hρ : 0 < ρ) (hε : 0 < ε)
    (hm : 2 ≤ Scale.degree L ρ ε) :
    ρ * ε * Scale.degree L ρ ε ^ 4 / L ^ 2 ≤ 1 := by
  have hlo := (Scale.degree_bounds L ρ ε).1
  have htarget : 1 ≤ Scale.target L ρ ε := by
    by_contra! h
    rw [max_eq_left h.le] at hlo
    linarith
  rw [max_eq_right htarget] at hlo
  have hs := pow_le_pow_left (show 0 ≤ Scale.degree L ρ ε by linarith) hlo 4
  rw [Scale.target_fourth hρ hε] at hs
  have h := (le_div_iff (mul_pos hρ hε)).1 hs
  apply (div_le_iff (sq_pos_of_pos hL)).2
  linarith only [h, le_of_eq (mul_comm (Scale.degree L ρ ε ^ 4) (ρ*ε))]

/-- The two constants in the manuscript's scale estimate. The radius of an
executed prefix is sqrt(AE)/L. The initial cap is ε²A/2. -/
theorem epoch_scale {L ρ ε m A E H : ℝ} (hL : 0 < L) (hρ : 0 < ρ)
    (hε : 0 < ε) (hA : 0 < A) (hE : 0 ≤ E) (hM : A ≤ 2*m^2) (hH : H ≤ m^2/2)
    (hstable : ρ*ε*m^4/L^2 ≤ 1) :
    let R := Real.sqrt (A*E)/L
    let e := Real.sqrt (E/(ε^2*A/2))
    ρ*R/L*H ≤ 1/Real.sqrt 2*e ∧ m^2*(ρ*R/L) ≤ Real.sqrt 2*e := by
  dsimp only
  let e := Real.sqrt (E/(ε^2*A/2))
  have ht : 0 < Real.sqrt 2 := by positivity
  have htwo := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 2)
  have hrad : Real.sqrt (A*E) = ε*A/Real.sqrt 2*e := by
    apply (Real.sqrt_eq_iff_sq_eq (mul_nonneg hA.le hE) (by positivity)).2
    rw [mul_pow, div_pow, htwo]
    dsimp [e]
    rw [Real.sq_sqrt (by positivity)]
    field_simp [ne_of_gt hε, ne_of_gt hA]
    ring
  have hs := (div_le_iff (sq_pos_of_pos hL)).1 hstable
  have hm : (m^2*ρ*ε*A)/L^2 ≤ 2 := by
    apply (div_le_iff (sq_pos_of_pos hL)).2
    nlinarith only [mul_le_mul_of_nonneg_left hM (show 0 ≤ m^2*ρ*ε by positivity), hs]
  have hmain : m^2*(ρ*(Real.sqrt (A*E)/L)/L) ≤ Real.sqrt 2*e := by
    calc
      _ = (m^2*ρ*ε*A/L^2) * (e/Real.sqrt 2) := by rw [hrad]; ring
      _ ≤ 2 * (e/Real.sqrt 2) := mul_le_mul_of_nonneg_right hm (by positivity)
      _ = _ := by field_simp [ht.ne']; nlinarith only [congrArg (fun t : ℝ => t*e) htwo]
  refine ⟨?_, hmain⟩
  have hu := mul_le_mul_of_nonneg_left hH
    (show 0 ≤ ρ*(Real.sqrt (A*E)/L)/L by positivity)
  have hfactor : 1/Real.sqrt 2*e = Real.sqrt 2*e/2 := by
    field_simp [ht.ne']
    nlinarith only [congrArg (fun t : ℝ => t*e) htwo]
  change _ ≤ 1/Real.sqrt 2*e
  rw [hfactor]
  linarith only [hu, hmain]

end GDProof.Geometry
