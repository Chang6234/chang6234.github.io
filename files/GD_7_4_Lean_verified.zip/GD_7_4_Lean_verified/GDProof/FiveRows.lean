import Mathlib

/-! Exact rational enclosures for the five tangent evaluations in the suffix
estimate. The final Boolean consists solely of rational comparisons. -/
namespace GDProof.FiveRows

structure Interval where
  lo : ℚ
  hi : ℚ

def Contains (a : Interval) (x : ℝ) : Prop := (a.lo : ℝ) ≤ x ∧ x ≤ (a.hi : ℝ)

def point (r : ℚ) : Interval := ⟨r,r⟩
def plus (a b : Interval) : Interval := ⟨a.lo+b.lo,a.hi+b.hi⟩
def minus (a b : Interval) : Interval := ⟨a.lo-b.hi,a.hi-b.lo⟩
def times (a b : Interval) : Interval :=
  let s := a.lo*b.lo
  let t := a.lo*b.hi
  let u := a.hi*b.lo
  let v := a.hi*b.hi
  ⟨min (min s t) (min u v),max (max s t) (max u v)⟩
def quotient (a b : Interval) : Interval := times a ⟨1/b.hi,1/b.lo⟩
def absolute (a : Interval) : Interval :=
  ⟨max 0 (max a.lo (-a.hi)),max a.hi (-a.lo)⟩
def power (a : Interval) (n : ℕ) : Interval := ⟨a.lo^n,a.hi^n⟩

/-- Numerators for the Taylor polynomial through degree 41. -/
def taylor (x : ℚ) (odd : Bool) : ℚ :=
  ((List.range 21).map fun k =>
    let n := 2*k + (if odd then 1 else 0)
    (-1:ℚ)^k*x^n/(Nat.factorial n : ℚ)).sum

/-- Round outwards after adding the full Taylor remainder. Keeping a fixed
denominator here avoids exponentiating enormous intermediate rationals. -/
def trigInterval (x : ℚ) (odd : Bool) : Interval :=
  let y := taylor x odd
  let e := x^42/(Nat.factorial 42 : ℚ)
  let scale : ℚ := 1000000000000
  ⟨(⌊scale*(y-e)⌋:ℤ)/scale,(⌈scale*(y+e)⌉:ℤ)/scale⟩

def terms : List (ℕ × ℕ) := [(2,1),(8,2),(32,6),(128,20)]

/-- Enclosures of the value and the logarithmic derivative, together with
the checks ensuring that every denominator interval avoids zero. -/
abbrev State := Interval × Interval × Bool

def initialState (y : ℚ) : State :=
  let piSq := power ⟨314159/100000,314160/100000⟩ 2
  let denom := minus (point (y*y)) (quotient piSq (point 4))
  let val := minus (quotient (point (4*y*y)) piSq) (point 1)
  let deriv := quotient (point (2*y)) denom
  (val,deriv,decide (0 < y ∧ 0 < denom.lo))

def next (y : ℚ) (state : State) (dk : ℕ × ℕ) : State :=
    let d := (dk.1 : ℚ)
    let x := y/d
    let s := trigInterval x true
    let c := trigInterval x false
    let v := power (absolute (quotient s (point x))) dk.2
    let q := minus (quotient (quotient c s) (point d)) (point (1/y))
    (times state.1 v, plus state.2.1 (times (point (dk.2 : ℚ)) q),
      state.2.2 && decide (0 < x ∧ (0 < s.lo ∨ s.hi < 0)))

def atPhase (y : ℚ) : State := terms.foldl (next y) (initialState y)

def valid (t : ℚ) (paired : Bool) (ceiling : ℚ) : Bool :=
  let a := atPhase t
  let row := if paired then
      let b := atPhase (t/4)
      (times a.1 b.1, plus a.2.1 (quotient b.2.1 (point 4)), a.2.2 && b.2.2)
    else a
  row.2.2 && decide (row.1.hi < ceiling ∧ (absolute row.2.1).hi < 1/1000)

set_option maxRecDepth 100000
set_option maxHeartbeats 6000000

theorem row_one : valid (4132/1000) false (227/100) = true := by rfl
theorem row_two : valid (9358/1000) false (412/100) = true := by rfl
theorem row_three : valid (15017/1000) false (225/100) = true := by rfl
theorem row_four : valid (10206/1000) true (439/100) = true := by rfl
theorem row_five : valid (15144/1000) true (491/100) = true := by rfl

private theorem point_ok (x : ℚ) : Contains (point x) (x : ℝ) := ⟨le_rfl,le_rfl⟩

private theorem plus_ok {a b : Interval} {x y : ℝ} (h : Contains a x) (k : Contains b y) :
    Contains (plus a b) (x+y) := by
  simpa [Contains,plus] using And.intro (add_le_add h.1 k.1) (add_le_add h.2 k.2)

private theorem minus_ok {a b : Interval} {x y : ℝ} (h : Contains a x) (k : Contains b y) :
    Contains (minus a b) (x-y) := by
  simpa [Contains,minus] using And.intro (sub_le_sub h.1 k.2) (sub_le_sub h.2 k.1)

private theorem segment_mul {l x h t : ℝ} (a : l ≤ x) (b : x ≤ h) :
    min (l*t) (h*t) ≤ x*t ∧ x*t ≤ max (l*t) (h*t) := by
  rcases le_total 0 t with ht | ht
  · exact ⟨(min_le_left _ _).trans (mul_le_mul_of_nonneg_right a ht),
        (mul_le_mul_of_nonneg_right b ht).trans (le_max_right _ _)⟩
  · exact ⟨(min_le_right _ _).trans (mul_le_mul_of_nonpos_right b ht),
        (mul_le_mul_of_nonpos_right a ht).trans (le_max_left _ _)⟩

private theorem times_ok {a b : Interval} {x y : ℝ} (h : Contains a x) (k : Contains b y) :
    Contains (times a b) (x*y) := by
  obtain ⟨a0,a1⟩ := segment_mul (t:=y) h.1 h.2
  obtain ⟨b0,b1⟩ := segment_mul (t:=(a.lo:ℝ)) k.1 k.2
  obtain ⟨c0,c1⟩ := segment_mul (t:=(a.hi:ℝ)) k.1 k.2
  simp only [Contains,times,Rat.cast_min,Rat.cast_max,Rat.cast_mul]
  rw [mul_comm _ (a.lo:ℝ),mul_comm _ (a.lo:ℝ),mul_comm _ (a.lo:ℝ)] at b0 b1
  rw [mul_comm _ (a.hi:ℝ),mul_comm _ (a.hi:ℝ),mul_comm _ (a.hi:ℝ)] at c0 c1
  exact ⟨(min_le_min b0 c0).trans a0,a1.trans (max_le_max b1 c1)⟩

private theorem quotient_ok {a b : Interval} {x y : ℝ} (h : Contains a x) (k : Contains b y)
    (hd : 0 < b.lo ∨ b.hi < 0) : Contains (quotient a b) (x/y) := by
  have h' : Contains ⟨1/b.hi,1/b.lo⟩ (1/y) := by
    simp only [Contains,Rat.cast_div,Rat.cast_one]
    rcases hd with hp | hn
    · have hp' : 0 < (b.lo:ℝ) := by exact_mod_cast hp
      exact ⟨one_div_le_one_div_of_le (hp'.trans_le k.1) k.2,
        one_div_le_one_div_of_le hp' k.1⟩
    · have hn' : (b.hi:ℝ) < 0 := by exact_mod_cast hn
      exact ⟨one_div_le_one_div_of_neg_of_le hn' k.2,
        one_div_le_one_div_of_neg_of_le (k.2.trans_lt hn') k.1⟩
  simpa only [quotient,one_div,div_eq_mul_inv,one_mul] using times_ok h h'

private theorem absolute_ok {a : Interval} {x : ℝ} (h : Contains a x) :
    Contains (absolute a) |x| := by
  simp only [Contains,absolute,Rat.cast_zero,Rat.cast_max,Rat.cast_neg]
  exact ⟨max_le (abs_nonneg _) (max_le (h.1.trans (le_abs_self _))
      ((neg_le_neg h.2).trans (neg_le_abs _))),
    abs_le.mpr ⟨by linarith [le_max_right (a.hi:ℝ) (-(a.lo:ℝ)),h.1],
      h.2.trans (le_max_left _ _)⟩⟩

private theorem power_ok {a : Interval} {x : ℝ} (h : Contains a x) (ha : 0 ≤ a.lo) (n : ℕ) :
    Contains (power a n) (x^n) := by
  have h0 : 0 ≤ (a.lo : ℝ) := by exact_mod_cast ha
  simpa [Contains,power] using And.intro (pow_le_pow_left h0 h.1 n)
    (pow_le_pow_left (h0.trans h.1) h.2 n)

/-- The real Taylor enclosure required by the interval evaluation. -/
def TrigonometricEnclosures : Prop := ∀ x : ℚ, 0 < x → ∀ odd : Bool,
  Contains (trigInterval x odd) (if odd then Real.sin (x:ℝ) else Real.cos (x:ℝ))

noncomputable section

def realNext (y : ℚ) (s : ℝ × ℝ) (dk : ℕ × ℕ) : ℝ × ℝ :=
  let d := (dk.1 : ℚ)
  let x := ((y/d : ℚ) : ℝ)
  (s.1 * |Real.sin x / x| ^ dk.2,
   s.2 + ((dk.2 : ℕ):ℝ)*(Real.cos x / Real.sin x / (d:ℝ) - 1/(y:ℝ)))

/-- The two entries are H(y) and the expression for its logarithmic derivative. -/
def realPhase (y : ℚ) : ℝ × ℝ :=
  terms.foldl (realNext y)
    (4*(y:ℝ)*(y:ℝ)/Real.pi^2-1, 2*(y:ℝ)/((y:ℝ)*(y:ℝ)-Real.pi^2/4))

private def Related (s : State) (v : ℝ × ℝ) : Prop :=
    s.2.2 = true → Contains s.1 v.1 ∧ Contains s.2.1 v.2

private theorem next_ok (ht : TrigonometricEnclosures) (y : ℚ) (dk : ℕ × ℕ)
    {s : State} {v : ℝ × ℝ} (h : Related s v) :
    Related (next y s dk) (realNext y v dk) := by
  let d : ℚ := dk.1
  let x := y/d
  let si := trigInterval x true
  let co := trigInterval x false
  intro good
  change (s.2.2 && decide (0<x ∧ (0<si.lo ∨ si.hi<0))) = true at good
  have hgood := (Bool.and_eq_true_iff _ _).mp good
  obtain ⟨hx,hsafe⟩ := of_decide_eq_true hgood.2
  obtain ⟨hval,hder⟩ := h hgood.1
  have hsin : Contains si (Real.sin (x:ℝ)) := ht x hx true
  have hcos : Contains co (Real.cos (x:ℝ)) := ht x hx false
  have hd : 0 < d := by
    change 0 < (dk.1:ℚ)
    by_contra hn
    have he : (dk.1:ℚ) = 0 := le_antisymm (le_of_not_gt hn) (by positivity)
    simp [x,d,he] at hx
  have h1 := quotient_ok hsin (point_ok x) (Or.inl hx)
  have h2 := power_ok (absolute_ok h1) (le_max_left _ _) dk.2
  have h3 := quotient_ok (quotient_ok hcos hsin hsafe) (point_ok d) (Or.inl hd)
  have hone : Contains (point (1/y)) (1/(y:ℝ)) := by simpa using point_ok (1/y)
  have h4 := minus_ok h3 hone
  have h5 : Contains (point (dk.2:ℚ)) (dk.2:ℝ) := by simpa using point_ok (dk.2:ℚ)
  exact ⟨times_ok hval h2,plus_ok hder (times_ok h5 h4)⟩

private theorem fold_ok (ht : TrigonometricEnclosures) (y : ℚ) (l : List (ℕ × ℕ))
    {s : State} {v : ℝ × ℝ} (h : Related s v) :
    Related (l.foldl (next y) s) (l.foldl (realNext y) v) := by
  induction l generalizing s v with
  | nil => exact h
  | cons a _ ih => exact ih (next_ok ht y a h)

theorem atPhase_ok (ht : TrigonometricEnclosures) (y : ℚ) :
    (atPhase y).2.2 = true → Contains (atPhase y).1 (realPhase y).1 ∧
      Contains (atPhase y).2.1 (realPhase y).2 := by
  apply fold_ok ht y terms
  intro good
  let piI : Interval := ⟨314159/100000,314160/100000⟩
  have hpi : Contains piI Real.pi := by
    constructor
    · norm_num [piI]
      have h := Real.pi_gt_3141592
      norm_num at h
      linarith
    · norm_num [piI]
      have h := Real.pi_lt_3141593
      norm_num at h
      linarith
  have hs := power_ok hpi (by norm_num [piI]) 2
  let den := minus (point (y*y)) (quotient (power piI 2) (point 4))
  change decide (0<y ∧ 0<den.lo) = true at good
  have hg := of_decide_eq_true good
  have hy : Contains (point (y*y)) ((y:ℝ)*(y:ℝ)) := by simpa using point_ok (y*y)
  have hfour : Contains (point 4) (4:ℝ) := by simpa using point_ok 4
  have hden := minus_ok hy (quotient_ok hs hfour (Or.inl (by norm_num [point])))
  have hp : 0 < (power piI 2).lo := by norm_num [power,piI]
  have hy4 : Contains (point (4*y*y)) (4*(y:ℝ)*(y:ℝ)) := by simpa using point_ok (4*y*y)
  have hy2 : Contains (point (2*y)) (2*(y:ℝ)) := by simpa using point_ok (2*y)
  have hone : Contains (point 1) (1:ℝ) := by simpa using point_ok 1
  exact ⟨minus_ok (quotient_ok hy4 hs (Or.inl hp)) hone,quotient_ok hy2 hden (Or.inl hg.2)⟩

/-- For paired rows use the product of the values and the chain-rule sum
of logarithmic derivatives. -/
def realRow (t : ℚ) (paired : Bool) : ℝ × ℝ :=
  let a := realPhase t
  let b := realPhase (t/4)
  if paired then (a.1*b.1,a.2+b.2/4) else a

theorem real_bound_of_row (ht : TrigonometricEnclosures) (t cap : ℚ) (p : Bool)
    (hr : valid t p cap = true) :
    (realRow t p).1 < (cap:ℝ) ∧ |(realRow t p).2| < 1/1000 := by
  let a := atPhase t
  let b := atPhase (t/4)
  let s : State := if p then (times a.1 b.1,plus a.2.1 (quotient b.2.1 (point 4)),a.2.2 && b.2.2) else a
  change (s.2.2 && decide (s.1.hi < cap ∧ (absolute s.2.1).hi < 1/1000)) = true at hr
  have h := (Bool.and_eq_true_iff _ _).mp hr
  have hc := of_decide_eq_true h.2
  have hs : Contains s.1 (realRow t p).1 ∧ Contains s.2.1 (realRow t p).2 := by
    cases p with
    | false => exact atPhase_ok ht t h.1
    | true =>
      have hgood : (a.2.2 && b.2.2) = true := h.1
      have hab := (Bool.and_eq_true_iff _ _).mp hgood
      obtain ⟨av,ad⟩ := atPhase_ok ht t hab.1
      obtain ⟨bv,bd⟩ := atPhase_ok ht (t/4) hab.2
      have hfour : Contains (point 4) (4:ℝ) := by simpa using point_ok 4
      exact ⟨times_ok av bv,plus_ok ad (quotient_ok bd hfour (Or.inl (by norm_num [point])))⟩
  constructor
  · exact hs.1.2.trans_lt (by exact_mod_cast hc.1)
  · have hupper : ((absolute s.2.1).hi : ℝ) < ((1/1000:ℚ) : ℝ) := Rat.cast_lt.mpr hc.2
    push_cast at hupper
    exact (absolute_ok hs.2).2.trans_lt hupper

end
end GDProof.FiveRows
