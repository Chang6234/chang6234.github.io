import GDProof.Kernel

namespace GDProof.Spectral

open Finset
open scoped BigOperators
open GDProof.Kernel
noncomputable section

/-- Ordered list of the first n normalized steps of an epoch. -/
def steps (h : ℕ → ℝ) (n : ℕ) := (List.range n).map h

theorem steps_succ (h : ℕ → ℝ) (n : ℕ) :
    steps h (n + 1) = steps h n ++ [h n] := by simp [steps, List.range_succ]

/-- Only steps strictly between source s and destination i amplify the error. -/
def between (z : ℝ) (h : ℕ → ℝ) (s i : ℕ) : ℝ :=
  ∏ j ∈ Ico (s + 1) i, (1 - z * h j)

private theorem between_succ (z : ℝ) (h : ℕ → ℝ) {s i : ℕ} (hs : s < i) :
    between z h s (i + 1) = between z h s i * (1 - z * h i) :=
  prod_Ico_succ_top hs _

private theorem between_adjacent (z : ℝ) (h : ℕ → ℝ) (i : ℕ) :
    between z h i (i + 1) = 1 := by simp [between]

/-- Variation of constants for a scalar component of the gradient prediction error. -/
theorem forced_unroll (z : ℝ) (h w e : ℕ → ℝ) (n : ℕ) (h₀ : e 0 = 0)
    (hf : ∀ i < n, e (i + 1) = (1 - z * h i) * e i + √(h i) * w i) :
    e n = ∑ s ∈ range n, (√(h s) * between z h s n) * w s := by
  induction n with
  | zero => simpa using h₀
  | succ n ih =>
    rw [hf n (by omega), ih (fun i hi => hf i (by omega)), sum_range_succ, between_adjacent,
      mul_one, mul_sum]
    congr 1
    apply sum_congr rfl
    intro s hs
    rw [between_succ z h (mem_range.mp hs)]
    ring

private theorem reverse_eq (z : ℝ) (h l : ℕ → ℝ) (f : ℝ → ℝ) (n : ℕ)
    (hl : ∀ i, l i = f (h i)) :
    reverseResponse z f (steps h n) = ∑ s ∈ range n, l s * (between z h s n)^2 := by
  induction n with
  | zero => simp [steps, reverseResponse]
  | succ n ih =>
    rw [steps_succ, reverseResponse_append, ih, sum_range_succ, between_adjacent]
    simp only [product, reverseResponse, mul_one, one_pow, add_zero, factor, hl n]
    rw [sum_mul]
    congr 1
    apply sum_congr rfl
    intro s hs
    rw [between_succ z h (mem_range.mp hs)]
    ring

/-- Sum of squared matrix entries with endpoint weights l and r is exactly the
recursively defined pair sum used in the scalar kernel analysis. -/
theorem pair_entries (z : ℝ) (h : ℕ → ℝ) (l r : ℝ → ℝ) (n : ℕ) :
    pairSum z l r (steps h n) =
      ∑ i ∈ range n, ∑ s ∈ range i, l (h s) * r (h i) * (between z h s i)^2 := by
  induction n with
  | zero => simp [steps, pairSum]
  | succ n ih =>
    rw [steps_succ, pairSum_append, ih, sum_range_succ]
    simp only [pairSum, response, mul_zero, add_zero, zero_add]
    rw [reverse_eq z h (fun s => l (h s)) l n (fun _ => rfl), sum_mul]
    congr 1
    apply sum_congr rfl
    intro s _
    ring

/-- Cauchy–Schwarz applied to every causal row gives the squared Frobenius bound. -/
theorem forced_energy (z : ℝ) (h w e : ℕ → ℝ) (r : ℝ → ℝ) (n : ℕ)
    (h₀ : e 0 = 0) (hh : ∀ i < n, 0 ≤ h i) (hr : ∀ i < n, 0 ≤ r (h i))
    (hf : ∀ i < n, e (i + 1) = (1 - z * h i) * e i + √(h i) * w i) :
    (∑ i ∈ range n, r (h i) * (e i)^2) ≤
      pairSum z id r (steps h n) * ∑ s ∈ range n, (w s)^2 := by
  rw [pair_entries, sum_mul]
  apply sum_le_sum
  intro i hi
  have hin := mem_range.mp hi
  let v := fun s => √(h s) * between z h s i
  have hu : e i = ∑ s ∈ range i, v s * w s := forced_unroll z h w e i h₀
    (fun j hj => hf j (by omega))
  have hs : (∑ s ∈ range i, (w s)^2) ≤ ∑ s ∈ range n, (w s)^2 :=
    sum_le_sum_of_subset_of_nonneg (range_mono hin.le) (fun s _ _ => sq_nonneg (w s))
  have hm : r (h i) * (∑ s ∈ range i, (v s)^2) =
      ∑ s ∈ range i, id (h s) * r (h i) * (between z h s i)^2 := by
    rw [mul_sum]
    apply sum_congr rfl
    intro s hs
    dsimp [v]
    rw [mul_pow, Real.sq_sqrt (hh s (by have := mem_range.mp hs; omega))]
    ring
  rw [← hm, hu, mul_assoc]
  apply mul_le_mul_of_nonneg_left _ (hr i hin)
  exact (sum_mul_sq_le_sq_mul_sq _ v w).trans
    (mul_le_mul_of_nonneg_left hs (sum_nonneg (fun s _ => sq_nonneg (v s))))

/-- For positive normalized eigenvalues, both paper norms of the vector error
are dominated by the same scalar D bound, uniformly over eigendirections. -/
theorem spectral_transfer {ι : Type*} [Fintype ι] (z : ι → ℝ) (h : ℕ → ℝ)
    (w e : ι → ℕ → ℝ) (n : ℕ) (B : ℝ) (hz : ∀ k, 0 ≤ z k) (hh : ∀ i < n, 0 ≤ h i)
    (h₀ : ∀ k, e k 0 = 0)
    (hf : ∀ k i, i < n → e k (i + 1) = (1 - z k * h i) * e k i + √(h i) * w k i)
    (hD : ∀ k, D (z k) (steps h n) ≤ B) :
    (∑ k, ∑ i ∈ range n, h i * (e k i)^2) ≤ B * ∑ k, ∑ i ∈ range n, (w k i)^2 ∧
    (∑ k, ∑ i ∈ range n, (z k * (h i)^2) * (e k i)^2) ≤ B * ∑ k, ∑ i ∈ range n, (w k i)^2 := by
  have hn : ∀ a ∈ steps h n, 0 ≤ a := by
    intro a ha
    obtain ⟨i, hi, rfl⟩ := List.mem_map.mp ha
    exact hh i (List.mem_range.mp hi)
  have huw : ∀ k, 0 ≤ ∑ i ∈ range n, (w k i)^2 := fun k =>
    sum_nonneg (fun i _ => sq_nonneg (w k i))
  rw [mul_sum]
  constructor
  · apply sum_le_sum
    intro k _
    exact (forced_energy (z k) h (w k) (e k) id n (h₀ k) hh hh (hf k)).trans
      (mul_le_mul_of_nonneg_right (((squared_gains_le_D (hz k) _ hn).1).trans (hD k)) (huw k))
  · apply sum_le_sum
    intro k _
    exact (forced_energy (z k) h (w k) (e k) (fun a => z k * a^2) n (h₀ k) hh
      (fun i _ => mul_nonneg (hz k) (sq_nonneg (h i))) (hf k)).trans
      (mul_le_mul_of_nonneg_right (((squared_gains_le_D (hz k) _ hn).2).trans (hD k)) (huw k))

end
end GDProof.Spectral
