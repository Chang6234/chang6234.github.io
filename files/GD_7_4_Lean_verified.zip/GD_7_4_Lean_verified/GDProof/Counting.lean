import Mathlib

/-!
# Accounting for completed epochs

The value sequence in this file is in the units of the manuscript's
`L * f`. The inputs to `AnalyticBounds` are the conclusions of the
analytic epoch proposition; this file proves their counting consequences.

Our alternative proof uses a decreasing potential on both kinds of
completed epoch. It avoids rounding a base-two logarithm.
-/

namespace GDProof.Counting

/-- Finite trace of the budget test. Entries past `epochs` are irrelevant. -/
structure Ledger where
  epochs : ℕ
  budget : ℕ → ℝ
  value : ℕ → ℝ
  passes : ℕ → Prop
  keep : ∀ k, k < epochs → passes k → budget (k + 1) = budget k
  halve : ∀ k, k < epochs → ¬ passes k → budget (k + 1) = budget k / 2

/-- The three analytic guarantees for a completed epoch, with its threshold
`threshold = c * E₀` and a dimension-independent increase factor `growth`. -/
structure AnalyticBounds (t : Ledger) (threshold growth : ℝ) : Prop where
  threshold_pos : 0 < threshold
  growth_nonneg : 0 ≤ growth
  initial : threshold ≤ t.budget 0
  small_passes : ∀ k, k < t.epochs → t.budget k ≤ threshold → t.passes k
  passing_drop : ∀ k, k < t.epochs → t.passes k →
    t.value (k + 1) ≤ t.value k - 3 * t.budget k / 16
  failing_increase : ∀ k, k < t.epochs → ¬ t.passes k →
    t.value (k + 1) ≤ t.value k + growth * t.budget k

/-- Sum of the pre-halving budgets of failed epochs before time `n`. -/
noncomputable def failedBudget (t : Ledger) (n : ℕ) : ℝ := by
  classical
  exact (Finset.range n).sum (fun j => if t.passes j then 0 else t.budget j)

/-- The sum over failures telescopes exactly, irrespective of the run's length. -/
theorem failedBudget_eq (t : Ledger) (n : ℕ) (hn : n ≤ t.epochs) :
    failedBudget t n = 2 * (t.budget 0 - t.budget n) := by
  classical
  induction n with
  | zero => simp [failedBudget]
  | succ n ih =>
    have hlt : n < t.epochs := by omega
    have hprev := ih (Nat.le_of_lt hlt)
    have hrec : failedBudget t (n + 1) = failedBudget t n +
        (if t.passes n then 0 else t.budget n) := by
      simp only [failedBudget, Finset.sum_range_succ]
    by_cases hp : t.passes n
    · rw [hrec, if_pos hp, t.keep n hlt hp, hprev]
      ring
    · rw [hrec, if_neg hp, t.halve n hlt hp, hprev]
      ring

/-- A halving can cross the passing threshold at most by a factor of two. -/
theorem budget_floor {t : Ledger} {threshold growth : ℝ}
    (h : AnalyticBounds t threshold growth) (n : ℕ) (hn : n ≤ t.epochs) :
    threshold / 2 ≤ t.budget n := by
  induction n with
  | zero => linarith [h.initial, h.threshold_pos]
  | succ n ih =>
    have hlt : n < t.epochs := by omega
    by_cases hp : t.passes n
    · rw [t.keep n hlt hp]
      exact ih (Nat.le_of_lt hlt)
    · have hlarge : threshold < t.budget n :=
        lt_of_not_ge (fun hle => hp (h.small_passes n hlt hle))
      rw [t.halve n hlt hp]
      linarith

theorem failedBudget_le {t : Ledger} {threshold growth : ℝ}
    (h : AnalyticBounds t threshold growth) (n : ℕ) (hn : n ≤ t.epochs) :
    failedBudget t n ≤ 2 * t.budget 0 := by
  rw [failedBudget_eq t n hn]
  linarith [budget_floor h n hn, h.threshold_pos]

/-- Doubling the coefficient of the budget pays for objective increases
on failed tests, with positive decrease left over. -/
noncomputable def potential (t : Ledger) (growth : ℝ) (n : ℕ) : ℝ :=
  t.value n + 2 * (growth + 1) * t.budget n

theorem potential_drop {t : Ledger} {threshold growth : ℝ}
    (h : AnalyticBounds t threshold growth) (n : ℕ) (hn : n < t.epochs) :
    potential t growth (n + 1) + 3 * threshold / 32 ≤ potential t growth n := by
  unfold potential
  by_cases hp : t.passes n
  · rw [t.keep n hn hp]
    linarith [budget_floor h n (Nat.le_of_lt hn), h.passing_drop n hn hp]
  · have hlarge : threshold < t.budget n :=
      lt_of_not_ge (fun hle => hp (h.small_passes n hn hle))
    rw [t.halve n hn hp]
    nlinarith only [h.failing_increase n hn hp, hlarge, h.threshold_pos]

/-- Every completed epoch spends at least `3 * threshold / 32` of potential. -/
theorem accumulated_drop {t : Ledger} {threshold growth : ℝ}
    (h : AnalyticBounds t threshold growth) (n : ℕ) (hn : n ≤ t.epochs) :
    (n : ℝ) * (3 * threshold / 32) + potential t growth n ≤
      potential t growth 0 := by
  induction n with
  | zero => simp
  | succ n ih =>
    have hlt : n < t.epochs := by omega
    have hprev := ih (Nat.le_of_lt hlt)
    rw [Nat.cast_succ]
    nlinarith only [hprev, potential_drop h n hlt]

/-- An explicit real-valued bound for the completed epoch count from a lower
bound on the objective. Only the terminal iterate's lower bound is needed. -/
theorem epoch_count {t : Ledger} {threshold growth lower : ℝ}
    (h : AnalyticBounds t threshold growth) (hlower : lower ≤ t.value t.epochs) :
    (t.epochs : ℝ) * (3 * threshold / 32) ≤
      t.value 0 - lower + 2 * (growth + 1) * t.budget 0 := by
  have hf : 0 ≤ t.budget t.epochs := by
    linarith [budget_floor h t.epochs (le_refl _), h.threshold_pos]
  have hc : 0 ≤ 2 * (growth + 1) := by linarith [h.growth_nonneg]
  have ha := accumulated_drop h t.epochs (le_refl _)
  unfold potential at ha
  linarith [mul_nonneg hc hf]

/-- There is one initial gradient call, at most `J` updates per completed
epoch, and at most `J` in the final partial epoch. Multiplication by the
strictly positive drop gives a division-free bound valid for all `J`. -/
theorem oracle_count {t : Ledger} {threshold growth lower : ℝ}
    (h : AnalyticBounds t threshold growth) (hlower : lower ≤ t.value t.epochs)
    (J calls : ℕ) (hcalls : calls ≤ 1 + J * (t.epochs + 1)) :
    (calls : ℝ) * (3 * threshold / 32) ≤
      (1 + (J : ℝ)) * (3 * threshold / 32) +
      (J : ℝ) * (t.value 0 - lower + 2 * (growth + 1) * t.budget 0) := by
  have hw : (calls : ℝ) ≤ 1 + (J : ℝ) * ((t.epochs : ℝ) + 1) := by
    exact_mod_cast hcalls
  have hd : 0 ≤ 3 * threshold / 32 := by linarith [h.threshold_pos]
  have hj : (0 : ℝ) ≤ (J : ℝ) := by positivity
  calc
    (calls : ℝ) * (3 * threshold / 32) ≤
        (1 + (J : ℝ) * ((t.epochs : ℝ) + 1)) * (3 * threshold / 32) :=
      mul_le_mul_of_nonneg_right hw hd
    _ = (1 + (J : ℝ)) * (3 * threshold / 32) +
        (J : ℝ) * ((t.epochs : ℝ) * (3 * threshold / 32)) := by ring
    _ ≤ _ := add_le_add_left (mul_le_mul_of_nonneg_left (epoch_count h hlower) hj) _


/-- An unbroken sequence of clipped GD updates must reach the cap or a
stationary input gradient within one table. The assumption on `cap` follows
from `cap = E ≤ E₀ = ε² * A / 2` when the epoch uses the budget cap.
`sqNorm` records the squared norm of the gradient at each input iterate. -/
theorem table_reaches_cap_or_stationary (J : ℕ) (b sqNorm S : ℕ → ℝ)
    (ε cap : ℝ) (hS : S 0 = 0) (hb : ∀ i, i < J → 0 ≤ b i)
    (hcover : cap ≤ ε ^ 2 * (Finset.range J).sum b)
    (hupdate : ∀ i, i < J → S (i + 1) =
        S i + min (b i) ((cap - S i) / sqNorm i) * sqNorm i) :
    (∃ i, i < J ∧ sqNorm i ≤ ε ^ 2) ∨ (∃ k, k ≤ J ∧ cap ≤ S k) := by
  by_cases hstop : ∃ i, i < J ∧ sqNorm i ≤ ε ^ 2
  · exact Or.inl hstop
  right
  by_contra hcap
  have hgrad (i : ℕ) (hi : i < J) : ε ^ 2 < sqNorm i :=
    lt_of_not_ge (fun hh => hstop ⟨i, hi, hh⟩)
  have hfull (i : ℕ) (hi : i < J) :
      min (b i) ((cap - S i) / sqNorm i) = b i := by
    by_cases hle : b i ≤ (cap - S i) / sqNorm i
    · exact min_eq_left hle
    · have hq : 0 < sqNorm i := lt_of_le_of_lt (sq_nonneg ε) (hgrad i hi)
      have he := hupdate i hi
      rw [min_eq_right (le_of_lt (lt_of_not_ge hle))] at he
      have hhit : S (i + 1) = cap := by
        calc
          S (i + 1) = S i + ((cap - S i) / sqNorm i) * sqNorm i := he
          _ = cap := by field_simp [ne_of_gt hq]
      exact False.elim (hcap ⟨i + 1, by omega, le_of_eq hhit.symm⟩)
  have hsum (k : ℕ) (hk : k ≤ J) :
      S k = (Finset.range k).sum (fun i => b i * sqNorm i) := by
    induction k with
    | zero => simpa using hS
    | succ k ih =>
      have hlt : k < J := by omega
      rw [hupdate k hlt, hfull k hlt, ih (Nat.le_of_lt hlt), Finset.sum_range_succ]
  have hlow : ε ^ 2 * (Finset.range J).sum b ≤
      (Finset.range J).sum (fun i => b i * sqNorm i) := by
    rw [Finset.mul_sum]
    apply Finset.sum_le_sum
    intro i hi
    have hlt := Finset.mem_range.mp hi
    rw [mul_comm (ε ^ 2)]
    exact mul_le_mul_of_nonneg_left (le_of_lt (hgrad i hlt)) (hb i hlt)
  exact hcap ⟨J, le_refl _, (hcover.trans hlow).trans (le_of_eq (hsum J (le_refl _)).symm)⟩

/-- When the initial squared gradient exceeds the budget, the unit first
entry spends the full gradient-defined cap in one update. -/
theorem first_step_spends_large_cap {E q : ℝ} (hE : E ≤ q) (hq : 0 < q) :
    min (1 : ℝ) ((max E q - 0) / q) * q = max E q := by
  simp [max_eq_right hE, ne_of_gt hq]

/-- Substituting the table length and initial mass yields the manuscript's
intermediate complexity bound, with explicit constants. Here `gap` is an
upper bound for `L * (f x₀ - inf f)`. -/
theorem table_oracle_count {t : Ledger} {c growth lower gap ε m : ℝ}
    (h : AnalyticBounds t (c * t.budget 0) growth)
    (hlower : lower ≤ t.value t.epochs) (hgap : t.value 0 - lower ≤ gap)
    (hc : 0 < c) (hgap0 : 0 ≤ gap) (hε : 0 < ε) (hm : 0 < m)
    (hmass : ε ^ 2 * m ^ 2 ≤ 3 * t.budget 0)
    (J calls : ℕ) (hJ : (J : ℝ) ≤ 4 * m)
    (hcalls : calls ≤ 1 + J * (t.epochs + 1)) :
    (calls : ℝ) ≤ 1 + 4 * m + 128 / (3 * c) *
      (3 * gap / (ε ^ 2 * m) + 2 * (growth + 1) * m) := by
  let B := 3 * gap / (ε ^ 2 * m) + 2 * (growth + 1) * m
  let d := 3 * (c * t.budget 0) / 32
  have hd : 0 < d := by dsimp [d]; linarith [h.threshold_pos]
  have hE : 0 ≤ t.budget 0 := by linarith [h.initial, h.threshold_pos]
  have hg : 0 ≤ growth + 1 := by linarith [h.growth_nonneg]
  have hG : 0 ≤ gap + 2 * (growth + 1) * t.budget 0 := by positivity
  have hcost : m * gap ≤ 3 * gap / (ε ^ 2 * m) * t.budget 0 := by
    calc
      m * gap = gap / (ε ^ 2 * m) * (ε ^ 2 * m ^ 2) := by
        field_simp [ne_of_gt hε, ne_of_gt hm] <;> ring
      _ ≤ gap / (ε ^ 2 * m) * (3 * t.budget 0) :=
        mul_le_mul_of_nonneg_left hmass (by positivity)
      _ = _ := by ring
  have hB : m * (gap + 2 * (growth + 1) * t.budget 0) ≤ B * t.budget 0 := by
    dsimp [B]
    nlinarith only [hcost]
  have hbudget := oracle_count h hlower J calls hcalls
  change (calls : ℝ) * d ≤ (1 + (J : ℝ)) * d +
    (J : ℝ) * (t.value 0 - lower + 2 * (growth + 1) * t.budget 0) at hbudget
  have hj0 : (0 : ℝ) ≤ J := by positivity
  have h1 := mul_le_mul_of_nonneg_right (add_le_add_left hJ 1) (le_of_lt hd)
  have h2 := mul_le_mul_of_nonneg_right hJ hG
  have h3 := mul_le_mul_of_nonneg_left (add_le_add_right hgap
    (2 * (growth + 1) * t.budget 0)) hj0
  have huv : (calls : ℝ) * d ≤ (1 + 4 * m) * d + 4 * (B * t.budget 0) := by
    nlinarith only [hbudget, h1, h2, h3, hB]
  change (calls : ℝ) ≤ 1 + 4 * m + 128 / (3 * c) * B
  by_contra! hnot
  have hbad := mul_lt_mul_of_pos_right hnot hd
  have hid : (1 + 4 * m + 128 / (3 * c) * B) * d =
      (1 + 4 * m) * d + 4 * (B * t.budget 0) := by
    dsimp [d]
    field_simp [ne_of_gt hc] <;> ring
  rw [hid] at hbad
  exact (not_lt_of_ge huv) hbad

/-- Fourth-root parametrization: take `L = a²`, `ρ = b⁴` and `ε = u⁴` for
positive roots `a, b, u`. Then `a/(b*u)` is the target table size. A dyadic
degree within a factor of two already gives the exponent `−7/4`. -/
theorem fourth_root_rate {a b u m Δ : ℝ}
    (ha : 0 < a) (hb : 0 < b) (hu : 0 < u) (hm : 0 < m) (hΔ : 0 ≤ Δ)
    (hdegree : a / (b * u) ≤ 2 * m) :
    Δ * a ^ 2 / ((u ^ 4) ^ 2 * m) ≤ 2 * Δ * a * b / u ^ 7 := by
  have hscale : a ≤ (2 * m) * (b * u) := by
    calc
      a = (a / (b * u)) * (b * u) := by
        field_simp [ne_of_gt hb, ne_of_gt hu]
      _ ≤ _ := mul_le_mul_of_nonneg_right hdegree (by positivity)
  calc
    Δ * a ^ 2 / ((u ^ 4) ^ 2 * m) =
        (Δ * a / ((u ^ 4) ^ 2 * m)) * a := by ring
    _ ≤ (Δ * a / ((u ^ 4) ^ 2 * m)) * ((2 * m) * (b * u)) :=
      mul_le_mul_of_nonneg_left hscale (by positivity)
    _ = _ := by
      field_simp [ne_of_gt hu, ne_of_gt hm]
      ring

end GDProof.Counting
