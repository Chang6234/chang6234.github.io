import GDProof.Suffix

/-! The phase argument of Appendix A.2. The analytic data that must be supplied
are stated separately from their assembly. The main asymptotic theorem in
GDProof.Main uses the independent unconditional suffix theorem in GDProof.Suffix. -/

namespace GDProof.SuffixAssembly
open Set
open scoped Real
noncomputable section

/-- Data at one tangent point in a positive lobe, including its log-concavity. -/
structure TangentRow (f : ℝ → ℝ) (l r t v : ℝ) : Prop where
  center : t ∈ Icc l r
  positive : 0 < f t
  value : f t ≤ v
  concave : ConcaveOn ℝ {x | x ∈ Icc l r ∧ 0 < f x} (fun x => Real.log (f x))
  derivative : ∃ d : ℝ, |d| ≤ (1 / 1000 : ℝ) ∧ HasDerivAt (fun x => Real.log (f x)) d t

/-- A row with pointwise value and derivative bounds controls the entire lobe,
including endpoints at which the function vanishes. -/
theorem TangentRow.bound {f : ℝ → ℝ} {l r t v y : ℝ} (h : TangentRow f l r t v)
    (hy : y ∈ Icc l r) (hdist : |y - t| ≤ 7) : f y ≤ (1008 / 1000 : ℝ) * v := by
  have hv : 0 ≤ v := h.positive.le.trans h.value
  by_cases hp : 0 < f y
  · obtain ⟨d,hd,hder⟩ := h.derivative
    have ht' : t ∈ {x | x ∈ Icc l r ∧ 0 < f x} := ⟨h.center,h.positive⟩
    have hy' : y ∈ {x | x ∈ Icc l r ∧ 0 < f x} := ⟨hy,hp⟩
    have hs : Real.log (f y) - Real.log (f t) ≤ d * (y-t) := by
      rcases lt_trichotomy t y with hlt | rfl | hgt
      · have q := h.concave.slope_le_of_hasDerivAt ht' hy' hlt hder
        rw [slope_def_field] at q
        exact (div_le_iff (sub_pos.mpr hlt)).mp q
      · simp
      · have q := h.concave.le_slope_of_hasDerivAt hy' ht' hgt hder
        rw [slope_def_field] at q
        have q' := (le_div_iff (sub_pos.mpr hgt)).mp q
        linarith
    have hsmall : d * (y-t) ≤ (7 / 1000 : ℝ) := by
      calc
        _ ≤ |d * (y-t)| := le_abs_self _
        _ = |d| * |y-t| := abs_mul _ _
        _ ≤ ((1 / 1000 : ℝ):ℝ) * 7 := mul_le_mul hd hdist (abs_nonneg _) (by norm_num)
        _ = _ := by norm_num
    have he : Real.exp ((7 / 1000 : ℝ):ℝ) ≤ (1008 / 1000 : ℝ) :=
      (Real.exp_bound_div_one_sub_of_interval (by norm_num) (by norm_num)).trans (by norm_num)
    have q := Real.exp_le_exp.mpr (show Real.log (f y) ≤ Real.log (f t) + (7 / 1000 : ℝ) by linarith)
    rw [Real.exp_log hp, Real.exp_add, Real.exp_log h.positive] at q
    calc
      _ ≤ f t * Real.exp (7 / 1000 : ℝ) := q
      _ ≤ v * (1008 / 1000 : ℝ) := mul_le_mul h.value he (Real.exp_pos _).le hv
      _ = _ := mul_comm _ _
  · exact (le_of_not_gt hp).trans (mul_nonneg (by norm_num) hv)

/-- The five point estimates in the printed table. -/
structure Rows (F : ℝ → ℝ) : Prop where
  single₁ : TangentRow F 2 (2*π) (4132 / 1000 : ℝ) (227 / 100 : ℝ)
  single₂ : TangentRow F (2*π) (4*π) (9358 / 1000 : ℝ) (412 / 100 : ℝ)
  single₃ : TangentRow F (4*π) (6*π) (15017 / 1000 : ℝ) (225 / 100 : ℝ)
  pair₁ : TangentRow (fun y => F y * F (y/4)) 8 (4*π) (10206 / 1000 : ℝ) (439 / 100 : ℝ)
  pair₂ : TangentRow (fun y => F y * F (y/4)) (4*π) (6*π) (15144 / 1000 : ℝ) (491 / 100 : ℝ)

theorem Rows.single {F : ℝ → ℝ} (h : Rows F) {y : ℝ} (hy : 2 ≤ y) (hy' : y ≤ 6*π) :
    F y ≤ 5 := by
  have hp : π < (315 / 100 : ℝ) := by convert Real.pi_lt_315 using 1; norm_num
  have hl := Real.pi_gt_three
  by_cases h1 : y ≤ 2*π
  · have q := h.single₁.bound ⟨hy,h1⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
    linarith
  by_cases h2 : y ≤ 4*π
  · have q := h.single₂.bound ⟨(not_le.mp h1).le,h2⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
    linarith
  · have q := h.single₃.bound ⟨(not_le.mp h2).le,hy'⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
    linarith

theorem Rows.pair {F : ℝ → ℝ} (h : Rows F) {y : ℝ} (hy : 8 ≤ y) (hy' : y ≤ 6*π) :
    F y * F (y/4) ≤ 5 := by
  have hp : π < (315 / 100 : ℝ) := by convert Real.pi_lt_315 using 1; norm_num
  have hl := Real.pi_gt_three
  by_cases h2 : y ≤ 4*π
  · have q := h.pair₁.bound ⟨hy,h2⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
    linarith
  · have q := h.pair₂.bound ⟨(not_le.mp h2).le,hy'⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
    linarith

theorem Rows.exceptional {F : ℝ → ℝ} (h : Rows F) {y : ℝ}
    (hy : 16 ≤ y) (hy' : y ≤ 6*π) : F y * 2 ≤ 5 := by
  have hp : π < (315 / 100 : ℝ) := by convert Real.pi_lt_315 using 1; norm_num
  have q := h.single₃.bound ⟨by linarith,hy'⟩ (abs_le.mpr ⟨by linarith,by linarith⟩)
  linarith

/-- A path follows one partial insertion. The nontrivial multipliers are
the last raw step or an earlier raw suffix followed by both full final guards. -/
inductive Path (F : ℝ → ℝ) : ℝ → ℝ → Prop
  | stop {y p : ℝ} (hp : p ≤ 1) : Path F y p
  | quiet {y x q p : ℝ} (hscale : x ≤ y/4) (hq₀ : 0 ≤ q) (hq : q ≤ 1)
      (tail : Path F x p) : Path F y (q*p)
  | last {y q p : ℝ} (hlo : 2 < y) (hhi : y < 6*π) (hq : 1 < q) (hf : q ≤ F y)
      (tail : Path F (y/4) p) : Path F y (q*p)
  | early {y x q p : ℝ} (hlo : 2 < y) (hhi : y < 6*π) (hscale : x ≤ y/16)
      (hq : 1 < q) (hf : q ≤ F y ∨ 4 < y ∧ q ≤ 2) (tail : Path F x p) : Path F y (q*p)

theorem Path.small {F : ℝ → ℝ} {y p : ℝ} (a : Path F y p) (hy : y ≤ 2) : p ≤ 1 := by
  induction a with
  | stop hp => exact hp
  | quiet hs hq₀ hq _ ih =>
    exact (mul_le_mul_of_nonneg_left (ih (by linarith)) hq₀).trans (by simpa using hq)
  | last hlo => linarith
  | early hlo => linarith

/-- After the first division by four, any additional amplification must be at
that very child. A second division puts the path below the contraction cutoff. -/
theorem Path.one {F : ℝ → ℝ} {y p : ℝ} (a : Path F y p) (hy : y ≤ 8) :
    p ≤ 1 ∨ (2 < y ∧ p ≤ F y) ∨ (4 < y ∧ p ≤ 2) := by
  cases a with
  | stop hp => exact Or.inl hp
  | quiet hs hq₀ hq tail =>
    exact Or.inl ((mul_le_mul_of_nonneg_left (tail.small (by linarith)) hq₀).trans (by simpa using hq))
  | last hlo _ hq hf tail =>
    exact Or.inr (Or.inl ⟨hlo,(mul_le_mul_of_nonneg_left (tail.small (by linarith))
      (by linarith)).trans (by simpa using hf)⟩)
  | early hlo _ hs hq hf tail =>
    have hchild := mul_le_mul_of_nonneg_left (tail.small (by linarith)) (le_trans zero_le_one hq.le)
    rw [mul_one] at hchild
    rcases hf with H | ⟨hh,H⟩
    · exact Or.inr (Or.inl ⟨hlo,hchild.trans H⟩)
    · exact Or.inr (Or.inr ⟨hh,hchild.trans H⟩)

theorem Path.bounded {F : ℝ → ℝ} (rows : Rows F) {y p : ℝ} (a : Path F y p) : p ≤ 5 := by
  have hpi := Real.pi_le_four
  induction a with
  | stop hp => linarith
  | quiet _ hq₀ hq _ ih =>
    exact (mul_le_mul_of_nonneg_left ih hq₀).trans (by linarith only [hq])
  | @last y q p hlo hhi hq hf tail _ =>
    have hq₀ : 0 ≤ q := le_trans zero_le_one hq.le
    rcases tail.one (by linarith only [hhi,hpi]) with h | ⟨h,hb⟩ | ⟨h,hb⟩
    · exact (mul_le_mul_of_nonneg_left h hq₀).trans (by simpa using hf.trans (rows.single hlo.le hhi.le))
    · calc
        _ ≤ q * F (y/4) := mul_le_mul_of_nonneg_left hb hq₀
        _ ≤ 5 := by
          by_cases h0 : 0 ≤ F (y/4)
          · exact (mul_le_mul_of_nonneg_right hf h0).trans (rows.pair (by linarith only [h]) hhi.le)
          · exact (mul_nonpos_of_nonneg_of_nonpos hq₀ (le_of_not_ge h0)).trans (by norm_num)
    · calc
        _ ≤ q*2 := mul_le_mul_of_nonneg_left hb hq₀
        _ ≤ F y*2 := by linarith only [hf]
        _ ≤ 5 := rows.exceptional (by linarith only [h]) hhi.le
  | early hlo hhi hs hq hf tail _ =>
    have h := mul_le_mul_of_nonneg_left (tail.small (by linarith only [hs,hhi,hpi])) (le_trans zero_le_one hq.le)
    rw [mul_one] at h
    rcases hf with H | ⟨_,H⟩
    · exact h.trans (H.trans (rows.single hlo.le hhi.le))
    · exact (h.trans H).trans (by norm_num)

/-- The continuously extended sinc function used in the phase formula. -/
def sinc (x : ℝ) : ℝ := if x = 0 then 1 else Real.sin x / x

/-- The four retained raw table multiplicities in the manuscript. -/
def envelope (y : ℝ) : ℝ :=
  (4*y^2/π^2 - 1) * |sinc (y/2)| * |sinc (y/8)|^2 *
    |sinc (y/32)|^6 * |sinc (y/128)|^20

/-- Concrete table conclusion from the path interpretation at its actual phase
and the five tangent rows for the explicit sine product. -/
theorem table_suffix_five (rows : Rows envelope) (k : ℕ) (z : ℝ)
    (paths : ∀ l s, GDProof.Schedule.table k = l ++ s →
      ∃ p, Path envelope ((2 : ℝ)^k * Real.arcsin (Real.sqrt z)) p ∧
        |GDProof.Prefix.prod z s| ≤ p) :
    GDProof.Suffix.Bounded z 5 (GDProof.Schedule.table k) := by
  intro l s hcut
  obtain ⟨_,h,hp⟩ := paths l s hcut
  exact hp.trans (h.bounded rows)

end
end GDProof.SuffixAssembly
