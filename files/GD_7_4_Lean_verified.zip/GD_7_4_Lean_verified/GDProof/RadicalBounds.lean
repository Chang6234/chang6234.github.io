import GDProof.Schedule

/-! Radical enclosures and mass truncations of the degree-four and degree-eight
tables in Appendix D.1. The exponent passed to `Schedule.table` is log₂(m). -/
namespace GDProof.RadicalBounds

open GDProof.Schedule
noncomputable section

/-- Enclose the smaller root using signs of its quadratic on [1,2].
The parent may itself be known only through an interval. -/
private theorem enclose_small {a lo hi l u : ℝ} (ha : 1 < a)
    (hal : lo ≤ a) (hau : a ≤ hi) (hl : 1 ≤ l) (hL : l ≤ 2)
    (hu : 1 ≤ u) (hU : u ≤ 2)
    (htl : 0 ≤ l^2 - 4*hi*(l-1)) (htu : u^2 - 4*lo*(u-1) ≤ 0) :
    l ≤ small a ∧ small a ≤ u := by
  have h := pair_mul ha.le
  unfold large at h
  have hs := (small_bounds ha.le).2
  have hL₀ := mul_nonneg (sub_nonneg.mpr hau) (sub_nonneg.mpr hl)
  have hU₀ := mul_nonneg (sub_nonneg.mpr hal) (sub_nonneg.mpr hu)
  constructor
  · by_contra! hlt
    have hsign : l + small a - 4*a < 0 := by linarith
    have := mul_neg_of_pos_of_neg (sub_pos.mpr hlt) hsign
    nlinarith
  · by_contra! hlt
    have hsign : small a + u - 4*a < 0 := by linarith
    have := mul_neg_of_pos_of_neg (sub_pos.mpr hlt) hsign
    nlinarith

theorem a2_bounds : (117157:ℝ)/100000 ≤ small 2 ∧ small 2 ≤ 117158/100000 := by
  apply enclose_small (lo := 2) (hi := 2) <;> norm_num

theorem a4_bounds : (14464:ℝ)/10000 ≤ small (small 2) ∧
    small (small 2) ≤ 14465/10000 := by
  obtain ⟨hl,hu⟩ := a2_bounds
  apply enclose_small (lo := 117157/100000) (hi := 117158/100000)
    (by linarith only [hl]) hl hu <;> norm_num

theorem a6_bounds : (10395:ℝ)/10000 ≤ small (large 2) ∧
    small (large 2) ≤ 10396/10000 := by
  obtain ⟨hl,hu⟩ := a2_bounds
  have h := pair_add (2:ℝ)
  apply enclose_small (lo := 8-117158/100000) (hi := 8-117157/100000)
    (by linarith only [hu,h]) (by linarith only [hu,h]) (by linarith only [hl,h]) <;> norm_num

theorem table_eight : table 3 =
    [1,2,small 2,large 2,small (small 2),large (small 2),small (large 2),
      1,2,large (large 2),1,2] := by rfl

/-- Keep n full entries, then choose the final entry so the sum equals half
the original table mass. The last-step bounds below verify the cut sites. -/
def cutAtHalf (k n : ℕ) : List ℝ :=
  let p := (table k).take n
  p ++ [(table k).sum/2 - p.sum]

theorem sum_four : (table 2).sum = 13 := by
  rw [table_four]
  simp only [List.sum_cons, List.sum_nil]
  linarith [pair_add (2:ℝ)]

theorem sum_eight : (table 3).sum = 49 := by
  rw [table_eight]
  simp only [List.sum_cons, List.sum_nil]
  linarith [pair_add (2:ℝ), pair_add (small 2), pair_add (large 2)]

/-- The five actual coefficients stopped at mass 13/2. -/
def four : Fin 5 → ℝ := ![1,2,small 2,1, 5/2 - small 2]

/-- The ten actual coefficients stopped at mass 49/2. -/
def eight : Fin 10 → ℝ :=
  ![1,2,small 2,large 2,small (small 2),large (small 2),small (large 2),
    1,2,21/2 - 4*small 2 - small (large 2)]

theorem cut_four : cutAtHalf 2 4 =
    [1,2,small 2,1,5/2 - small 2] := by
  unfold cutAtHalf
  rw [sum_four,table_four]
  simp [List.take]
  ring

theorem cut_eight : cutAtHalf 3 9 =
    [1,2,small 2,large 2,small (small 2),large (small 2),small (large 2),
      1,2,21/2 - 4*small 2 - small (large 2)] := by
  unfold cutAtHalf
  rw [sum_eight,table_eight]
  simp [List.take]
  linarith [pair_add (2:ℝ), pair_add (small 2)]

theorem four_from_table (i : Fin 5) : (cutAtHalf 2 4).getD i.val 0 = four i := by
  rw [cut_four]
  fin_cases i <;> rfl

theorem eight_from_table (i : Fin 10) : (cutAtHalf 3 9).getD i.val 0 = eight i := by
  rw [cut_eight]
  fin_cases i <;> rfl

theorem four_cut_within_last : 0 < four 4 ∧ four 4 ≤ (table 2).getD 4 0 := by
  rw [table_four]
  change 0 < 5/2 - small 2 ∧ 5/2-small 2 ≤ large 2
  obtain ⟨_,hu⟩ := a2_bounds
  constructor <;> linarith [pair_add (2:ℝ)]

theorem eight_cut_within_last : 0 < eight 9 ∧ eight 9 ≤ (table 3).getD 9 0 := by
  rw [table_eight]
  change 0 < 21/2-4*small 2-small (large 2) ∧
    21/2-4*small 2-small (large 2) ≤ large (large 2)
  obtain ⟨_,hu⟩ := a2_bounds
  obtain ⟨_,hv⟩ := a6_bounds
  constructor <;> linarith [pair_add (2:ℝ), pair_add (large 2)]

/-- Printed coefficient enclosure for the degree-four table. -/
def coeff4 : Fin 5 → ℝ × ℝ :=
  ![(1,1), (2,2), (7/6,6/5), (1,1), (13/10,4/3)]

/-- Printed coefficient enclosure for the degree-eight table. -/
def coeff8 : Fin 10 → ℝ × ℝ :=
  ![(1,1), (2,2), (117/100,118/100), (682/100,683/100),
    (144/100,145/100), (323/100,324/100), (103/100,104/100),
    (1,1), (2,2), (477/100,478/100)]

theorem four_enclosed (i : Fin 5) : (coeff4 i).1 ≤ four i ∧ four i ≤ (coeff4 i).2 := by
  obtain ⟨hl,hu⟩ := a2_bounds
  fin_cases i <;> norm_num [coeff4, four, Matrix.cons_val_succ] <;>
    constructor <;> linarith

theorem eight_enclosed (i : Fin 10) : (coeff8 i).1 ≤ eight i ∧ eight i ≤ (coeff8 i).2 := by
  obtain ⟨h2,h2'⟩ := a2_bounds
  obtain ⟨h4,h4'⟩ := a4_bounds
  obtain ⟨h6,h6'⟩ := a6_bounds
  have h3 := pair_add (2:ℝ)
  have h5 := pair_add (small 2)
  fin_cases i <;> norm_num [coeff8, eight, Matrix.cons_val_succ] <;>
    constructor <;> linarith

end
end GDProof.RadicalBounds
