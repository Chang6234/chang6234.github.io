import GDProof
import Lean.Elab.Print

open Lean Elab Command

/- Audit every theorem in every imported project module, including its private
lemmas. Use the same transitive dependency collector as Lean's #print axioms.
Sharing the traversal between declarations also keeps a full audit fast. -/
run_cmd do
  let env ← getEnv
  let mut roots : Array Name := #[]
  let mut modules : Nat := 0
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if `GDProof |>.isPrefixOf m then
      modules := modules + 1
      for decl in env.header.moduleData[i]!.constants do
        match decl with
        | .axiomInfo a =>
          if !a.isUnsafe && (`GDProof).isPrefixOf a.name then
            throwError "Project declares an axiom: {a.name}"
        | .thmInfo t => roots := roots.push t.name
        | _ => pure ()
  if roots.isEmpty then throwError "No imported project theorems found"
  let (_, state) := ((roots.forM CollectAxioms.collect).run env).run {}
  let allowed := #[``propext, ``Classical.choice, ``Quot.sound]
  for axiomName in state.axioms do
    unless allowed.contains axiomName do throwError "Unexpected axiom: {axiomName}"
  logInfo m!"Audited {modules} project modules and {roots.size} theorem declarations (including generated and private lemmas)."
  logInfo m!"Transitive axioms: {state.axioms.toList}"
