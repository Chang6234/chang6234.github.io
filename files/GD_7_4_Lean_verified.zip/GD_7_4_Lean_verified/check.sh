#!/bin/sh
set -eu
cd "$(dirname "$0")"
export LEAN_NUM_THREADS=1
case "${1:-main}" in
  modules|main) ;;
  *) echo "Usage: sh check.sh [modules|main]" >&2; exit 2 ;;
esac
test -f .lake/packages/mathlib/.lake/build/lib/Mathlib.olean || {
  echo "Install the mathlib cache as described in README.md." >&2; exit 2;
}
lake env lean --version
lake --version
mkdir -p .lake/build/lib/GDProof
while IFS= read -r name; do
  printf 'Checking GDProof.%s\n' "$name"
  lake env lean -j1 -o ".lake/build/lib/GDProof/$name.olean" "GDProof/$name.lean"
done < modules.txt
lake env lean -j1 -o .lake/build/lib/GDProof.olean GDProof.lean
lake env lean -j1 Audit.lean
if [ "${1:-main}" = main ]; then
  printf '%s\n' 'import GDProof' 'example : GDProof.MainGuarantee := GDProof.main_guarantee' '#print axioms GDProof.main_guarantee' '#check GDProof.title_rate' '#print axioms GDProof.title_rate' '#print axioms GDProof.FiniteDegree.storage_four' '#print axioms GDProof.FiniteDegree.storage_eight' |
    lake env lean -j1 --stdin
  echo 'Checked GDProof.title_rate.'
  echo 'Checked GDProof.main_guarantee : GDProof.MainGuarantee.'
fi
